package com.forkeye.invo.ui.base

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.forkeye.invo.R
import com.forkeye.invo.ui.dialog.AlertDialog


open class BaseFragment : Fragment() {

    private var dialog: ProgressDialog? = null

    fun showFragment(fragment: Fragment) {
        val transaction = activity?.supportFragmentManager?.beginTransaction()

        transaction?.replace(
            R.id.fragmentContainer, fragment
        )
        transaction?.addToBackStack(null)?.commit()
    }

    fun showProgress() {
        if (dialog == null){
            dialog = ProgressDialog(activity)
            dialog?.setMessage(activity?.applicationContext?.getString(R.string.making_network_call))
        }
        if (dialog?.isShowing == false)
            dialog?.show()
    }

    fun hideProgress(){
        if (dialog?.isShowing == true)
            dialog?.dismiss()
    }

    fun <T : AppCompatActivity> startActivity(
        className: Class<T>,
        extras: Bundle? = null,
        finishCurrent: Boolean = false,
        permissions: Array<String>? = null,
        clearStack: Boolean = false
    ) {


        val i = Intent(activity, className)

        if (extras != null)
            i.putExtras(extras)

        if (clearStack) {

            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        startActivity(i)

        //overridePendingTransition(R.anim.slide_in_from_right, R.anim.slide_out_from_left)

    }

    fun <T : AppCompatActivity> startActivityForResult(
        className: Class<T>,
        resultCode: Int,
        extras: Bundle? = null,
        finishCurrent: Boolean = false,
        permissions: Array<String>? = null,
        clearStack: Boolean = false
    ) {


        val i = Intent(activity, className)

        if (extras != null)
            i.putExtras(extras)

        if (clearStack) {

            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        startActivityForResult(i, resultCode)

        //overridePendingTransition(R.anim.slide_in_from_right, R.anim.slide_out_from_left)

    }
    fun showAlert(msg: String?) {
        activity?.let {
            AlertDialog.newInstance(msg, null, null).show(it.supportFragmentManager, "ConfirmationDialog")
        }
    }


}