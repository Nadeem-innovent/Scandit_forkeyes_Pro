package com.forkeye.invo.ui.map

import android.annotation.SuppressLint
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.forkeye.invo.R
import com.forkeye.invo.utils.LocationUtils
import com.google.android.gms.common.util.MapUtils
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import java.lang.Exception
import java.util.*

class MapsFragment : Fragment() {
    private var points = ArrayList<LatLng>()
    private var mMap: GoogleMap? = null
    private var line: Polyline? = null
    private var mapInterface:MapInterface? = null
    @SuppressLint("MissingPermission")
    private val callback = OnMapReadyCallback { googleMap ->
        /**
         * Manipulates the map once available.
         * This callback is triggered when the map is ready to be used.
         * This is where we can add markers or lines, add listeners or move the camera.
         * In this case, we just add a marker near Sydney, Australia.
         * If Google Play services is not installed on the device, the user will be prompted to
         * install it inside the SupportMapFragment. This method will only be triggered once the
         * user has installed Google Play services and returned to the app.
         */
        /**
         * Manipulates the map once available.
         * This callback is triggered when the map is ready to be used.
         * This is where we can add markers or lines, add listeners or move the camera.
         * In this case, we just add a marker near Sydney, Australia.
         * If Google Play services is not installed on the device, the user will be prompted to
         * install it inside the SupportMapFragment. This method will only be triggered once the
         * user has installed Google Play services and returned to the app.
         */
        mMap = googleMap
        mMap?.isMyLocationEnabled = true
        mMap?.uiSettings?.isZoomControlsEnabled = true
        mapInterface?.onMapReady()
    }

    fun setMapType(type: Int) {
        mMap!!.mapType = type
    }

    fun setMapInterface(myMapInterface:MapInterface){
        mapInterface = myMapInterface
    }

    fun showUserLocation(myLoc: Location?, zoomLevel:Float){
        myLoc?.let {
            if (LocationUtils.isLocationInRAK(myLoc.latitude, myLoc.longitude)){
                var myLatLng = LatLng(myLoc?.latitude!!, myLoc?.longitude!!)
                mMap?.animateCamera(
                    CameraUpdateFactory.newLatLngZoom(
                        myLatLng,
                        zoomLevel
                    )
                )
            }else
                Toast.makeText(context, "Your Location is not in RAK", Toast.LENGTH_SHORT).show()
        }
    }

    fun getZoomLevel(): Float? {
       return mMap?.cameraPosition?.zoom
    }

    fun redrawMap(geoPoints: ArrayList<LatLng>) {
        try {
            points = geoPoints
            if (line != null) {
                line?.remove()
            }
            if (mMap != null) {
                val options = PolylineOptions()
                for (i in points.indices) {
                    options.add(points[i])
                }
                options.width(6f)
                options.color(Color.RED)
                options.geodesic(true)
                line = mMap?.addPolyline(options)

                val sourceMarker: MarkerOptions = MarkerOptions()
                    .position(points[0])
                sourceMarker.icon(
                    BitmapDescriptorFactory.fromResource(R.drawable.src_mark)
                )
                mMap?.addMarker(sourceMarker)

                val destMarkerOptions: MarkerOptions = MarkerOptions()
                    .position(points[points.size-1])
                destMarkerOptions.icon(
                    BitmapDescriptorFactory.fromResource(R.drawable.dest_mark)
                )
                mMap?.addMarker(destMarkerOptions)

                mMap?.animateCamera(CameraUpdateFactory.newLatLngBounds(LatLngBounds(points[0], points[points.size-1]), 15))

            }

        }catch (ex:Exception){
         Log.e("Map Fragment", ""+ex.message)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_maps, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)
    }

    interface MapInterface{
        fun onMapReady()
    }
}