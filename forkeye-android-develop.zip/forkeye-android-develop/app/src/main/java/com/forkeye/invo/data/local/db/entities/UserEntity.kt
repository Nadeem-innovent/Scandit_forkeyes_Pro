package com.forkeye.invo.data.local.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.forkeye.invo.data.local.db.dao.UserDAO
import java.io.Serializable

@Entity(tableName = UserDAO.TABLE_NAME)
class UserEntity(
    @PrimaryKey()
    @ColumnInfo(name = UserDAO.ID)
    var id: String = "0",
    @ColumnInfo(name = UserDAO.PROCESS)
    var Process: String = "",
    @ColumnInfo(name = UserDAO.FIRST_NAME)
    var FirstName: String = "",
    @ColumnInfo(name = UserDAO.LAST_NAME)
    var LastName: String = "",
    @ColumnInfo(name = UserDAO.EMAIL)
    var Email: String = "",
    @ColumnInfo(name = UserDAO.USER_NAME)
    var Username: String = "",

    @ColumnInfo(name = UserDAO.PASSWORD)
    var Password: String = "",
    @ColumnInfo(name = UserDAO.PLANT)
    var Plant: String = "",
    @ColumnInfo(name = UserDAO.MANAGER)
    var Manager: String = "",
    @ColumnInfo(name = UserDAO.ROLE)
    var Role: String = ""


) : Serializable
