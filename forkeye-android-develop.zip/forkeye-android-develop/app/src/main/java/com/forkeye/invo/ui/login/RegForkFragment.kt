package com.forkeye.invo.ui.login

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.forkeye.invo.ui.MainActivity
import com.forkeye.invo.R
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils
import com.forkeye.invo.data.remote.NetworkHelper
import com.forkeye.invo.ui.barcode.BarcodeScannerActivity
import com.forkeye.invo.ui.base.BaseFragment
import org.koin.androidx.viewmodel.ext.android.viewModel


class RegForkFragment : BaseFragment() {

    val registerViewModel by viewModel<RegViewModel>()
    var forkRegNo: TextView? = null
    var forkId: TextView? = null
    var PlantNo: TextView? = null
    var RegDevice: TextView? = null

    companion object {
        @JvmStatic
        fun getInstance() =
            RegForkFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.reg_fort_fragment, container, false)

        val saveRegBtn = view.findViewById<Button>(R.id.bt_save)
        forkRegNo = view.findViewById<EditText>(R.id.forkLiftRegNo)
        forkId = view.findViewById<EditText>(R.id.forkLiftId)
        PlantNo = view.findViewById<EditText>(R.id.plantNoEt)
        RegDevice = view.findViewById<EditText>(R.id.regDevices)

        saveRegBtn.setOnClickListener {
            if (!forkRegNo?.text.toString().isNullOrEmpty()
                && !forkId?.text.toString().isNullOrEmpty()
                && !PlantNo?.text.toString().isNullOrEmpty()
                && !RegDevice?.text.toString().isNullOrEmpty()
            ) {
                showProgress()
                registerViewModel.performReg(
                    forkRegNo?.text.toString(),
                    forkId?.text.toString(), PlantNo?.text.toString(), RegDevice?.text.toString()
                )
            } else {
                checkPermission()
            }
        }
        val qrBtn: LinearLayout = view.findViewById<Button>(R.id.ll_scan_reg) as LinearLayout
        qrBtn.setOnClickListener {
            checkPermission()
        }


        registerViewModel.regResult.observe(viewLifecycleOwner, androidx.lifecycle.Observer {
            hideProgress()
            if (it != null) {
                Log.i("TAG", "onCreateView: ${it}")
                PrefUtils.saveToPrefs(context, PrefKeys.FORK_LIFT_REG_NO, forkRegNo?.text.toString())
                PrefUtils.saveToPrefs(context, PrefKeys.FORK_LIFT_REG_ID, forkId?.text.toString())
                PrefUtils.saveToPrefs(context, PrefKeys.REG_PLANT_ID, PlantNo?.text.toString())
                PrefUtils.saveToPrefs(context, PrefKeys.FORK_REG, true)
                startActivity(MainActivity::class.java)
                activity?.finish()
//                var result = it.equals("true")
//                if (!it.toString().isNullOrEmpty()) {
//                    if (result) {
//                    } else {
//                        Toast.makeText(context, "Registration Failed!", Toast.LENGTH_SHORT).show()
//                    }
//                }
            } else {
                Toast.makeText(context, "Registration Failed!", Toast.LENGTH_SHORT).show()
            }
        })

        return view
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == BarcodeScannerActivity.BARCODE) {
            var code = data?.extras?.get(BarcodeScannerActivity.BAR_CODE_VAL) as String
            code?.let {

                if (it.contains(":")) {
                    try {
                        var strArr = it.split(":")
                        forkRegNo?.text = strArr[0]
                        forkId?.text = strArr[1]
                        PlantNo?.text = strArr[2]
                        RegDevice?.text = strArr[3]
                        if (NetworkHelper(requireContext()).isNetworkConnected()) {
                            showProgress()
                            registerViewModel.performReg(
                                forkRegNo?.text.toString(),
                                forkId?.text.toString(), PlantNo?.text.toString(), RegDevice?.text.toString()
                            )
                        } else {
                            Toast.makeText(context, context?.getString(R.string.no_intenet), Toast.LENGTH_LONG).show()
                        }
                    } catch (ex: Exception) {
                        showAlert(context?.getString(R.string.qr_code_failed))
                    }
                } else {
                    showAlert(context?.getString(R.string.qr_code_failed))
                }
            }
        }
    }


    fun checkPermission() {
        var bundle = Bundle()
        bundle.putBoolean(BarcodeScannerActivity.FRONT_FACING_CAM, true)
        var intent = Intent(context, BarcodeScannerActivity::class.java)
        intent.putExtra(BarcodeScannerActivity.FRONT_FACING_CAM, true)
        startActivityForResult(
            intent,
            BarcodeScannerActivity.BARCODE,
            bundle
        )
    }
}