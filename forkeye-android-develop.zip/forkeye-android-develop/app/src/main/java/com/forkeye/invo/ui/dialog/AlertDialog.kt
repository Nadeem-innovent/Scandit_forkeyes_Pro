package com.forkeye.invo.ui.dialog

import android.os.Bundle
import android.view.*
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.forkeye.invo.R


class AlertDialog : DialogFragment() {

    var tvTitle:TextView? = null
    var btnPositive: Button? = null
    var btnNegative: Button? = null


    companion object {

        const val TAG = "SimpleDialog"
        private const val KEY_TITLE = "KEY_TITLE"
        private const val KEY_SUBTITLE = "KEY_SUBTITLE"
        private var listener: DialogClickListener? = null

        fun newInstance(title:String?, msg:String?, listener: DialogClickListener?): AlertDialog {
            val args = Bundle()
            args.putString(KEY_TITLE, title)
            args.putString(KEY_SUBTITLE, msg)
            val fragment = AlertDialog()
            fragment.arguments = args
            Companion.listener = listener
            return fragment
        }

    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view =  inflater.inflate(R.layout.dialog_alert, container, false)
        tvTitle = view.findViewById(R.id.tvTitle)
        btnPositive = view.findViewById(R.id.btnPositive)
        btnNegative = view.findViewById(R.id.btnNagitive)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (arguments != null && arguments?.containsKey(KEY_TITLE) == true)
        {
            tvTitle?.text = arguments?.get(KEY_TITLE) as String
        }
        setupView(view)
        setupClickListeners(view)
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun setupView(view: View) {
    }

    private fun setupClickListeners(view: View) {
        btnPositive?.setOnClickListener {
            listener?.onSelectionDone(true)
            dismiss()
        }

        btnNegative?.setOnClickListener {
            listener?.onSelectionDone(false)
            dismiss()
        }
    }

    interface DialogClickListener{
        fun onSelectionDone(transitToTruck: Boolean)
    }

}