package com.forkeye.invo.data.local.db.entities

import java.io.Serializable

data class AuthUser(
    val Process: String,
    val Username: String,
    val Password: String
):Serializable
