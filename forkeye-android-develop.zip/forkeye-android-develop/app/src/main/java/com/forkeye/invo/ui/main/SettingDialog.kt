package com.forkeye.invo.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatSpinner
import androidx.fragment.app.DialogFragment
import com.forkeye.invo.R
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils

class SettingDialog : DialogFragment() {

    var tvTitle: TextView? = null
    var tvSubTitle: TextView? = null
    var btnPositive: Button? = null
    var btnNegative: Button? = null

    var langSpinner: AppCompatSpinner? = null

    var langSelected:String? = null


    companion object {

        const val TAG = "SimpleDialog"
        private const val KEY_TITLE = "KEY_TITLE"
        private const val KEY_SUBTITLE = "KEY_SUBTITLE"
        private var listener: SettingDialogClickListener? = null

        fun newInstance(
            title: String,
            subTitle: String,
            listener: SettingDialogClickListener
        ): SettingDialog {
            val args = Bundle()
            args.putString(KEY_TITLE, title)
            args.putString(KEY_SUBTITLE, subTitle)
            val fragment = SettingDialog()
            fragment.arguments = args
            Companion.listener = listener
            return fragment
        }

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate(R.layout.dialog_setting, container, false)
        tvTitle = view.findViewById(R.id.tvTitle)
        tvSubTitle = view.findViewById(R.id.tvSubTitle)
        btnPositive = view.findViewById(R.id.btnPositive)
        btnNegative = view.findViewById(R.id.btnNegative)
        langSpinner = view.findViewById(R.id.lang_spinner)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupView(view)
        setupClickListeners(view)
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun setupView(view: View) {
        langSelected = PrefUtils.getFromPrefs(context, PrefKeys.LANGUAGE_PREF, "en") as String
        tvTitle?.text = arguments?.getString(KEY_TITLE)
        tvSubTitle?.text = arguments?.getString(KEY_SUBTITLE)
        langSpinner?.setSelection(getLangPosition(langSelected!!))
    }

    private fun getLangPosition(lang:String):Int{
        when(lang){
            "en" -> { return 0}
            "ar" -> { return 1 }
            "ur" -> { return 2 }
            "hi" -> { return 3 }
        }
        return 0
    }

    private fun setupClickListeners(view: View) {

        langSpinner?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long) {
                when(position){
                    0 -> { langSelected = "en" }
                    1 -> {langSelected = "ar" }
                    2 -> { langSelected = "ur" }
                    3 -> { langSelected = "hi" }
                }

            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

        btnPositive?.setOnClickListener {
            if (!PrefUtils.getFromPrefs(context, PrefKeys.LANGUAGE_PREF, "en")?.equals(langSelected)!!){
                PrefUtils.saveToPrefs(context, PrefKeys.LANGUAGE_PREF, langSelected!!)
                listener?.onSelectionDone(langSelected!!)
                dismiss()
            }else{
                Toast.makeText(context, context?.getString(R.string.not_save), Toast.LENGTH_SHORT).show()
            }
        }
        btnNegative?.setOnClickListener {
            dismiss()
        }
    }

    interface SettingDialogClickListener {
        fun onSelectionDone(locale:String)
    }

}