package com.forkeye.invo.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.forkeye.invo.R
import com.forkeye.invo.ui.base.BaseActivity
import com.forkeye.invo.ui.dialog.ConfirmationDialog
import com.forkeye.invo.ui.main.MainFragment


class MainActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        showFragment(MainFragment.getInstance())
    }

    override fun showFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()

        transaction.replace(
            R.id.fragmentContainer, fragment
        )
        transaction
            .addToBackStack(null)
            .commit()
    }

    override fun onBackPressed() {
        ConfirmationDialog.newInstance(applicationContext?.getString(R.string.exit_msg), null, object : ConfirmationDialog.DialogClickListener {
            override fun onSelectionDone(exit: Boolean) {
                if (exit)
                    finish()
            }
        }).show(supportFragmentManager, "ConfirmationDialog")
    }

}