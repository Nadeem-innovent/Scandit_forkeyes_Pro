package com.forkeye.invo.ui.login

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.forkeye.invo.data.local.db.entities.AuthUser
import com.forkeye.invo.data.local.db.entities.SubcriptionParam
import com.forkeye.invo.data.remote.response.Response
import com.forkeye.invo.data.remote.response.SubDataResponse
import com.forkeye.invo.ui.base.BaseViewModel
import kotlinx.coroutines.*
import java.io.Serializable
import java.lang.Exception
import kotlin.math.log

class SplashViewModel(
    var context: Context
) : BaseViewModel() {

    var viewModelJob = Job()
    val coroutineScope = CoroutineScope(viewModelJob + Dispatchers.Main)

    private val _loginResult = MutableLiveData<Response>()
    val loginResult: LiveData<Response>
        get() = _loginResult


    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }

    suspend fun performLogin(userName: String, password: String): Serializable? {
        val response = coroutineScope.async(Dispatchers.IO) {
            try {
                var authParam = AuthUser("Authenticate", userName, password)
                repository.authUser(authParam)
            } catch (ex: Exception) {
                Log.e("Exception", "performLogin:", ex.cause)
                null
            }
        }

        return response.await()
    }

    suspend fun performSubCheck() {

        try {
            var subParam = SubcriptionParam("fbfba1b0b46f4344", "123")
            val  response = repository.checkAppSubcriptin(subParam)
            Log.i("Resp", "" + response.toString())
        } catch (ex: Exception) {
            Log.e("Exception", "performLogin:", ex.cause)
            null
        }
    }


}