package com.forkeye.invo.data.local.db.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.forkeye.invo.data.local.db.entities.RegForkLiftEntity
import com.forkeye.invo.data.local.db.entities.RouteEntity

@Dao
interface RouteDAO {

    companion object {

        const val TABLE_NAME = "RoutesTable"
        const val ID = "ID"
        const val POINT_ID = "POINT_ID"
        const val LATITUE = "latitude"
        const val LONGITUDE = "longitude"
        const val TRACK_NAME = "track_name"
        const val DISTANCE_FROM_CUR_LOC = "distance_from_cur"
        const val DISTANCE_FROM_END_LOC = "distance_from_end"
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: RouteEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(items: List<RouteEntity>): List<Long>

    @Query("SELECT COUNT(*) from $TABLE_NAME")
    fun getCount(): Int

    @Query("SELECT * from $TABLE_NAME")
    fun getAllPoint(): List<RouteEntity>

    @Query("SELECT * from $TABLE_NAME where distance_from_cur = (Select MIN(distance_from_cur) from $TABLE_NAME )")
    fun getRoutePointNearestToCurrent(): RouteEntity

    @Query("SELECT * from $TABLE_NAME where distance_from_end = (Select MIN(distance_from_end) from $TABLE_NAME )")
    fun getRoutePointNearestToEnd(): RouteEntity

    @Query("SELECT * from $TABLE_NAME where track_name like :routeName ")
    fun getRouteFullRouteByName(routeName:String): List<RouteEntity>

//    @Query("select * from $TABLE_NAME where $REG_NO like :text")
//    fun searchByUserName(text: String): List<RegForkLiftEntity>

    @Query("delete from $TABLE_NAME")
    fun deleteAll()

    @Delete
    fun delete(item: RegForkLiftEntity)

    @Update
    fun update(item: RegForkLiftEntity)

    @Update
    fun update(items: List<RegForkLiftEntity>)
}