package com.forkeye.invo.ui.main

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils
import com.forkeye.invo.ui.ManualViewModel
import com.forkeye.invo.utils.ConnectionLiveData
import com.forkeye.invo.utils.LocationData
import com.forkeye.invo.utils.LocationUtils
import kotlinx.coroutines.*
import java.io.*
import java.net.*
import java.util.concurrent.atomic.AtomicBoolean


//private const val DEFAULT_RTSP_REQUEST = "rtsp://freja.hiof.no:1935/rtplive/definst/hessdalen03.stream"
//private const val DEFAULT_RTSP_USERNAME = ""
//private const val DEFAULT_RTSP_PASSWORD = ""

private val TAG: String = MainViewModel::class.java.simpleName
private const val DEBUG = true
private const val LIVE_PARAMS_FILENAME = "live_params"


//private var processMode:String


class MainViewModel(context: Context) : ManualViewModel(context) {


    var mContext = context
//New
//    val DEFAULT_RTSP_REQUEST = "rtsp://192.168.1.51/multicaststream_ch1"
//    val DEFAULT_RTSP_USERNAME = ""
//    val DEFAULT_RTSP_PASSWORD = ""
//Old
//    val DEFAULT_RTSP_REQUEST = "rtsp://192.168.1.51/axis-media/media.3gp"
//    val DEFAULT_RTSP_USERNAME = "root"
//    val DEFAULT_RTSP_PASSWORD = "Innovent@2020"

    val DEFAULT_RTSP_REQUEST = "rtsp://192.168.1.51:554/channel1"
    val DEFAULT_RTSP_USERNAME = "admin"
    val DEFAULT_RTSP_PASSWORD = "innovent@2020"

    val TAG = "MainViewModel"

    val loaderLD = MutableLiveData<DeviceStatus>()

    //val loaderOperationLD = MutableLiveData<DeviceStatus>()
    val pickedQualified = MutableLiveData(false)
    val locationLD = MutableLiveData<DeviceStatus>()
    var location = ""
    val qrCodeValue = MutableLiveData<String>().apply {
        value = "Waiting.."
    }


    private var viewModelJob = Job()
    private val coroutineScope = CoroutineScope(viewModelJob + Dispatchers.Main)

    var loaderRoutine:Deferred<Int>? = null
    var locationRoutine:Deferred<Int>? = null

    var msg = "default"
    var resp = "No Response Yet\nTry Sending Some Data."
    var server_address = "0.0.0.0"
    var loader_senosr_port: String = "8976"
    var gns_sensor_port: String = "9000"
    var Abort = false

    var loaderSensorUp = AtomicBoolean(false)
    var gnsSensorUp = AtomicBoolean(false)

    var socketLoader: Socket? = null
    val serverLoader: ServerSocket = ServerSocket()
    var socketLoc: Socket? = null
    var serverLocationSocket: ServerSocket? = null
    var dropOffType: DROP_OFF_TYPE = DROP_OFF_TYPE.TRUCK_TRANSIT

    val palletExternalListLD = repository.dropOffDAO().getAll()
    var connectionLiveData: ConnectionLiveData


    enum class DROP_OFF_TYPE(val type: String) {
        DEFAULT("Stored"),
        TRUCK_TRANSIT("Stock Transfer"),
        SHIPPING_TRUCK("Shipped"),
        INSIDE("Pending-Repacking")
    }

    init {
        server_address = PrefUtils.getFromPrefs(mContext, PrefKeys.SERVER_IP_1, "0.0.0.0") as String
        loader_senosr_port = PrefUtils.getFromPrefs(mContext, PrefKeys.LOADER_SENSOR_PORT, "8976") as String
        gns_sensor_port = PrefUtils.getFromPrefs(mContext, PrefKeys.LOCATION_SENSOR_PORT, "9000") as String
        startSensorService()
        connectionLiveData = ConnectionLiveData(mContext)
    }

    fun startSensorService() {
        coroutineScope.async(Dispatchers.IO) {
            if (!loaderSensorUp.get())
                startForkLoadingRoutine()

            while (!loaderSensorUp.get()) {
                //wait for 10 sec
                delay(1000)
                if (loaderSensorUp.get())
                    break
                startForkLoadingRoutine()
                delay(5000)
            }

        }

        coroutineScope.async(Dispatchers.IO) {
            if (!gnsSensorUp.get())
                startGNSLocationRoutine()

            while (!gnsSensorUp.get()) {
                //wait for 10 sec
                delay(10000)
                if (gnsSensorUp.get())
                    break
                startGNSLocationRoutine()
                delay(5000)
            }
        }
    }



    fun startForkLoadingRoutine() {

        coroutineScope.async(Dispatchers.IO) {

            try {
                Log.i(TAG, "startForkLoadingRoutine: Time: " + System.currentTimeMillis())
                loaderLD.postValue(DeviceStatus.STARTING)
                val address: SocketAddress =
                    InetSocketAddress(loader_senosr_port.toInt())
                serverLoader.bind(address)
                socketLoader = serverLoader.accept()
                loaderSensorUp.set(true)

                var br: BufferedReader? = null
                socketLoader?.setReuseAddress(true)
                socketLoader?.setSoLinger(true, 1000)
                loaderLD.postValue(DeviceStatus.WAITING)
                Log.d("test", "trying to read from server")

                var loadedTime = -1L
                var totalTime: Long

                while (true) {
                    socketLoader?.setKeepAlive(true)
                    socketLoader = serverLoader.accept()
                    loaderLD.postValue(DeviceStatus.CONNNECTED)

                    br = BufferedReader(InputStreamReader(socketLoader?.getInputStream()))
                    val buffer = CharArray(200)
                    br?.read(buffer)
                    val rawStr = String(buffer)
                    Log.d("Raw String", rawStr)

                    if (rawStr
                            .contains("Unload")
                    ) {
                        loaderLD.postValue(DeviceStatus.UNLOADED)
                        Log.d("my read", "Un Loaded")
                        totalTime = (System.currentTimeMillis() - loadedTime) / 1000
                        if (totalTime >= 10) {
                            pickedQualified.postValue(true)

                        } else {
                            pickedQualified.postValue(false)
                        }
                        totalTime = 0L
                        loadedTime = -1L
                    } else {
                        loaderLD.postValue(DeviceStatus.LOADED)
                        Log.d("my read", "Loaded")
                        if (loadedTime == -1L) {
                            totalTime = 0L
                            loadedTime = System.currentTimeMillis()
                        }
                    }
                    delay(300)
                }
                br?.close()
                socketLoader?.close()

            } catch (e: SocketException) {
                Log.d("timeout", "server took too long to respond")
                e.printStackTrace()
                loaderLD.postValue(DeviceStatus.ERROR)
            }
            Log.d("tag", "done server")


        }
    }



    fun startGNSLocationRoutine() {

        coroutineScope.async(Dispatchers.IO) {

            try {
                locationLD.postValue(DeviceStatus.STARTING)
                //val bufferSize = 200
                Log.i(TAG, "startGNSLocationRoutine: Time: " + System.currentTimeMillis())
                serverLocationSocket = ServerSocket(gns_sensor_port.toInt())

                while (true) {
                    if (serverLocationSocket != null) {
                        socketLoc = serverLocationSocket?.accept()
                        Log.i(TAG, "New client: $socketLoc")
                        locationLD.postValue(DeviceStatus.WAITING)
                        gnsSensorUp.set(true)

                        val dataInputStream = DataInputStream(socketLoc?.getInputStream())
                        val dataOutputStream = DataOutputStream(socketLoc?.getOutputStream())
                        locationLD.postValue(DeviceStatus.CONNNECTED)

                        //Run a thread to complete the read from Socket
                        coroutineScope.async(Dispatchers.IO) {

                            while (dataInputStream.available() > 0) {
                                try {
                                    if (dataInputStream.available() > 0) {
                                        val rawStr = dataInputStream.readLine()
                                        Log.i("Location", "Received: " + rawStr)

                                        val strArr = rawStr.split("\\n".toRegex()).toTypedArray()
                                        var gprmc = ""
                                        var gpgga = ""
                                        val parser = NMEA()

                                        for (i in strArr.indices) {
                                            if (strArr[i].contains("\$GPRMC")) {

                                                gprmc = strArr[i]
                                                var index = gprmc.indexOf("$")
                                                if (index > 0 && index < gprmc.length) {
                                                    gprmc = gprmc.substring(index, gprmc.length)
                                                    Log.d("LINE", gprmc)
                                                }
                                                try {
                                                    parser.parse(gprmc)
                                                } catch (ex: Exception) {
                                                    Log.e(TAG, "Location: parsing exception", ex.cause)
                                                }
                                            }

                                            if (strArr[i].contains("\$GPGGA")) {
                                                gpgga = strArr[i]
                                                var index = gpgga.indexOf("$")
                                                if (index > 0 && index < gpgga.length) {
                                                    gpgga = gpgga.substring(index, gpgga.length)
                                                    Log.d("LINE", gpgga)
                                                }
                                                try {
                                                    parser.parse(gpgga)
                                                } catch (ex: Exception) {
                                                    Log.e(TAG, "Location: parsing exception", ex.cause)
                                                }
                                            }
                                        }
                                        if (!gprmc.isEmpty() || !gpgga.isEmpty()) {


                                            //locationLD.postValue("Loc: " + parser.position.lat.toString() + ", " + parser.position.lon)
                                            location = "" + parser.position.lon + ";" + parser.position.lat.toString()
                                            LocationUtils.insertLocation(LocationData(location, parser.position.quality, System.currentTimeMillis()))
                                            Log.d(
                                                "Position",
                                                "Position: lat: " + parser.position.lat.toString() + " long: " + parser.position.lon
                                            )
                                        }

                                        delay(300)
                                    }
                                } catch (e: IOException) {
                                    locationLD.postValue(DeviceStatus.ERROR)
                                    e.printStackTrace()
                                    try {
                                        dataInputStream.close()
                                        dataOutputStream.close()
                                    } catch (ex: IOException) {
                                        ex.printStackTrace()
                                    }
                                } catch (e: InterruptedException) {
                                    locationLD.postValue(DeviceStatus.ERROR)
                                    e.printStackTrace()
                                    try {
                                        dataInputStream.close()
                                        dataOutputStream.close()
                                    } catch (ex: IOException) {
                                        ex.printStackTrace()
                                    }
                                }
                            }
                        }
//                        dataInputStream.close()
//                        dataOutputStream.close()
                        delay(100)
                    }
                }

                socketLoc?.close()

            } catch (e: Exception) {
                locationLD.postValue(DeviceStatus.ERROR)
                Log.e(TAG, "Location: " + e.localizedMessage)
                socketLoc?.close()
            }

            locationLD.postValue(DeviceStatus.DISCONECTED)
            Log.d("tag", "done server")
        }
    }


    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }


//    fun dropOffShip(qrCode: String, default: MainViewModel.DROP_OFF_TYPE) {
//        var dropOff = DropOffEntity(
//            System.currentTimeMillis().toString(),
//            (qrCode),
//            System.currentTimeMillis().toString(),
//            "VISION_1234",
//            PrefUtils.getFromPrefs(mContext, PrefKeys.USER_NAME, "") as String,
//            default.type,
//            PrefUtils.getFromPrefs(mContext, PrefKeys.FORK_LIFT_REG_NO, "") as String,
//            location + ";0.0"
//
//        )
//        repository.dropOffDAO().insert(dropOff)
//    }
//
//    fun dropOffInside(qrCode: String, zone: String) {
//        var dropOff = DropOffEntity(
//            System.currentTimeMillis().toString(),
//            (qrCode),
//            System.currentTimeMillis().toString(),
//            "VISION_1234",
//            PrefUtils.getFromPrefs(mContext, PrefKeys.USER_NAME, "") as String,
//            DROP_OFF_TYPE.INSIDE.type,
//            PrefUtils.getFromPrefs(mContext, PrefKeys.FORK_LIFT_REG_NO, "") as String,
//            zone,
//            zone
//        )
//        repository.dropOffDAO().insert(dropOff)
//    }
//
//    fun dropOffDefault(qrCode: String, zone: String) {
//        var dropOff = DropOffEntity(
//            System.currentTimeMillis().toString(),
//            (qrCode),
//            System.currentTimeMillis().toString(),
//            "VISION_1234",
//            PrefUtils.getFromPrefs(mContext, PrefKeys.USER_NAME, "") as String,
//            DROP_OFF_TYPE.DEFAULT.type,
//            PrefUtils.getFromPrefs(mContext, PrefKeys.FORK_LIFT_REG_NO, "") as String,
//            location + ";0.0",
//            zone
//        )
//        repository.dropOffDAO().insert(dropOff)
//    }

    fun addImageToLastDropOff(base64Img: String): Boolean {
        try {
            var lastDropOff = repository.dropOffDAO().getLastItem()
            if (lastDropOff != null){
                lastDropOff.image = base64Img
                lastDropOff.pushed = false
                repository.dropOffDAO().update(lastDropOff)
                return true
            }else{
                return false
            }
        } catch (ex: java.lang.Exception) {
            Log.e("Save Image", "" + ex.message)
            return false
        }
    }

    fun resetSensorState() {
        loaderSensorUp.set(false)
        gnsSensorUp.set(false)
    }

    fun stopSensor() {
        resetSensorState()
        coroutineScope.async(Dispatchers.IO) {
            loaderRoutine?.cancelAndJoin()
            locationRoutine?.cancelAndJoin()
        }
    }

}