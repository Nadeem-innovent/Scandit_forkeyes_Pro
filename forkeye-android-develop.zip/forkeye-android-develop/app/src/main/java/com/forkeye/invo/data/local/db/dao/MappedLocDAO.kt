package com.forkeye.invo.data.local.db.dao

import androidx.room.*
import com.forkeye.invo.data.local.db.entities.MappedLocEntity

@Dao
interface MappedLocDAO {

    companion object {

//        "LocationDetails":"MC5",
//        "StorageLocation":"T5GD",
//        "BinLocation":"A18",
//        "Lane":"B",
//        "MappedZone":"MC5-ZONE-A"

        const val TABLE_NAME = "MappedLocationTable"
        const val ID = "id"
        const val LOCATION_DETAILS = "Location_Details"
        const val STORAGE_LOCATION = "Storage_Location"
        const val BIN_LOCATION = "Bin_Location"
        const val LANE = "Lane"
        const val MAPPED_ZONE = "Mapped_Zone"
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: MappedLocEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(items: ArrayList<MappedLocEntity>): List<Long>

    @Query("SELECT COUNT(*) from $TABLE_NAME")
    fun getCount(): Int

    @Query("select * from $TABLE_NAME where $STORAGE_LOCATION like :text")
    fun searchByUserName(text: String): List<MappedLocEntity>

    @Query("delete from $TABLE_NAME")
    fun deleteAll()

    @Delete
    fun delete(item: MappedLocEntity)

    @Update
    fun update(item: MappedLocEntity)

    @Update
    fun update(items: List<MappedLocEntity>)
}