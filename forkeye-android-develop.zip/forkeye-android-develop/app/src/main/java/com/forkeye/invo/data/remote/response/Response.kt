package com.forkeye.invo.data.remote.response

import java.io.Serializable

data class Response (
	val response : String?,
	val error : String?,
	val Username : String?,
	val FirstName : String?,
	val LastName : String?,
	val Role : String?,
	val Plant : String?,
	val Manager : String?,
	val Email : String?,

	val lastDetectTime : String?,

	val serialNumber : String?,
	val Material : String?,
	val Batch : String?,
	val location : String?,
	val ProcessTime : String?

):Serializable