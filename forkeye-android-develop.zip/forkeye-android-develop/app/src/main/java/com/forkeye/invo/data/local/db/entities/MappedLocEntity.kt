package com.forkeye.invo.data.local.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.forkeye.invo.data.local.db.dao.MappedLocDAO
import java.io.Serializable

@Entity(tableName = MappedLocDAO.TABLE_NAME)
class MappedLocEntity(


    @PrimaryKey()
    @ColumnInfo(name = MappedLocDAO.ID)
    var id: String = "0",
    @ColumnInfo(name = MappedLocDAO.LOCATION_DETAILS)
    var LocationDetails: String = "",
    @ColumnInfo(name = MappedLocDAO.STORAGE_LOCATION)
    var StorageLocation: String = "",
    @ColumnInfo(name = MappedLocDAO.BIN_LOCATION)
    var BinLocation: String = "",
    @ColumnInfo(name = MappedLocDAO.LANE)
    var Lane: String = "",
    @ColumnInfo(name = MappedLocDAO.MAPPED_ZONE)
    var MappedZone: String = "",


) : Serializable
