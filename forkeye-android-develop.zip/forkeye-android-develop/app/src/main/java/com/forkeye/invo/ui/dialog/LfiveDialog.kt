package com.forkeye.invo.ui.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.forkeye.invo.R

class LfiveDialog : DialogFragment() {

    var tvSubTitle: TextView? = null
    var btnPositive: Button? = null
    var btnClear: Button? = null

    var btn1: TextView? = null
    var btn2: TextView? = null
    var btn3: TextView? = null
    var btn4: TextView? = null
    var btn5: TextView? = null
    var btn6: TextView? = null
    var btn7: TextView? = null
    var btn8: TextView? = null

    var btn9: TextView? = null
    var btn0: TextView? = null

    var btnA: TextView? = null
    var btnB: TextView? = null
    var btnALane: TextView? = null
    var btnBLane: TextView? = null
    var btnC: TextView? = null
    var btnD: TextView? = null
    var btnE: TextView? = null
    var btnF: TextView? = null
    var btnG: TextView? = null
    var btnH: TextView? = null
    var btnI: TextView? = null
    var btnJ: TextView? = null
    var btnK: TextView? = null
    var btnL: TextView? = null
    var btnM: TextView? = null
    var btnN: TextView? = null
    var btnO: TextView? = null
    var btnP: TextView? = null
    var btnQ: TextView? = null
    var btnR: TextView? = null
    var btnS: TextView? = null
    var btnT: TextView? = null
    var btnU: TextView? = null
    var btnV: TextView? = null
    var btnW: TextView? = null
    var btnX: TextView? = null
    var btnY: TextView? = null
    var btnZ: TextView? = null

    var btnRAK: TextView? = null
    var btnMC1: TextView? = null
    var btnMC2: TextView? = null
    var btnMC3: TextView? = null
    var btnMC4: TextView? = null
    var btnMC5: TextView? = null
    var btnMC6: TextView? = null
    var btnMC7: TextView? = null
    var btnMC8: TextView? = null
    var btnMC9: TextView? = null
    var btnTRD: TextView? = null
    var btnAIN: TextView? = null
    var btnRTL: TextView? = null
    var btnARC: TextView? = null
    var btnGFD: TextView? = null
    var btnCER: TextView? = null
    var btnJAP: TextView? = null
    var btnSWD: TextView? = null
    var btnKLD: TextView? = null


    var btnAMCE: TextView? = null
    var btnEL01: TextView? = null
    var btnELEL: TextView? = null
    var btnELER: TextView? = null
    var btnELG1: TextView? = null
    var btnELKR: TextView? = null
    var btnJAWH: TextView? = null
    var btnJWTR: TextView? = null
    var btnELKL: TextView? = null
    var btnELOT: TextView? = null
    var btnELSB: TextView? = null
    var btnELTW: TextView? = null
    var btnTWR1: TextView? = null
    var btnTWRR: TextView? = null


    var laneSelected: String = ""
    var locSelected: String = ""
    var binAbc123Selected: String = ""




    companion object {

        const val TAG = "SimpleDialog"
        private const val KEY_TITLE = "KEY_TITLE"
        private const val KEY_SUBTITLE = "KEY_SUBTITLE"
        private var listener: SimpleDialogClickListener? = null

        fun newInstance(title: String, subTitle: String, listener: SimpleDialogClickListener): LfiveDialog {
            val args = Bundle()
            args.putString(KEY_TITLE, title)
            args.putString(KEY_SUBTITLE, subTitle)
            val fragment = LfiveDialog()
            fragment.arguments = args
            Companion.listener = listener
            return fragment
        }

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate(R.layout.dialog_l_five, container, false)

        tvSubTitle = view.findViewById(R.id.tvSubTitle)
        btnPositive = view.findViewById(R.id.btnPositive)
        btnClear = view.findViewById(R.id.btnClean)

        btn1 = view.findViewById(R.id.btnOne)
        btn2 = view.findViewById(R.id.btnTwo)
        btn3 = view.findViewById(R.id.btnThree)
        btn4 = view.findViewById(R.id.btnFour)
        btn5 = view.findViewById(R.id.btnFive)
        btn6 = view.findViewById(R.id.btnSix)
        btn7 = view.findViewById(R.id.btnSeven)
        btn8 = view.findViewById(R.id.btn8)
        btn9 = view.findViewById(R.id.btn9)
        btn0 = view.findViewById(R.id.btn0)

        btnA = view.findViewById(R.id.aBtn)
        btnB = view.findViewById(R.id.bBtn)
        btnC = view.findViewById(R.id.cBtn)
        btnD = view.findViewById(R.id.dBtn)
        btnE = view.findViewById(R.id.eBtn)
        btnF = view.findViewById(R.id.fBtn)
        btnG = view.findViewById(R.id.gBtn)
        btnH = view.findViewById(R.id.hBtn)
        btnI = view.findViewById(R.id.iBtn)
        btnJ = view.findViewById(R.id.jBtn)
        btnK = view.findViewById(R.id.kBtn)
        btnL = view.findViewById(R.id.lBtn)
        btnM = view.findViewById(R.id.mBtn)
        btnN = view.findViewById(R.id.nBtn)
        btnO = view.findViewById(R.id.oBtn)
        btnP = view.findViewById(R.id.pBtn)
        btnQ = view.findViewById(R.id.qBtn)
        btnR = view.findViewById(R.id.rBtn)
        btnS = view.findViewById(R.id.sBtn)
        btnT = view.findViewById(R.id.tBtn)
        btnU = view.findViewById(R.id.uBtn)
        btnV = view.findViewById(R.id.vBtn)
        btnW = view.findViewById(R.id.wBtn)
        btnX = view.findViewById(R.id.xBtn)
        btnY = view.findViewById(R.id.yBtn)
        btnZ = view.findViewById(R.id.zBtn)

        btnALane = view.findViewById(R.id.aLaneBtn)
        btnBLane = view.findViewById(R.id.bLaneBtn)

        btnRAK = view.findViewById(R.id.locRakBtn)
        btnMC1 = view.findViewById(R.id.locMc1Btn)
        btnMC2 = view.findViewById(R.id.locMc2Btn)
        btnMC3 = view.findViewById(R.id.locMc3Btn)
        btnMC4 = view.findViewById(R.id.locMc4Btn)
        btnMC5 = view.findViewById(R.id.locMc5Btn)
        btnMC6 = view.findViewById(R.id.locMc6Btn)
        btnMC7 = view.findViewById(R.id.locMc7Btn)
        btnMC8 = view.findViewById(R.id.locMc8Btn)
        btnMC9 = view.findViewById(R.id.locMc9Btn)
        btnTRD = view.findViewById(R.id.locTrdBtn)
        btnAIN = view.findViewById(R.id.locAinBtn)
        btnRTL = view.findViewById(R.id.locRTLBtn)
        btnARC = view.findViewById(R.id.locARCBtn)
        btnGFD = view.findViewById(R.id.locGFDBtn)
        btnCER = view.findViewById(R.id.locCERBtn)
        btnJAP = view.findViewById(R.id.locJAPBtn)
        btnSWD = view.findViewById(R.id.locSWDBtn)
        btnKLD = view.findViewById(R.id.locKLDBtn)

        btnAMCE = view.findViewById(R.id.locAMCEBtn)
        btnEL01 = view.findViewById(R.id.locEL01Btn)
        btnELEL = view.findViewById(R.id.locELELBtn)
        btnELER = view.findViewById(R.id.locELERBtn)
        btnELG1 = view.findViewById(R.id.locELG1Btn)
        btnELKR = view.findViewById(R.id.locELKRBtn)
        btnJAWH = view.findViewById(R.id.locJAWHBtn)
        btnJWTR = view.findViewById(R.id.locJWTRBtn)
        btnELKL = view.findViewById(R.id.locELKLBtn)
        btnELOT = view.findViewById(R.id.locELOTBtn)
        btnELSB = view.findViewById(R.id.locELSBBtn)
        btnELTW = view.findViewById(R.id.locELTWBtn)
        btnTWR1 = view.findViewById(R.id.locTWR1Btn)
        btnTWRR = view.findViewById(R.id.locTWRRBtn)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupView(view)
        setupClickListeners(view)
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun setupView(view: View) {
        tvSubTitle?.text = arguments?.getString(KEY_SUBTITLE)
    }

    private fun setupClickListeners(view: View) {

        btn1?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "1"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btn2?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "2"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btn3?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "3"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btn4?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "4"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btn5?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "5"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btn6?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "6"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btn7?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "7"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btn8?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "8"
                tvSubTitle?.text = getUpdateL5()
            }
        }

        btn9?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "9"
                tvSubTitle?.text = getUpdateL5()
            }
        }

        btn0?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "0"
                tvSubTitle?.text = getUpdateL5()
            }
        }


        btnA?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "A"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnB?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "B"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnC?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "C"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnD?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "D"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnE?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "E"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnF?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "F"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnG?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "G"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnH?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "H"
                tvSubTitle?.text = getUpdateL5()
            }
        }

        btnI?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "I"
                tvSubTitle?.text = getUpdateL5()
            }
        }

        btnJ?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "J"
                tvSubTitle?.text = getUpdateL5()
            }
        }

        btnK?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "K"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnL?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "L"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnM?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "M"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnN?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "N"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnO?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "O"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnP?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "P"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnQ?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "Q"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnR?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "R"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnS?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "S"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnT?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "T"
                tvSubTitle?.text = getUpdateL5()
            }
        }

        btnU?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "U"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnV?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "V"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnW?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "W"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnX?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "X"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnY?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "Y"
                tvSubTitle?.text = getUpdateL5()
            }
        }
        btnZ?.setOnClickListener {
            if (checkAB123LenghtNotGreaterThan4()) {
                binAbc123Selected += "Z"
                tvSubTitle?.text = getUpdateL5()
            }
        }


        btnRAK?.setOnClickListener {
            locSelected = "RAK"
            tvSubTitle?.text = getUpdateL5()
        }
        btnMC1?.setOnClickListener {
            locSelected = "MC1"
            tvSubTitle?.text = getUpdateL5()
        }
        btnMC2?.setOnClickListener {
            locSelected = "MC2"
            tvSubTitle?.text = getUpdateL5()
        }
        btnMC3?.setOnClickListener {
            locSelected = "MC3"
            tvSubTitle?.text = getUpdateL5()
        }
        btnMC4?.setOnClickListener {
            locSelected = "MC4"
            tvSubTitle?.text = getUpdateL5()
        }
        btnMC5?.setOnClickListener {
            locSelected = "MC5"
            tvSubTitle?.text = getUpdateL5()
        }
        btnMC6?.setOnClickListener {
            locSelected = "MC6"
            tvSubTitle?.text = getUpdateL5()
        }
        btnMC7?.setOnClickListener {
            locSelected = "MC7"
            tvSubTitle?.text = getUpdateL5()
        }
        btnMC8?.setOnClickListener {
            locSelected = "MC8"
            tvSubTitle?.text = getUpdateL5()
        }
        btnMC9?.setOnClickListener {
            locSelected = "MC9"
            tvSubTitle?.text = getUpdateL5()
        }


        btnTRD?.setOnClickListener {
            locSelected = "TRD"
            tvSubTitle?.text = getUpdateL5()
        }
        btnAIN?.setOnClickListener {
            locSelected = "AIN"
            tvSubTitle?.text = getUpdateL5()
        }
        btnRTL?.setOnClickListener {
            locSelected = "RTL"
            tvSubTitle?.text = getUpdateL5()
        }
        btnARC?.setOnClickListener {
            locSelected = "ARC"
            tvSubTitle?.text = getUpdateL5()
        }
        btnGFD?.setOnClickListener {
            locSelected = "GFD"
            tvSubTitle?.text = getUpdateL5()
        }
        btnCER?.setOnClickListener {
            locSelected = "CER"
            tvSubTitle?.text = getUpdateL5()
        }
        btnJAP?.setOnClickListener {
            locSelected = "JAP"
            tvSubTitle?.text = getUpdateL5()
        }
        btnSWD?.setOnClickListener {
            locSelected = "SWD"
            tvSubTitle?.text = getUpdateL5()
        }
        btnKLD?.setOnClickListener {
            locSelected = "KLD"
            tvSubTitle?.text = getUpdateL5()
        }


        btnAMCE?.setOnClickListener {
            locSelected = "AMCE"
            tvSubTitle?.text = getUpdateL5()
        }
        btnEL01?.setOnClickListener {
            locSelected = "EL01"
            tvSubTitle?.text = getUpdateL5()
        }
        btnELEL?.setOnClickListener {
            locSelected = "ELEL"
            tvSubTitle?.text = getUpdateL5()
        }
        btnELER?.setOnClickListener {
            locSelected = "ELER"
            tvSubTitle?.text = getUpdateL5()
        }
        btnELG1?.setOnClickListener {
            locSelected = "ELG1"
            tvSubTitle?.text = getUpdateL5()
        }
        btnELKR?.setOnClickListener {
            locSelected = "ELKR"
            tvSubTitle?.text = getUpdateL5()
        }
        btnJAWH?.setOnClickListener {
            locSelected = "JAWH"
            tvSubTitle?.text = getUpdateL5()
        }
        btnJWTR?.setOnClickListener {
            locSelected = "JWTR"
            tvSubTitle?.text = getUpdateL5()
        }
        btnELKL?.setOnClickListener {
            locSelected = "ELKL"
            tvSubTitle?.text = getUpdateL5()
        }
        btnELOT?.setOnClickListener {
            locSelected = "ELOT"
            tvSubTitle?.text = getUpdateL5()
        }
        btnELSB?.setOnClickListener {
            locSelected = "ELSB"
            tvSubTitle?.text = getUpdateL5()
        }
        btnELTW?.setOnClickListener {
            locSelected = "ELTW"
            tvSubTitle?.text = getUpdateL5()
        }
        btnTWR1?.setOnClickListener {
            locSelected = "TWR1"
            tvSubTitle?.text = getUpdateL5()
        }
        btnTWRR?.setOnClickListener {
            locSelected = "TWRR"
            tvSubTitle?.text = getUpdateL5()
        }





        btnALane?.setOnClickListener {
            laneSelected = "A"
            tvSubTitle?.text = getUpdateL5()
        }
        btnBLane?.setOnClickListener {
            laneSelected = "B"
            tvSubTitle?.text = getUpdateL5()
        }


        btnPositive?.setOnClickListener {
            if (!checkValidSequence()) return@setOnClickListener
            listener?.onSelectionDone( locSelected, laneSelected,binAbc123Selected,  locSelected+"-"+binAbc123Selected + "-" + laneSelected)
            dismiss()
        }

        btnClear?.setOnClickListener {
            locSelected = ""
            binAbc123Selected = ""
            laneSelected = ""
            tvSubTitle?.text = getUpdateL5()
        }

    }

    private fun getUpdateL5() = context?.getString(R.string.selection) + " " + locSelected + "-" + binAbc123Selected + "-" + laneSelected

    private fun checkValidSequence(): Boolean {
        if (locSelected.isNullOrEmpty()) {
            showAlert(context?.getString(R.string.sel_zone))
            return false
        }
        if (binAbc123Selected.isNullOrEmpty()) {
            showAlert("After zone please select ABC/123")
            return false
        }
        if (laneSelected.isNullOrEmpty()) {
            showAlert("Please select lane button")
            return false
        }
        return true
    }

    fun checkAB123LenghtNotGreaterThan4(): Boolean {
        return binAbc123Selected.length < 4
    }

    fun showAlert(msg: String?) {
        activity?.supportFragmentManager?.let {
            AlertDialog.newInstance(msg, null, null).show(it, "ConfirmationDialog")
        }
    }

    interface SimpleDialogClickListener {
        fun onSelectionDone(locDetails:String, lane:String, bin:String, l5Selection: String)
    }

}