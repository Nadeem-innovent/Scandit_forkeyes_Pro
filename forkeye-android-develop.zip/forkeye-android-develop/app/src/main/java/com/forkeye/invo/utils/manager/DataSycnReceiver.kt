package com.forkeye.invo.utils.manager

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.forkeye.invo.data.Repository
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils
import com.forkeye.invo.data.remote.entity.DefaultDropOffEntity
import com.forkeye.invo.data.remote.entity.InsideDropOffEntity
import com.forkeye.invo.data.remote.entity.TruckShippingEntity
import com.forkeye.invo.data.remote.entity.TruckTransitEntity
import com.forkeye.invo.ui.main.MainViewModel
import com.google.firebase.crashlytics.FirebaseCrashlytics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import org.koin.core.component.KoinComponent
import org.koin.core.component.get
import java.util.*

class DataSycnReceiver : BroadcastReceiver(), KoinComponent {

    val repository by lazy { get<Repository>() }
    val DAY_IN_MILLISECONDS = (24 * 60 * 60 * 1000).toLong()


    val DELAY: Long = 500

    override fun onReceive(context: Context?, intent: Intent?) {

        var list = repository.dropOffDAO().getAllNonPushed()

        if (list.size > 0) {

            list?.let {
                GlobalScope.launch(Dispatchers.IO) {
                    for (index in 0 until it.size) {
                        try {
                            var op = it.get(index)
                            op.truck_plate = PrefUtils.getFromPrefs(context, PrefKeys.FORK_LIFT_REG_NO, "") as String
                            op.User = PrefUtils.getFromPrefs(context, PrefKeys.USER_NAME, "") as String
                            when (op.Process) {
                                MainViewModel.DROP_OFF_TYPE.DEFAULT.type -> {
                                    GlobalScope.async(Dispatchers.IO) {
                                        var default = DefaultDropOffEntity(
                                            op.PalletSerialNumber,
                                            op.lastDetectTime,
                                            op.source,
                                            op.User,
                                            MainViewModel.DROP_OFF_TYPE.DEFAULT.type,
                                            op.ForkliftSerialNumber,
                                            op.LocationDetails,
                                            op.BinLocation,
                                            op.Lane,
                                            op.L5Location,
                                            op.location,
                                            op.L5Location,
                                            op.image
                                        )
                                        var res = repository.dropOffDefault(default)

                                        //delay(DELAY)
                                        if (!res?.response?.isNullOrEmpty()!!) {
                                            op.pushed = true
                                            repository.dropOffDAO().update(op)
                                        }
                                    }

                                }
                                MainViewModel.DROP_OFF_TYPE.INSIDE.type -> {
                                    GlobalScope.async(Dispatchers.IO) {
                                        var inside = InsideDropOffEntity(
                                            op.PalletSerialNumber,
                                            op.lastDetectTime,
                                            op.source,
                                            op.User,
                                            MainViewModel.DROP_OFF_TYPE.DEFAULT.type,
                                            op.ForkliftSerialNumber,
                                            op.LocationDetails,
                                            "",
                                            op.LocationDetails,
                                            op.image
                                        )

                                        var res = repository.dropOffInside(inside)
                                        //delay(DELAY)
                                        if (!res?.response?.isNullOrEmpty()!!) {
                                            op.pushed = true
                                            repository.dropOffDAO().update(op)
                                        }
                                    }
                                }
                                MainViewModel.DROP_OFF_TYPE.TRUCK_TRANSIT.type -> {
                                    GlobalScope.async(Dispatchers.IO) {
                                        var transitTruck = TruckTransitEntity(
                                            op.PalletSerialNumber,
                                            op.lastDetectTime,
                                            op.source,
                                            op.User,
                                            MainViewModel.DROP_OFF_TYPE.TRUCK_TRANSIT.type,
                                            op.ForkliftSerialNumber,
                                            op.truck_plate,
                                            op.location,
                                            op.image
                                        )
                                        var res = repository.dropOffInternalTruck(transitTruck)
                                        //delay(DELAY)
                                        if (!res?.response?.isNullOrEmpty()!!) {
                                            op.pushed = true
                                            repository.dropOffDAO().update(op)
                                        }
                                    }
                                }
                                MainViewModel.DROP_OFF_TYPE.SHIPPING_TRUCK.type -> {
                                    GlobalScope.async(Dispatchers.IO) {
                                        var transitTruck = TruckShippingEntity(
                                            op.PalletSerialNumber,
                                            op.lastDetectTime,
                                            op.source,
                                            op.User,
                                            MainViewModel.DROP_OFF_TYPE.SHIPPING_TRUCK.type,
                                            op.ForkliftSerialNumber,
                                            op.location,
                                            op.image
                                        )
                                        var res = repository.dropOffExternal(transitTruck)
                                        //delay(DELAY)
                                        if (!res?.response?.isNullOrEmpty()!!) {
                                            op.pushed = true
                                            repository.dropOffDAO().update(op)
                                        }
                                    }
                                }
                            }

                        } catch (ex: Exception) {
                            Log.e("DataSycnRecv", "onReceive: ", ex.cause)
                            FirebaseCrashlytics.getInstance().recordException(ex)
                        }
                    }


                }
            }


        }


        GlobalScope.async (Dispatchers.IO) {
            var listOfPushed = repository.dropOffDAO().getAllPushed()

            for (item in listOfPushed)
                if (!item.lastDetectTime.isNullOrEmpty() && notTodayEntry(item.lastDetectTime)){
                    repository.dropOffDAO().delete(item)
                    Log.i("DelItem", "Item Deleted from the DB its ${getDaysOld(item.lastDetectTime)} days Old")
                }
        }

    }

    private fun notTodayEntry(timeInMillis:String):Boolean{
        var daysOld = (System.currentTimeMillis() - timeInMillis.toLong()) / DAY_IN_MILLISECONDS
        return daysOld >= 1
    }

    private fun getDaysOld(timeInMillis:String):Int{
        return ((System.currentTimeMillis() - timeInMillis.toLong()) / DAY_IN_MILLISECONDS).toInt()

    }

    fun isMidNight(): Boolean {
        val start = 23 // let's take your failing example: 21-07
        val midNightCal = Calendar.getInstance()
        midNightCal[Calendar.HOUR_OF_DAY] = start
        midNightCal[Calendar.MINUTE] = 59
        midNightCal[Calendar.SECOND] = 0
        midNightCal[Calendar.MILLISECOND] = 0

        val curCal = Calendar.getInstance()
        curCal.timeInMillis = System.currentTimeMillis()
        return midNightCal.before(curCal)
    }
}