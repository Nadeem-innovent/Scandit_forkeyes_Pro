package com.forkeye.invo.ui.map

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.forkeye.invo.data.local.db.entities.RouteEntity
import com.forkeye.invo.data.remote.response.Response
import com.forkeye.invo.data.local.db.entities.SaerchPallet
import com.forkeye.invo.data.remote.response.PalletSearchResponse
import com.forkeye.invo.ui.base.BaseViewModel
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.lang.Exception

class MapViewModel(
        var context: Context
) : BaseViewModel() {


    private val _palletResult = MutableLiveData< List<PalletSearchResponse>>()
    val palletSearchResult: LiveData< List<PalletSearchResponse>>
        get() = _palletResult

    val routeSearchResult = ArrayList<RouteEntity>()


    private var viewModelJob = Job()
    private val coroutineScope = CoroutineScope(viewModelJob + Dispatchers.Main)


    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }

    fun insertRoutes(routeEntity: List<RouteEntity>){
        val userCount = repository.getRouteDAO().insert(routeEntity)
        Log.i("DB Test", "performLogin: $userCount")
    }

    fun searchPallet(palletSrNumber:String){
        coroutineScope.launch(Dispatchers.IO) {
            try {
                var searchPallet = SaerchPallet(palletSrNumber )
                _palletResult.postValue(repository.searchPallet(searchPallet))
//                delay(300)
                //var palletResp = PalletSearchResponse("12331028409","material", "batch", "55.785778;25.683535;0.0","time")
//                var respList = ArrayList<PalletSearchResponse>()
//                respList.add(palletResp)
//                _palletResult.postValue(respList)
            }catch (ex:Exception){
                _palletResult.postValue(null)
                Log.e("Exception", "performLogin:", ex.cause )
            }
        }
    }

    fun getAllRoutes(): List<RouteEntity> {
        return repository.getRouteDAO().getAllPoint()
    }

    fun getAllRoutesCount(): Int {
        return repository.getRouteDAO().getCount()
    }

    fun clearAllRoute() {
        return repository.getRouteDAO().deleteAll()
    }

    fun getRouteStartPoint(): RouteEntity {
        return repository.getRouteDAO().getRoutePointNearestToCurrent()
    }

    fun getRouteEndPoint(): RouteEntity {
        return repository.getRouteDAO().getRoutePointNearestToEnd()
    }

    fun getRouteByName(routeName:String): List<RouteEntity> {
        return repository.getRouteDAO().getRouteFullRouteByName(routeName)
    }


}