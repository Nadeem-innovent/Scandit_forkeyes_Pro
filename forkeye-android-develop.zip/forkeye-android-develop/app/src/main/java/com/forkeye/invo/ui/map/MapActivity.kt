package com.forkeye.invo.ui.map

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.forkeye.invo.R
import com.forkeye.invo.data.local.db.entities.RouteEntity
import com.forkeye.invo.ui.base.BaseActivity
import com.forkeye.invo.ui.dialog.ConfirmationDialog
import com.forkeye.invo.utils.LocationUtils
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import kotlinx.android.synthetic.main.fragment_maps.*
import mumayank.com.airlocationlibrary.AirLocation
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.io.*
import java.lang.RuntimeException
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class MapActivity : BaseActivity() {
    private val DEFAULT_ZOOM: Float = 16f
    private var btnOpen: Button? = null
    private var pts = ArrayList<LatLng>()
    private var ptsNew = ArrayList<RouteEntity>()
    private var nodeHashMap = HashMap<String, Node>()
    private val paths = ArrayList<ArrayList<LatLng>>()
    private var minDistance = 0.0
    private var mapFragment: MapsFragment? = null
    private var switchSatellite: Switch? = null
    private var plantNoEdt: EditText? = null

    private var srNumTv: TextView? = null
    private var materialTv: TextView? = null
    private var batchTv: TextView? = null
    private var processTimeTv: TextView? = null


    //private var edtLongitude: EditText? = null
    private var currentLocation: Location? = null
    private var endLocation: Location? = null

    val mapViewModel by viewModel<MapViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)
        btnOpen = findViewById(R.id.btn_open)
        switchSatellite = findViewById(R.id.switch_satellite)
        plantNoEdt = findViewById(R.id.pallettNoEdt)
        srNumTv = findViewById(R.id.srNumTv)
        materialTv = findViewById(R.id.materialTv)
        batchTv = findViewById(R.id.batchTv)
        processTimeTv = findViewById(R.id.processTimeTv)

        findViewById<ImageView>(R.id.back).setOnClickListener {
            onBackPressed()
        }


        //edtLongitude = findViewById(R.id.edt_longitude)
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ), REQUEST_PERMISSION
            )
            return
        }

        mapViewModel.palletSearchResult.observe(this, androidx.lifecycle.Observer {
            hideProgress()
            if (it == null) {
                Toast.makeText(this, "Network communication failed!", Toast.LENGTH_LONG).show()
            } else {
                if (!it.isNullOrEmpty()) {
                    var locObj = it.get(0)
                    srNumTv?.setText(locObj.serialNumber)
                    materialTv?.setText(locObj.Material)
                    batchTv?.setText(locObj.Batch)
                    processTimeTv?.setText(locObj.ProcessTime)
                    //TODO pass the end location here
                    if (!locObj.location.isNullOrEmpty()) {
                        var locArr = locObj.location?.split(";")
                        var lat = locArr?.get(1)
                        var lng = locArr?.get(0)
                        endLocation = Location("")
                        endLocation?.latitude = lat!!.toDouble()
                        endLocation?.longitude = lng!!.toDouble()

//                        currentLocation?.latitude = 25.683178
//                        currentLocation?.longitude =  55.787142
//                        endLocation?.latitude =   25.685568
//                        endLocation?.longitude = 55.786366

                        if (LocationUtils.isLocationInRAK(endLocation!!.latitude, endLocation!!.longitude)){
                            calculateMinDistance3()
                        }else{
                            Toast.makeText(applicationContext, "Your Location is not in RAK", Toast.LENGTH_LONG).show()
                        }

                    } else {
                        showAlert("Location not found on server!")
                    }
                }
            }
        })

//        if (mapViewModel.getAllRoutesCount() <= 0) {
//            openRoute(null)
//        }
        initFragment()
        openRoute(null)
    }



    private fun initFragment() {
        mapFragment = MapsFragment()
        mapFragment?.setMapInterface(object : MapsFragment.MapInterface {
            override fun onMapReady() {
                currentLocation?.let {
                    if (LocationUtils.isLocationInRAK(it.latitude, it.longitude)){
                        mapFragment?.showUserLocation(currentLocation, 16F)
                    }else
                        Toast.makeText(applicationContext, "Your Location is not in RAK", Toast.LENGTH_LONG).show()
                }
            }
        })
        supportFragmentManager
            .beginTransaction()
            .add(R.id.container, mapFragment!!)
            .commit()
        btnOpen!!.setOnClickListener(View.OnClickListener {
            if (plantNoEdt!!.text.toString().isEmpty()) {
                Toast.makeText(this, "Please input end point location", Toast.LENGTH_SHORT).show()
                return@OnClickListener
            }
            if (currentLocation == null) {
                Toast.makeText(this, "Turn on your location", Toast.LENGTH_SHORT).show()
                return@OnClickListener
            }

            showProgress()
            mapViewModel.searchPallet(plantNoEdt?.text.toString())
        })

        switchSatellite!!.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                mapFragment!!.setMapType(GoogleMap.MAP_TYPE_SATELLITE)
            } else {
                mapFragment!!.setMapType(GoogleMap.MAP_TYPE_NORMAL)
            }
        }

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        airLocation.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            airLocation.onActivityResult(requestCode, resultCode, data)
            return
        } else {
            val returnUri = data!!.data
            openRoute(returnUri)
        }
    }

    private fun openRoute(returnUri: Uri?) {
        try {
            mapViewModel.clearAllRoute()
            val geoObject = JSONObject(readFileFromRaw(R.raw.ware_house_one_geo))
            val features = geoObject.getJSONArray("features")
            if (features.length() > 0) {
                for (j in 0 until features.length()) {
                    val feature = features.getJSONObject(j)
                    val geometry = feature.getJSONObject("geometry")
                    val coordinatesParent = geometry.getJSONArray("coordinates")
                    val properties = feature.getJSONObject("properties")
                    val roadName = properties.getString("ROAD_NAME")
                    pts = ArrayList()
                    ptsNew = ArrayList()

                    for (i in 0 until coordinatesParent.length()) {
                        val itemArray = JSONArray(coordinatesParent.getString(i))
//                        val id = itemArray.getInt(0)
//                        val nextNodeIds = itemArray.getString(1)
//                        val siblingNodeList = ArrayList<String>()
//                        if (nextNodeIds.contains(",")) {
//                            val idArr = nextNodeIds.split(",")
//                            idArr.forEach { siblingNodeList.add(roadName + "," + it) }
//                        } else {
//                            siblingNodeList.add(roadName + "," + nextNodeIds)
//                        }
//
//                        val crossRoadNodeKey = itemArray.getString(2)
//                        val lat = itemArray.getDouble(3)
//                        val lng = itemArray.getDouble(4)


                        //nodeHashMap.put(roadName + "," + id, Node(lat, lng, id, siblingNodeList, crossRoadNodeKey, roadName))

                        //val geoPoint = LatLng(java.lang.Double.valueOf(itemArray.getDouble(0)), java.lang.Double.valueOf(itemArray.getDouble(1)))
                        //pts.add(geoPoint)
                        //pointsMap.put(calculateDistanceBetweenGeoPoints(geoPoint.latitude, geoPoint.longitude, endLocation!!.latitude, endLocation!!.longitude), geoPoint)
                        ptsNew.add(
                            RouteEntity(
                                0,
                                itemArray.getInt(0),
                                itemArray.getDouble(3),
                                itemArray.getDouble(4),
                                roadName,
                                0.0,
                                0.0
                            )
                        )

                    }

                    mapViewModel.insertRoutes(ptsNew)
                    // [6,-1,"", 25.681687, 55.787090]
                    //[2,3,"", 25.685252, 55.788646],
//                    val srcNode = Node(25.681687, 55.787090,6, -1, "")
//                    val dstNode = Node( 25.685252, 55.788646,2, 3, "")


                    //paths.add(pts)
                }

//                nodeHashMap.forEach { (key, node) ->
//                    if (!node.siblingNodeArr.isNullOrEmpty()) {
//                        node.siblingNodeArr.forEach {
//                            node.addSiblingNode(nodeHashMap.get(it)!!)
//                        }
//                    }
//                    if (!node.crossRoadNodeKey.isNullOrEmpty())
//                        node.addSiblingNode(nodeHashMap.get(node.crossRoadNodeKey)!!)
//                }

            }
        } catch (ex: JSONException) {
            ex.printStackTrace()
        }
    }

    fun readFileFromRaw(resourceId: Int): String? {

        var result: String? = null
        try {

            val inputStream = this.resources.openRawResource(resourceId)
            result = inputStream.bufferedReader().use { it.readText() }

        } catch (e: IOException) {
            Log.e("ERROR", e.localizedMessage)
        }

        return result
    }

    var pointsMap = HashMap<Double, LatLng>()

    private fun calculateMinDistance() {
        val recommendedRoutes = ArrayList<ArrayList<LatLng>>()
        minDistance = 0.0
        if (endLocation == null)
            return
        val endLatitude = endLocation?.latitude!!
        val endLongitude = endLocation?.longitude!!
        var routeIndex = 0
        var pointIndex = 0
        for (i in paths.indices) {
            val points = paths[i]
            val startPoint = points[0]
            val endPoint = points[points.size - 1]
            if ( /*calculateDistanceBetweenGeoPoints(currentLocation.getLatitude(), currentLocation.getLongitude(), startPoint.latitude, startPoint.longitude) <= 2 && */
                calculateDistanceBetweenGeoPoints(
                    endLatitude,
                    endLongitude,
                    endPoint.latitude,
                    endPoint.longitude
                ) <= 2
            ) {
                recommendedRoutes.add(points)
            }
        }
        if (recommendedRoutes.size == 0) {
            Toast.makeText(this, "No Recommended Route", Toast.LENGTH_SHORT).show()
            return
        }
        for (i in recommendedRoutes.indices) {
            var distance = 0.0
            val points = recommendedRoutes[i]
            for (j in points.indices) {
                val point1 = points[j]
                //LatLng point2 = points.get(j + 1);
                distance =
                    calculateDistanceBetweenGeoPoints(point1.latitude, point1.longitude, currentLocation!!.latitude, currentLocation!!.longitude)
                Log.v("Distance", distance.toString() + "km")
                if (minDistance == 0.0) {
                    minDistance = distance
                    routeIndex = i
                    pointIndex = j
                } else {
                    if (minDistance > distance) {
                        minDistance = distance
                        routeIndex = i
                        pointIndex = j
                    }
                }
            }
        }
        Log.v("Index", "$routeIndex,$pointIndex")
        val nearestRoute = recommendedRoutes[routeIndex]
        val shortestRoute = ArrayList<LatLng>()
        val currentPoint = LatLng(currentLocation!!.latitude, currentLocation!!.longitude)
        shortestRoute.add(currentPoint)
        for (i in pointIndex until nearestRoute.size) {
            shortestRoute.add(nearestRoute[i])
        }
        val destinationPoint = LatLng(endLatitude, endLongitude)
        shortestRoute.add(destinationPoint)
        mapFragment!!.redrawMap(shortestRoute)

        //Toast.makeText(MainActivity.this, String.format("%.2f km", minDistance), Toast.LENGTH_SHORT).show();
    }

    //067160026

    private fun calculateMinDistance2() {
        val recommendedRoutes = ArrayList<ArrayList<LatLng>>()

        mapViewModel.getAllRoutes()

        //val nearestRoute = recommendedRoutes[routeIndex]
        val distFromCurrentLoc = calculateDistanceBetweenGeoPoints(
            currentLocation!!.latitude,
            currentLocation!!.longitude,
            endLocation!!.latitude,
            endLocation!!.longitude
        )
        val shortestRoute = ArrayList<LatLng>()
        val currentPoint = LatLng(currentLocation!!.latitude, currentLocation!!.longitude)
        shortestRoute.add(currentPoint)
        pointsMap.forEach { k, v -> if (k < distFromCurrentLoc) shortestRoute.add(v) }
//        for (i in pointIndex until nearestRoute.size) {
//            shortestRoute.add(nearestRoute[i])
//        }
        val destinationPoint = LatLng(endLocation!!.latitude, endLocation!!.longitude)
        shortestRoute.add(destinationPoint)
        mapFragment!!.redrawMap(shortestRoute)

        //Toast.makeText(MainActivity.this, String.format("%.2f km", minDistance), Toast.LENGTH_SHORT).show();
    }

    private fun drawShortestPath() {
        var srcNode: Node? = nodeHashMap.get("R1,1")
        var dstNode: Node? = nodeHashMap.get("R1,1")
        nodeHashMap.forEach { (key, value) ->
            value.disFromSrc = calculateDistanceBetweenGeoPoints(
                currentLocation!!.latitude,
                currentLocation!!.longitude,
                value.latLng!!.latitude,
                value.latLng!!.longitude
            )
            value.disFromDest =
                calculateDistanceBetweenGeoPoints(endLocation!!.latitude, endLocation!!.longitude, value.latLng!!.latitude, value.latLng!!.longitude)

            if (value.disFromSrc < srcNode!!.disFromSrc)
                srcNode = value
            if (value.disFromDest < dstNode!!.disFromDest)
                dstNode = value
        }

        val shortestPath: List<Node> = getDirections(srcNode!!, dstNode!!)
        val finalPath = ArrayList<LatLng>()

        for (node in shortestPath) {
            Log.d("Node", "ID: ${node.nodeId} Road: ${node.roadName}")
            finalPath.add(node.latLng!!)
        }
        //finalPath.add(LatLng(endLocation!!.latitude, endLocation!!.longitude) )
        mapFragment!!.redrawMap(finalPath)
    }

    private fun calculateMinDistance3() {
        val recommendedRoutes = ArrayList<ArrayList<LatLng>>()

        var routePointList = mapViewModel.getAllRoutes()
        routePointList.let {
            it.forEach {
                it.distFromCurLoc =
                    calculateDistanceBetweenGeoPoints(currentLocation!!.latitude, currentLocation!!.longitude, it.latitude, it.longitude)
                it.distFromEndLoc = calculateDistanceBetweenGeoPoints(
                    endLocation!!.latitude, endLocation!!.longitude, it.latitude, it.longitude
                )
            }
        }

        mapViewModel.clearAllRoute()
        mapViewModel.insertRoutes(routePointList)


        val startPoint = mapViewModel.getRouteStartPoint()
        val endPoint = mapViewModel.getRouteEndPoint()


        Log.d("Node", "Start: Road ${startPoint.trackName} Id ${startPoint.pointId}")
        Log.d("Node", "End: Road ${endPoint.trackName} Id ${endPoint.pointId}")

        val shortestRoute = ArrayList<LatLng>()

        val currentPoint = LatLng(currentLocation!!.latitude, currentLocation!!.longitude)
        //shortestRoute.add(currentPoint)

        val destinationPoint = LatLng(endLocation!!.latitude, endLocation!!.longitude)
        //shortestRoute.add(LatLng(startPoint.latitude, endPoint.longitude))


        var startTrack = mapViewModel.getRouteByName(startPoint.trackName)
        var endTrack = mapViewModel.getRouteByName(endPoint.trackName)

        // start and end on the same road
        if (startPoint.trackName.equals(endPoint.trackName)) {
            var startIndex = Math.min(startPoint.pointId, endPoint.pointId)
            var endIndex = Math.max(startPoint.pointId, endPoint.pointId)
            var pointList = ArrayList<LatLng>()
            for (p in startIndex..endIndex - 2) {
                pointList.add(LatLng(endTrack.get(p).latitude, endTrack.get(p).longitude))
                Log.d("Node", "Road ${endTrack[p].trackName} Id ${endTrack[p].pointId}")
            }

            if (startPoint.pointId > endPoint.pointId){
                pointList.reverse()
            }
            shortestRoute.addAll(pointList)
        }

        // start on one road and end on other road
        else if (startPoint.trackName.equals("R1") || endPoint.trackName.equals("R1")) {
            //start is not on road 1
            if (!startPoint.trackName.equals("R1")) {
                //add all point till road 1
                for (i in startPoint.pointId - 1 downTo 0) {
                    shortestRoute.add(LatLng(startTrack[i].latitude, startTrack[i].longitude))
                    Log.d("Node", "Road ${startTrack[i].trackName} Id ${startTrack[i].pointId}")
                }

                var cutOfPoint = getEndCutPointId(startPoint.trackName)

                var startIndex = Math.min(cutOfPoint, endPoint.pointId)
                var endIndex = Math.max(cutOfPoint, endPoint.pointId)
                var pointList = ArrayList<LatLng>()
                for (p in startIndex..endIndex - 2) {
                    pointList.add(LatLng(endTrack.get(p).latitude, endTrack.get(p).longitude))
                    Log.d("Node", "Road ${endTrack[p].trackName} Id ${endTrack[p].pointId}")
                }

                if ((startPoint.trackName.equals("R4"))) {
                    pointList.reverse()
                } else if (endPoint.pointId <= cutOfPoint) {
                    pointList.reverse()
                }


                shortestRoute.addAll(pointList)

                //No Handle the point on Road 1
                //road1PointHandlingCase2(endPoint, getEndCutPointId(startPoint.trackName), endTrack, shortestRoute)
            } else {

                for (i in endPoint.pointId - 1 downTo 0) {
                    shortestRoute.add(LatLng(endTrack[i].latitude, endTrack[i].longitude))
                    Log.d("Node", "Road ${endTrack[i].trackName} Id ${endTrack[i].pointId}")
                }

                var cutOfPoint = getEndCutPointId(endPoint.trackName)

                var startIndex = Math.min(cutOfPoint, startPoint.pointId)
                var endIndex = Math.max(cutOfPoint, startPoint.pointId)
                var pointList = ArrayList<LatLng>()
                for (p in startIndex..endIndex - 2) {
                    pointList.add(LatLng(startTrack.get(p).latitude, startTrack.get(p).longitude))
                    Log.d("Node", "Road ${startTrack[p].trackName} Id ${startTrack[p].pointId}")
                }

                if ((endPoint.trackName.equals("R4"))) {
                    pointList.reverse()
                } else if (startPoint.pointId <= cutOfPoint) {
                    pointList.reverse()
                }

                shortestRoute.addAll(pointList)

            }
        } else if (!startPoint.trackName.equals("R1") && !endPoint.trackName.equals("R1")) {
            //add all point till road 1
            for (i in startPoint.pointId - 1 downTo 0) {
                shortestRoute.add(LatLng(startTrack[i].latitude, startTrack[i].longitude))
                Log.d("Node", "Road ${startTrack[i].trackName} Id ${startTrack[i].pointId}")
            }

            var startTrackCutOfPoint = getEndCutPointId(startPoint.trackName)
            var endTrackCutOfPoint = getEndCutPointId(endPoint.trackName)

            var startIndex = Math.min(startTrackCutOfPoint, endTrackCutOfPoint)
            var endIndex = Math.max(startTrackCutOfPoint, endTrackCutOfPoint)
            var pointList = ArrayList<LatLng>()

            var trackR1 = mapViewModel.getRouteByName("R1")
            for (p in startIndex..endIndex -1) {
                pointList.add(LatLng(trackR1.get(p).latitude, trackR1.get(p).longitude))
                Log.d("Node", "Road ${trackR1[p].trackName} Id ${trackR1[p].pointId}")
            }

            if (startTrackCutOfPoint > endTrackCutOfPoint) {
                pointList.reverse()
            }

            shortestRoute.addAll(pointList)

            for (i in 0 until endPoint.pointId) {
                shortestRoute.add(LatLng(endTrack[i].latitude, endTrack[i].longitude))
                Log.d("Node", "Road ${endTrack[i].trackName} Id ${endTrack[i].pointId}")
            }

            //No Handle the point on Road 1
            //road1PointHandlingCase2(endPoint, getEndCutPointId(startPoint.trackName), endTrack, shortestRoute)
        }

        //shortestRoute.add(destinationPoint)


        mapFragment!!.redrawMap(shortestRoute)

    }

    private fun findShortestPath() {

//        val node0 = Node(0)
//
//        val node1 = Node(1)
//        val node2 = Node(2)
//        node0.addSiblingNode(node1)
//        node0.addSiblingNode(node2)
//
//        val node3 = Node(3)
//        node2.addSiblingNode(node3)
//
//        val node4 = Node(4)
//        node3.addSiblingNode(node4)
//
//        val node5 = Node(5)
//        val node6 = Node(6)
//        node4.addSiblingNode(node5)
//        node4.addSiblingNode(node6)

//        val shortestPath: List<Node> = getDirections(node0, node6)
//        for (node in shortestPath) {
//            Log.d("Node",""+node.getValue())
//        }
    }


    fun getDirections(sourceNode: Node, destinationNode: Node?): List<Node> {
        // Initialization.
        val nextNodeMap: MutableMap<Node, Node> = HashMap()
        var currentNode = sourceNode
        var previousNode = sourceNode

        // Queue
        val queue: Queue<Node> = LinkedList()
        queue.add(currentNode)

        /*
         * The set of visited nodes doesn't have to be a Map, and, since order
         * is not important, an ordered collection is not needed. HashSet is
         * fast for add and lookup, if configured properly.
         */
        val visitedNodes: MutableSet<Node> = HashSet()
        visitedNodes.add(currentNode)

        //Search.
        while (!queue.isEmpty()) {
            currentNode = queue.remove()
            if (currentNode.equals(destinationNode)) {
                // Handle case where the node leading to the destinatino node
                // itself pointed to multiple nodes. In this case,
                // nextNodeMap is incorrect and we need to rely on the previously
                // seen node.
                // Also need to check for edge-case of start node == end node.
                if (!previousNode.equals(currentNode)) {
                    nextNodeMap[previousNode] = currentNode
                }
                break
            } else {
                for (nextNode in currentNode.getSiblingNodes()!!) {
                    if (!visitedNodes.contains(nextNode)) {
                        if (nextNode.roadName.equals("R1")
                            || nextNode.roadName.equals(sourceNode.roadName)
                            || nextNode.roadName.equals(destinationNode?.roadName)
                        ) {

                        }
                        queue.add(nextNode)
                        visitedNodes.add(nextNode)
                        // Look up of next node instead of previous.
                        nextNodeMap[currentNode] = nextNode
                        previousNode = currentNode
                    }
                }
            }
        }

        // If all nodes are explored and the destination node hasn't been found.
        if (!currentNode.equals(destinationNode)) {
            throw RuntimeException("No feasible path.")
        }

        // Reconstruct path. No need to reverse.
        val directions: MutableList<Node> = LinkedList()
        var node: Node? = sourceNode
        while (node != null) {
            directions.add(node)
            node = nextNodeMap[node]
        }
        return directions
    }

    private fun road1PointHandlingCase2(
        startPoint: RouteEntity,
        cutOfPoint: Int,
        track: List<RouteEntity>,
        shortestRoute: ArrayList<LatLng>
    ) {
        if (startPoint.pointId < cutOfPoint) {
            for (p in startPoint.pointId..cutOfPoint - 1) {
                shortestRoute.add(LatLng(track.get(p).latitude, track.get(p).longitude))
            }
        } else {
            for (p in track) {
                for (p in cutOfPoint..startPoint.pointId - 1) {
                    shortestRoute.add(LatLng(track.get(p).latitude, track.get(p).longitude))
                }
            }
        }
    }



    private fun addValidTrackPointCase2(
        track: List<RouteEntity>,
        startPoint: RouteEntity,
        endPoint: RouteEntity,
        shortestRoute: ArrayList<LatLng>
    ) {
        for (p in track) {
            if (p.pointId <= endPoint.pointId)
                shortestRoute.add(LatLng(p.latitude, p.longitude))
        }
    }

    private fun calculateDistanceBetweenGeoPoints(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val theta = lon1 - lon2
        var dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta))
        dist = Math.acos(dist)
        dist = rad2deg(dist)
        dist = dist * 60 * 1.1515
        dist = dist * 1.609344 // Distance to km
        return dist / 1000 // to meter
    }

    private fun deg2rad(deg: Double): Double {
        return deg * Math.PI / 180.0
    }

    private fun rad2deg(rad: Double): Double {
        return rad * 180.0 / Math.PI
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSION) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                airLocation.onRequestPermissionsResult(requestCode, permissions, grantResults) // ADD THIS LINE INSIDE onRequestPermissionResult
                initFragment()
            }
        }
    }

    private val airLocation = AirLocation(this, object : AirLocation.Callback {

        override fun onSuccess(locations: ArrayList<Location>) {
            locations?.let {
                if (it.size > 0) {
                    currentLocation = it.get(0)

                    var locStr = currentLocation?.latitude.toString() + "," + currentLocation?.longitude.toString()
                    Log.v("Location", locStr)
                    mapFragment?.getZoomLevel()?.let {
                        if (it < DEFAULT_ZOOM)
                            mapFragment?.showUserLocation(currentLocation, DEFAULT_ZOOM)
                    }
                }
            }
        }

        override fun onFailure(locationFailedEnum: AirLocation.LocationFailedEnum) {
            // do something
            // the reason for failure is given in locationFailedEnum
        }

    })

    override fun onBackPressed() {
        ConfirmationDialog.newInstance("Are you sure. You want to Exit?", null, object : ConfirmationDialog.DialogClickListener {
            override fun onSelectionDone(exit: Boolean) {
                if (exit)
                    finish()
            }
        }).show(supportFragmentManager, "ConfirmationDialog")
    }

    fun getEndCutPointId(roadName: String): Int {
        return when (roadName) {
            "R1" -> 0
            "R2" -> 49
            "R3" -> 71
            "R4" -> 0
            else -> 0
        }
    }


    companion object {
        private const val REQUEST_PERMISSION = 100
    }
}