package com.forkeye.invo.ui.login

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.forkeye.invo.R
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils
import com.forkeye.invo.data.remote.NetworkHelper
import com.forkeye.invo.ui.*
import com.forkeye.invo.ui.barcode.BarcodeScannerActivity
import com.forkeye.invo.ui.base.BaseActivity
import com.forkeye.invo.ui.base.BaseFragment
import com.google.android.gms.vision.CameraSource
import com.permissionx.guolindev.PermissionX
import org.koin.androidx.viewmodel.ext.android.viewModel


class LoginFragment : BaseFragment() {


    val loginViewModel by viewModel<LoginViewModel>()
    var userName: TextView? = null
    var password: TextView? = null
    var langSpinner: Spinner? = null
    var langSelected: String? = null
    var langLayout: LinearLayout? = null
    var btnAdminLogin: Button? = null
    var loginScanBtn:LinearLayout? = null
    var backBtn:ImageView? = null
    var appTitleTxt:TextView? = null

    private var isAdminLogin = false


    companion object {

        @JvmStatic
        fun getInstance(adminLogin: Boolean): LoginFragment {
            var instance = LoginFragment()
            instance.isAdminLogin = adminLogin
            return instance
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.login_fragment, container, false)
        userName = view.findViewById<TextView>(R.id.et_username)
        password = view.findViewById<TextView>(R.id.et_password)
        langSpinner = view.findViewById(R.id.lang_spinner)
        langLayout = view.findViewById(R.id.langLayout)
        btnAdminLogin = view.findViewById(R.id.bt_admin_login)
        backBtn = view.findViewById(R.id.back)
        appTitleTxt = view.findViewById(R.id.appTitleTxt)

        loginScanBtn = view.findViewById<LinearLayout>(R.id.ll_scan)

        setupLangView()

        loginScanBtn?.setOnClickListener {

            if (userName?.text.toString().isNullOrEmpty() && password?.text.toString().isNullOrEmpty()) {
                checkPermission()
            } else {
                loginViewModel.performLogin(userName?.text.toString(), password?.text.toString())
            }
        }

        backBtn?.setOnClickListener {
            activity?.finish()
        }

        btnAdminLogin?.setOnClickListener {
            if (!userName?.text.toString().isNullOrEmpty()
                && userName?.text.toString().equals("admin", true)
                && !password?.text.toString().isNullOrEmpty()
                && password?.text.toString().equals("123456")
            ) {
                startSettingActivity()
            } else {
                Toast.makeText(context, context?.getString(R.string.login_failed), Toast.LENGTH_SHORT).show()
            }
        }

        loginViewModel.loginResult.observe(viewLifecycleOwner, androidx.lifecycle.Observer {
            hideProgress()
            Log.i("TAG", "onCreateView: ${it?.response}")
            if (it == null) {
                Toast.makeText(context, context?.getString(R.string.no_network), Toast.LENGTH_LONG).show()
            } else {
                if (it.response.equals("true") && !it.FirstName.isNullOrEmpty() && !it.LastName.isNullOrEmpty()){
                    PrefUtils.saveToPrefs(context, PrefKeys.USER_NAME, it.FirstName + " " + it.LastName)
                    var result = it.response.equals("true")
                    result?.let { it ->
                        if (it) {
                            PrefUtils.saveToPrefs(context, PrefKeys.USER_LOG_IN, it)

                            if (it) {
                                if (!(PrefUtils.getFromPrefs(context, PrefKeys.FORK_REG, false) as Boolean)) {
                                    showFragment(RegForkFragment.getInstance())
                                } else {
                                    startMainActivity()
                                }

                            } else {
                                Toast.makeText(context, context?.getString(R.string.login_failed), Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }else{
                    Toast.makeText(context, context?.getString(R.string.login_failed), Toast.LENGTH_SHORT).show()
                }
            }
        })


        return view
    }

    private fun startMainActivity() {
        startActivity(MainActivity::class.java)
        activity?.finish()
    }

    private fun startSettingActivity() {
        startActivity(SettingActivity::class.java)
        activity?.finish()
    }

    private fun setupLangView() {
        langSelected = PrefUtils.getFromPrefs(context, PrefKeys.LANGUAGE_PREF, "en") as String
        langSpinner?.setSelection(getLangPosition(langSelected!!))
        setupClickListeners()

        backBtn?.visibility = View.GONE
        langLayout?.visibility = View.VISIBLE
        appTitleTxt?.visibility = View.VISIBLE

        if (isAdminLogin) {
            langLayout?.visibility = View.GONE
            loginScanBtn?.visibility = View.GONE
            btnAdminLogin?.visibility = View.VISIBLE
            appTitleTxt?.visibility = View.GONE
            backBtn?.visibility = View.VISIBLE
        }
    }

    private fun getLangPosition(lang: String): Int {
        when (lang) {
            "en" -> {
                return 0
            }
            "ar" -> {
                return 1
            }
            "ur" -> {
                return 2
            }
            "hi" -> {
                return 3
            }
        }
        return 0
    }

    private fun setupClickListeners() {

        langSpinner?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                when (position) {
                    0 -> {
                        langSelected = "en"
                    }
                    1 -> {
                        langSelected = "ar"
                    }
                    2 -> {
                        langSelected = "ur"
                    }
                    3 -> {
                        langSelected = "hi"
                    }
                }

                if (langSelected?.equals(PrefUtils.getFromPrefs(context, PrefKeys.LANGUAGE_PREF, "en").toString(), true) != true) {
                    PrefUtils.saveToPrefs(context, PrefKeys.LANGUAGE_PREF, langSelected!!)
                    (activity as SplashActivity)?.setLocale(langSelected)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == BarcodeScannerActivity.BARCODE) {
            var code = data?.extras?.get(BarcodeScannerActivity.BAR_CODE_VAL) as String
            code?.let {
                if (it.contains(":")) {
                    var strArr = it.toString().split(":")
                    Toast.makeText(context, "Code Found $code", Toast.LENGTH_SHORT).show()
                    userName?.text = strArr[0]
                    password?.text = strArr[1]
                    if (NetworkHelper(requireContext()).isNetworkConnected()) {
                        showProgress()
                        loginViewModel.performLogin(userName?.text.toString(), password?.text.toString())
                    } else {
                        Toast.makeText(context, context?.getString(R.string.no_intenet), Toast.LENGTH_LONG).show()
                    }
                } else {
                    showAlert(context?.getString(R.string.qr_code_failed))
                }
            }
        }
    }


    fun checkPermission() {
        var bundle = Bundle()
        bundle.putBoolean(BarcodeScannerActivity.FRONT_FACING_CAM, true)
        var intent = Intent(context, BarcodeScannerActivity::class.java)
        startActivityForResult(
            intent,
            BarcodeScannerActivity.BARCODE,
            bundle
        )
    }

}