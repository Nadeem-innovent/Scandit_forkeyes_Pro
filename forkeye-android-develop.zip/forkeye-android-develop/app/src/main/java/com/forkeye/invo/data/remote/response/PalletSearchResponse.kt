package com.forkeye.invo.data.remote.response

import java.io.Serializable

data class PalletSearchResponse(
    val serialNumber: String?,
    val Material: String?,
    val Batch: String?,
    val location: String?,
    val ProcessTime: String?
) : Serializable
