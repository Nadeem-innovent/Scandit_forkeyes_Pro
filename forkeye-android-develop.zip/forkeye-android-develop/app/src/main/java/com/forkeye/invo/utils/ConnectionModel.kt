package com.forkeye.invo.utils

class ConnectionModel(val type: Type, val isConnected: Boolean) {
     companion object {
        enum class Type {
            WIFI, MOBILE_DATA, NO_CONNECTION
        }
    }

}