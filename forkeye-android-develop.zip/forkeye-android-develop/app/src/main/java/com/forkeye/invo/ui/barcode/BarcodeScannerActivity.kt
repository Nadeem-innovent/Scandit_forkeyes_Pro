package com.forkeye.invo.ui.barcode

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.forkeye.invo.R
import com.forkeye.invo.ui.base.BaseActivity
import com.google.firebase.ml.vision.FirebaseVision
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcode
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcodeDetector
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcodeDetectorOptions
import com.google.firebase.ml.vision.common.FirebaseVisionImage
import com.google.firebase.ml.vision.common.FirebaseVisionImageMetadata
import com.otaliastudios.cameraview.controls.Facing
import com.otaliastudios.cameraview.frame.Frame
import kotlinx.android.synthetic.main.activity_barcode_scanner.*

class BarcodeScannerActivity : BaseActivity() {

    companion   object {
        val BARCODE: Int = 1000
        val BAR_CODE_VAL: String = "barcode"
        val FRONT_FACING_CAM: String = "front_facing_cam"
    }



    private var isQR = false
    private var isFrontFacingCam = false
    private lateinit var barcodeDetectorOptions: FirebaseVisionBarcodeDetectorOptions
    private lateinit var barcodeDetector: FirebaseVisionBarcodeDetector

    var scannerView: ImageView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_barcode_scanner)
        scannerView = findViewById(R.id.scan_view_img)
        if (intent != null && intent.hasExtra(FRONT_FACING_CAM)){
            isFrontFacingCam = intent.getBooleanExtra(FRONT_FACING_CAM, false)
        }

        findViewById<ImageView>(R.id.back).setOnClickListener {
            finish()
        }
        requestPermission()
    }

    fun makeMeBlink(view: View, offset: Long): View? {
        val anim: Animation = AlphaAnimation(0.0f, 1.0f)
        anim.duration = 100L
        anim.startOffset = offset
        anim.setRepeatMode(Animation.REVERSE)
        anim.setRepeatCount(Animation.INFINITE)
        view.startAnimation(anim)
        return view
    }

    override fun onResume() {
        super.onResume()
        scannerView?.let { makeMeBlink(it, 20L) }
    }

    override fun onPause() {
        super.onPause()
        scannerView?.clearAnimation()
    }


    private fun requestPermission() {
        val cameraPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        )
        val recordAudioPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        )
        if (cameraPermission != PackageManager.PERMISSION_GRANTED || recordAudioPermission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO),
                100
            )
        } else {
            showCamera()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            100 -> {
                if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission not granted", Toast.LENGTH_LONG).show()
                } else {
                    showCamera()
                }
            }
        }
    }

    private fun showCamera() {
        barcodeDetectorOptions = FirebaseVisionBarcodeDetectorOptions.Builder()
            .setBarcodeFormats(FirebaseVisionBarcode.FORMAT_ALL_FORMATS)
            .build()
        barcodeDetector = FirebaseVision.getInstance().getVisionBarcodeDetector(barcodeDetectorOptions)
        cameraView.setLifecycleOwner(this)
        if (isFrontFacingCam){
            cameraView.facing = Facing.FRONT
        }
        cameraView.addFrameProcessor { frame -> processImage(getFirebaseVisionImage(frame)) }
    }

    private fun processImage(vision: FirebaseVisionImage) {
        if (!isQR) {
            barcodeDetector.detectInImage(vision)
                .addOnFailureListener {
                        e -> Log.d("Data", e.toString()) }
                .addOnSuccessListener { qrInfo -> process(qrInfo) }
        }
    }

    private fun process(barCodes: List<FirebaseVisionBarcode>) {
        if (barCodes.isNotEmpty()) {
            isQR = true
            //Toast.makeText(this, "BarCode ${barCodes.first().displayValue}", Toast.LENGTH_SHORT).show()
            val intent = Intent()
            intent.putExtra(
                BAR_CODE_VAL,
                barCodes.first().displayValue
            )
            setResult(BARCODE, intent)
            finish()

//            when (barCodes.first().valueType){
//                FirebaseVisionBarcode.TYPE_CONTACT_INFO -> {
//                    val intent = Intent(this, MainActivity::class.java)
//                    intent.putExtra("fromScannerActivity",
//                        true)
//                    intent.putExtra("name",barCodes.
//                    firstOrNull()?.contactInfo?.name?.formattedName ?: "NA")
//                    intent.putExtra("email",barCodes
//                        .firstOrNull()?.contactInfo?.emails?.firstOrNull()?.address ?: "NA")
//                    intent.putExtra("url",barCodes
//                        .firstOrNull()?.contactInfo?.urls?.firstOrNull() ?: "NA")
//                    intent.putExtra("organization",barCodes
//                        .firstOrNull()?.contactInfo?.organization ?: "NA")
//                    intent.putExtra("phoneNo",barCodes
//                        .firstOrNull()?.contactInfo?.phones?.firstOrNull()?.number ?: "NA")
//                    startActivity(intent)
//                    finish()
//
//                }
//            }
        }
    }

    private fun getFirebaseVisionImage(frame: Frame): FirebaseVisionImage {
        val metadata = FirebaseVisionImageMetadata.Builder()
            .setFormat(FirebaseVisionImageMetadata.IMAGE_FORMAT_NV21)
            .setHeight(frame.size.height)
            .setWidth(frame.size.width)
            .build()
        val data: ByteArray = frame.getData()
        return FirebaseVisionImage.fromByteArray(data, metadata)
    }
}
