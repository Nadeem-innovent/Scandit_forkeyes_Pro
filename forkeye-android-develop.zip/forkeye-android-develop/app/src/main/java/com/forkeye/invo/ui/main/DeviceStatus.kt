package com.forkeye.invo.ui.main

enum class DeviceStatus {
    CONNENTING,
    WAITING,
    ERROR,
    STARTING,
    CONNNECTED,
    DISCONECTED,
    LOADED,
    UNLOADED
}