package com.forkeye.invo.data.remote.response

import java.io.Serializable


data class AuthResp (

//	Email = "maher@innovent.me"
//			FirstName = "Maher"
//LastName = "Al Bitar"
//Manager = "Saqib"
//Material = null
//Plant = "MC5"
//ProcessTime = null
//Role = "Warehouse Manager"
//Username = "Admin"
//error = null
//lastDetectTime = null
//location = null
//response = "true"

	val response : String?,
	val Username : String?,
	val FirstName : String?,
	val LastName : String?,
	val Role : String?,
	val Plant : String?,
	val Manager : String?,
	val Email : String?,

):Serializable