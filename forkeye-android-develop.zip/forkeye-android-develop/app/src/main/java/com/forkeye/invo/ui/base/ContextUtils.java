package com.forkeye.invo.ui.base;

import android.content.Context;
import android.content.ContextWrapper;

public class ContextUtils extends ContextWrapper {
    public ContextUtils(Context base) {
        super(base);
    }
}