package com.forkeye.invo.ui.base

import android.app.ProgressDialog
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.res.Resources
import android.os.Build
import android.os.Bundle
import android.os.LocaleList
import android.os.PersistableBundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.forkeye.invo.R
import com.forkeye.invo.ui.SplashActivity
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils
import com.forkeye.invo.ui.dialog.AlertDialog
import com.forkeye.invo.ui.dialog.ConfirmationDialog
import java.lang.Exception
import java.util.*


open class BaseActivity : AppCompatActivity() {

    private var dialog: ProgressDialog? = null

    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onCreate(savedInstanceState, persistentState)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    private fun hideSystemUI() {
        // Enables regular immersive mode.
        // For "lean back" mode, remove SYSTEM_UI_FLAG_IMMERSIVE.
        // Or for "sticky immersive," replace it with SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE
                // Set the content to appear under the system bars so that the
                // content doesn't resize when the system bars hide and show.
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                // Hide the nav bar and status bar
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN)
    }

    // Shows the system bars by removing all the flags
// except for the ones that make the content appear under the system bars.
    private fun showSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }


    open fun showFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()

        transaction.replace(
            R.id.fragmentContainer, fragment
        )
        transaction
            .addToBackStack(null)
            .commit()
    }

    fun <T : AppCompatActivity> startActivity(
        className: Class<T>,
        extras: Bundle? = null,
        finishCurrent: Boolean = false,
        permissions: Array<String>? = null,
        clearStack: Boolean = false
    ) {


        val i = Intent(this, className)

        if (extras != null)
            i.putExtras(extras)

        if (clearStack) {

            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        startActivity(i)

        //overridePendingTransition(R.anim.slide_in_from_right, R.anim.slide_out_from_left)

    }

    fun setLocale(lang: String?) {
//        var myLocale = Locale(lang)
//        val res: Resources = resources
//        val dm: DisplayMetrics = res.getDisplayMetrics()
//        val conf: Configuration = res.getConfiguration()
//        conf.locale = myLocale
//        res.updateConfiguration(conf, dm)
        val refresh = Intent(this, SplashActivity::class.java)
        startActivity(refresh)
        this?.finish()
    }

    override fun attachBaseContext(newBase: Context?) {
        val localeToSwitchTo = Locale(PrefUtils.getFromPrefs(newBase, PrefKeys.LANGUAGE_PREF, "en") as String)
        val localeUpdatedContext: ContextWrapper = updateLocale(newBase!!, localeToSwitchTo)!!
        super.attachBaseContext(localeUpdatedContext)
    }

    open fun updateLocale(context: Context, localeToSwitchTo: Locale?): ContextWrapper? {
        var context: Context = context
        val resources: Resources = context.getResources()
        val configuration = resources.configuration // 1
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val localeList = LocaleList(localeToSwitchTo) // 2
            LocaleList.setDefault(localeList) // 3
            configuration.setLocales(localeList) // 4
        } else {
            configuration.locale = localeToSwitchTo // 5
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            context = context.createConfigurationContext(configuration) // 6
        } else {
            resources.updateConfiguration(configuration, resources.displayMetrics) // 7
        }
        return ContextUtils(context) // 8
    }

    fun showAlert(msg: String?) {
        AlertDialog.newInstance(msg, null, null).show(supportFragmentManager, "ConfirmationDialog")
    }



    fun showProgress() {
        try {
            if (dialog == null){
                dialog = ProgressDialog(this)
                dialog?.setMessage(applicationContext?.getString(R.string.making_network_call))
            }
            if (dialog?.isShowing == false)
                dialog?.show()
        }catch (ex:Exception){
            Log.e("BaseActivity",""+ex.message)
        }

    }

    fun hideProgress(){
        try {
            if (dialog?.isShowing == true)
                dialog?.dismiss()
        }catch (ex:Exception){

        }

    }
}