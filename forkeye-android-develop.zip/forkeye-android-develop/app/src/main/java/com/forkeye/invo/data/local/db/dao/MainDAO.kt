package com.forkeye.invo.data.local.db.dao

import androidx.room.*
import com.forkeye.invo.data.local.db.entities.MainListEntity

@Dao
interface MainDAO {

    companion object {
        const val TABLE_NAME = "MainTable"
        const val ID = "id"
        const val SERVICE_ID = "service_id"
        const val TYPE = "type"
        const val TITLE = "title"

    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: MainListEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(items: ArrayList<MainListEntity>): List<Long>

    @Query("SELECT COUNT(*) from $TABLE_NAME")
    fun getCount(): Int

    @Query("select * from $TABLE_NAME where $TITLE like :text")
    fun search(text: String): List<MainListEntity>

    @Query("delete from $TABLE_NAME")
    fun deleteAll()

    @Delete
    fun delete(item: MainListEntity)

    @Update
    fun update(item: MainListEntity)

    @Update
    fun update(items: List<MainListEntity>)
}