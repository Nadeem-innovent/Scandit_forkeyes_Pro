package com.forkeye.invo.data.remote.entity

data class InsideDropOffEntity (

	val PalletSerialNumber : String,
	val lastDetectTime : String,
	val source : String,
	val User : String,
	val Process : String,
	val ForkliftSerialNumber : String,
	val LocationDetails : String,
	val L5Location : String,
	val MappedZone : String,
	val image : String
)