package com.forkeye.invo.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.lifecycle.viewModelScope
import com.forkeye.invo.R
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils
import com.forkeye.invo.ui.base.BaseActivity
import com.forkeye.invo.ui.login.SplashViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import org.koin.androidx.viewmodel.ext.android.viewModel


class SettingActivity : BaseActivity() {

    val debug = false
    val splashViewModel by viewModel<SplashViewModel>()

    var plantNo:EditText? = null
    var server1_IP:EditText? = null
    var loader_port:EditText? = null
    var server2_IP:EditText? = null
    var location_port:EditText? = null
    var forkLiftId:EditText? = null
    var vizixServerurl:EditText? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        findViewById<ImageView>(R.id.back).setOnClickListener {
            finish()
        }

        plantNo = findViewById(R.id.pallettNoEdt)
        server1_IP = findViewById(R.id.server1_IP)
        loader_port = findViewById(R.id.server1_port)
        server2_IP = findViewById(R.id.server2_IP)
        location_port = findViewById(R.id.server2_port)
        forkLiftId = findViewById(R.id.forkLiftId)
        vizixServerurl = findViewById(R.id.vizixServerUrl)

        plantNo?.let {
           it.setText(PrefUtils.getFromPrefs(applicationContext, PrefKeys.PLANT_NO, "") as String)
        }

        server1_IP?.let {
            it.setText(PrefUtils.getFromPrefs(applicationContext, PrefKeys.SERVER_IP_1, "0.0.0.0") as String)
        }

        loader_port?.let {
            it.setText(PrefUtils.getFromPrefs(applicationContext, PrefKeys.LOADER_SENSOR_PORT, "8976") as String)
        }

        server2_IP?.let {
            it.setText(PrefUtils.getFromPrefs(applicationContext, PrefKeys.SERVER_IP_2, "0.0.0.0") as String)
        }

        location_port?.let {
            it.setText(PrefUtils.getFromPrefs(applicationContext, PrefKeys.LOCATION_SENSOR_PORT, "9000") as String)
        }

        forkLiftId?.let {
            it.setText(PrefUtils.getFromPrefs(applicationContext, PrefKeys.FORK_LIFT_ID, "") as String)
        }

        vizixServerurl?.let {
            it.setText(PrefUtils.getFromPrefs(applicationContext, PrefKeys.VIZIX_SERVER_URL, "https://digitrack.rakceramics.com/innovent/") as String)
        }


        findViewById<Button>(R.id.bt_save).setOnClickListener {
            var updated = false
            if (!plantNo?.text.isNullOrEmpty()
                && plantNo?.text.toString() != (PrefUtils.getFromPrefs(applicationContext, PrefKeys.PLANT_NO, "") as String)){
                updated = true
                PrefUtils.saveToPrefs(applicationContext, PrefKeys.PLANT_NO, plantNo!!.text.toString())
            }
            if (!server1_IP?.text.isNullOrEmpty()
                && server1_IP?.text.toString() != (PrefUtils.getFromPrefs(applicationContext, PrefKeys.SERVER_IP_1, "") as String)){
                updated = true
                PrefUtils.saveToPrefs(applicationContext, PrefKeys.SERVER_IP_1, server1_IP!!.text.toString())
            }
            if (!loader_port?.text.isNullOrEmpty()
                && loader_port?.text.toString() != (PrefUtils.getFromPrefs(applicationContext, PrefKeys.LOADER_SENSOR_PORT, "") as String)){
                updated = true
                PrefUtils.saveToPrefs(applicationContext, PrefKeys.LOADER_SENSOR_PORT, loader_port!!.text.toString())
            }
            if (!server2_IP?.text.isNullOrEmpty()
                && server2_IP?.text.toString() != (PrefUtils.getFromPrefs(applicationContext, PrefKeys.SERVER_IP_2, "") as String)){
                updated = true
                PrefUtils.saveToPrefs(applicationContext, PrefKeys.SERVER_IP_2, server2_IP!!.text.toString())
            }
            if (!location_port?.text.isNullOrEmpty()
                && location_port?.text.toString() != (PrefUtils.getFromPrefs(applicationContext, PrefKeys.LOCATION_SENSOR_PORT, "") as String)){
                updated = true
                PrefUtils.saveToPrefs(applicationContext, PrefKeys.LOCATION_SENSOR_PORT, location_port!!.text.toString())
            }
            if (!forkLiftId?.text.isNullOrEmpty()
                && forkLiftId?.text.toString() != (PrefUtils.getFromPrefs(applicationContext, PrefKeys.FORK_LIFT_ID, "") as String)){
                updated = true
                PrefUtils.saveToPrefs(applicationContext, PrefKeys.FORK_LIFT_ID, forkLiftId!!.text.toString())
            }

            if (!vizixServerurl?.text.isNullOrEmpty()
                && vizixServerurl?.text.toString() != (PrefUtils.getFromPrefs(applicationContext, PrefKeys.VIZIX_SERVER_URL, "http://rak.innovent.site/innovent/") as String)){
                updated = true
                PrefUtils.saveToPrefs(applicationContext, PrefKeys.VIZIX_SERVER_URL, vizixServerurl!!.text.toString())
            }

            if(updated){
                Toast.makeText(this, applicationContext?.getString(R.string.setting_update_msg), Toast.LENGTH_LONG).show()
                triggerRebirth(this)
            }else{
                showAlert(applicationContext?.getString(R.string.not_save))
            }
        }
    }

    fun triggerRebirth(context: Context) {
        val intent = Intent(context, SplashActivity::class.java)
        intent.addFlags(FLAG_ACTIVITY_NEW_TASK)
        //intent.putExtra(KEY_RESTART_INTENT, nextIntent)
        context.startActivity(intent)
        if (context is Activity) {
            (context as Activity).finish()
        }
        Runtime.getRuntime().exit(0)
    }


}