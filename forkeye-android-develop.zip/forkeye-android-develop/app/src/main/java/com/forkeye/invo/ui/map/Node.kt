package com.forkeye.invo.ui.map

import com.google.android.gms.maps.model.LatLng

class Node(lat: Double, lng: Double, nodeId: Int, nextNodeId: ArrayList<String>, crossRoadNodeKey: String, roadName:String) {
    private val value1 = 1
    var latLng: LatLng? = null
    var nodeId = 0
    var siblingNodeArr = ArrayList<String>()
    var crossRoadNodeKey = ""
    var roadName:String = ""
    var disFromSrc:Double = 1000.0
    var disFromDest:Double = 10000.0
    private var siblingNodes: MutableSet<Node>? = null

    init {
        this.latLng = LatLng(lat, lng)
        this.nodeId = nodeId
        this.siblingNodeArr = nextNodeId
        this.crossRoadNodeKey = crossRoadNodeKey
        this.siblingNodes = HashSet()
        this.roadName = roadName
    }

    fun getSiblingNodes(): Set<Node>? {
        return siblingNodes
    }

    fun equals(compareTo: Node): Boolean {
        return compareTo.getValue() == value1
    }

    fun getValue(): Int {
        return value1
    }

    fun addSiblingNode(node: Node) {
        siblingNodes?.add(node)
    }
}
