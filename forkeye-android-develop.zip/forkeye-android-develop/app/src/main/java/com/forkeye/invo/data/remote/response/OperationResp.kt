package com.forkeye.invo.data.remote.response

import java.io.Serializable


data class OperationResp (


	val response : String?,
	val pallet : String?,
	val process : String?

):Serializable