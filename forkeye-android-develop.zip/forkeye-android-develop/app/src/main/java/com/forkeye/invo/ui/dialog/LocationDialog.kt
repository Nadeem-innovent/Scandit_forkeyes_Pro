package com.forkeye.invo.ui.dialog

import android.os.Bundle
import android.view.*
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.forkeye.invo.R
import com.forkeye.invo.ui.login.LocationDialogVM
import org.koin.androidx.viewmodel.ext.android.viewModel


class LocationDialog : DialogFragment() {

    var tvTitle:TextView? = null
    var tvSubTitle:TextView? = null
    var btnPositive: Button? = null
    var btnNegative: Button? = null
    val locationDialogVM by viewModel<LocationDialogVM>()

    var btn1: TextView? = null
    var btn2: TextView? = null
    var btn3: TextView? = null
    var btn4: TextView? = null
    var btn5: TextView? = null
    var btn6: TextView? = null
    var btn7: TextView? = null
    var btn8: TextView? = null

    var btn9: TextView? = null

    var leftRight:String? = null
    var zoneSelected:String = ""


    companion object {

        const val TAG = "SimpleDialog"
        private const val KEY_TITLE = "KEY_TITLE"
        private const val KEY_SUBTITLE = "KEY_SUBTITLE"
        private var listener: DialogClickListener? = null

        fun newInstance(listener: DialogClickListener): LocationDialog {
            val args = Bundle()
            val fragment = LocationDialog()
            fragment.arguments = args
            Companion.listener = listener
            return fragment
        }

    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view =  inflater.inflate(R.layout.dialog_location, container, false)
        tvTitle = view.findViewById(R.id.tvTitle)
        btnPositive = view.findViewById(R.id.btnPositive)
        btnNegative = view.findViewById(R.id.btnNagitive)
        tvSubTitle = view.findViewById(R.id.tvSubTitle)

        btn1 = view.findViewById(R.id.btnOne)
        btn2 = view.findViewById(R.id.btnTwo)
        btn3 = view.findViewById(R.id.btnThree)
        btn4 = view.findViewById(R.id.btnFour)
        btn5 = view.findViewById(R.id.btnFive)
        btn6 = view.findViewById(R.id.btnSix)
        btn7 = view.findViewById(R.id.btnSeven)
        btn8 = view.findViewById(R.id.btn8)
        btn9 = view.findViewById(R.id.btn9)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupView(view)
        setupClickListeners(view)
    }

    private fun setupClickListeners(view: View) {

        btn1?.setOnClickListener { zoneSelected = "MC1"
            tvSubTitle?.text = context?.getString(R.string.selection) +" "+  zoneSelected
        }
        btn2?.setOnClickListener { zoneSelected = "MC2"
            tvSubTitle?.text = context?.getString(R.string.selection)  +" "+  zoneSelected
        }
        btn3?.setOnClickListener { zoneSelected = "MC3"
            tvSubTitle?.text = context?.getString(R.string.selection)  +" "+  zoneSelected
        }
        btn4?.setOnClickListener { zoneSelected = "MC4"
            tvSubTitle?.text = context?.getString(R.string.selection)  +" "+  zoneSelected
        }
        btn5?.setOnClickListener { zoneSelected = "MC5"
            tvSubTitle?.text = context?.getString(R.string.selection)  +" "+  zoneSelected
        }
        btn6?.setOnClickListener { zoneSelected = "MC6"
            tvSubTitle?.text = context?.getString(R.string.selection)  +" "+  zoneSelected
        }
        btn7?.setOnClickListener { zoneSelected = "MC7"
            tvSubTitle?.text = context?.getString(R.string.selection)  +" "+  zoneSelected
        }
        btn8?.setOnClickListener { zoneSelected = "MC8"
            tvSubTitle?.text = context?.getString(R.string.selection)  +" "+  zoneSelected
        }

        btn9?.setOnClickListener { zoneSelected = "MC9"
            tvSubTitle?.text = context?.getString(R.string.selection)  +" "+  zoneSelected
        }


        btnPositive?.setOnClickListener {
            listener?.onSelectionDone(zoneSelected)
            dismiss()
        }

    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun setupView(view: View) {
        locationDialogVM.fetchLocations()
    }


    interface DialogClickListener{
        fun onSelectionDone(zoneSelected: String)
    }

}