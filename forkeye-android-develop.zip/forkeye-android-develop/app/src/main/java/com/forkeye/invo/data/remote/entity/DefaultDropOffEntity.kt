package com.forkeye.invo.data.remote.entity

import androidx.room.ColumnInfo
import com.forkeye.invo.data.local.db.dao.DropOffDAO

data class DefaultDropOffEntity (

	val PalletSerialNumber : String,
	val lastDetectTime : String,
	val source : String,
	val User : String,
	val Process : String,
	val ForkliftSerialNumber : String,
	val LocationDetails : String,
	var BinLocation: String,
	var Lane: String,
	val L5Location : String,
	var location : String,
	val MappedZone : String,
	val image : String,

)