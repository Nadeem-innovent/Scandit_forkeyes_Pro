package com.forkeye.invo.ui.login

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.forkeye.invo.data.local.db.entities.RegForkLiftEntity
import com.forkeye.invo.data.remote.response.Response
import com.forkeye.invo.ui.base.BaseViewModel
import kotlinx.coroutines.*
import java.lang.Exception

class RegViewModel(
        var context: Context
) : BaseViewModel() {


    private val _regResult = MutableLiveData<Response>()
    val regResult: LiveData<Response>
        get() = _regResult

    private var viewModelJob = Job()
    private val coroutineScope = CoroutineScope(viewModelJob + Dispatchers.Main)


    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }


    fun performReg(forkRegNo:String, forkId:String, plantNo:String, regDevice:String){
        coroutineScope.launch(Dispatchers.IO) {
            try {
                var regForkParam = RegForkLiftEntity(forkId, "RegisterForkliftDetails",
                    forkRegNo, plantNo, regDevice )
                _regResult.postValue(repository.registerForkLift(regForkParam))
            }catch (ex:Exception){
                _regResult.postValue(null)
                Log.e("Exception", "performReg: ", ex.cause)
            }
        }

        val userCount = repository.getUserDAO().getCount()
        Log.i("DB Test", "performLogin: $userCount")
    }


}