package com.forkeye.invo.data.local.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.forkeye.invo.data.local.db.dao.ForkLiftDAO
import java.io.Serializable

@Entity(tableName = ForkLiftDAO.TABLE_NAME)
class RegForkLiftEntity(

    @PrimaryKey()
    @ColumnInfo(name = ForkLiftDAO.ID)
    var ID: String = "0",
    @ColumnInfo(name = ForkLiftDAO.PROCESS)
    var Process: String = "",
    @ColumnInfo(name = ForkLiftDAO.REG_NO)
    var Reg_No: String = "",
    @ColumnInfo(name = ForkLiftDAO.PLANT_NO)
    var Plant_No: String = "",
    @ColumnInfo(name = ForkLiftDAO.REG_DEVICES)
    var RegDevices: String = ""

) : Serializable
