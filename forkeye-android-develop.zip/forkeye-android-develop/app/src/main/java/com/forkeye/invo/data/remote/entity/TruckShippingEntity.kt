package com.forkeye.invo.data.remote.entity

   
data class TruckShippingEntity (

   var PalletSerialNumber : String,
   var lastDetectTime : String,
   var source : String,
   var User : String,
   var Process : String,
   var ForkliftSerialNumber : String,
   var location : String,
   var image : String

)