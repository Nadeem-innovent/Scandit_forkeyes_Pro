package com.forkeye.invo.utils

import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Polygon
import kotlinx.coroutines.newFixedThreadPoolContext
import java.util.*
import kotlin.collections.ArrayList


class LocationUtils {

    companion object {

        private val locationQueue:Queue<LocationData> = LinkedList()

        fun insertLocation(locData:LocationData){
            if (locationQueue.size >= 10)
                locationQueue.remove()
            locationQueue.add(locData)
        }

        fun getLocationFromQueue(): String? {
            var locationData:LocationData? = null
            if (locationQueue == null || locationQueue.isNullOrEmpty())
                return null
            for(loc in locationQueue){
                if(locationData == null || (locationData.locQaulity <= loc.locQaulity && locationTimeInSec(loc.timeStamp) < 120))
                    locationData = loc
            }
            return locationData?.location
        }

        private fun locationTimeInSec(timeStamp:Long):Long{
            var timeDiff = System.currentTimeMillis() - timeStamp
            return timeDiff/1000
        }

        fun isLocationInRAK(lat: Double, lon: Double): Boolean {

            //return true
            //
            val rakCamp = ArrayList<LatLng>()
            rakCamp.add(LatLng(25.685924,55.789095))
            rakCamp.add(LatLng(25.68204,55.782524))
            rakCamp.add(LatLng(25.680412,55.781004))
            rakCamp.add(LatLng(25.677249,55.78517))
            rakCamp.add(LatLng(25.676483,55.784572))
            rakCamp.add(LatLng(25.675458,55.786025))
            rakCamp.add(LatLng(25.676289,55.786805))
            rakCamp.add(LatLng(25.674745,55.788886))
            rakCamp.add(LatLng(25.667885,55.793784))
            rakCamp.add(LatLng(25.666783,55.791938))
            rakCamp.add(LatLng(25.664742,55.793498))
            rakCamp.add(LatLng(25.665643,55.794908))
            rakCamp.add(LatLng(25.66453,55.795854))
            rakCamp.add(LatLng(25.664689,55.796103))
            rakCamp.add(LatLng(25.666735,55.794691))
            rakCamp.add(LatLng(25.667518,55.795907))
            rakCamp.add(LatLng(25.668781,55.795023))
            rakCamp.add(LatLng(25.671674,55.799851))
            rakCamp.add(LatLng(25.685924,55.789095))

            //Arkane Shade Area
//            val arkaneShadeSajja = ArrayList<LatLng>()
//            rakCamp.add(LatLng(25.362364, 55.623289))
//            rakCamp.add(LatLng(25.357059, 55.637171))
//            rakCamp.add(LatLng(25.349661, 55.633446))
//            rakCamp.add(LatLng(25.355854, 55.618407))
//            rakCamp.add(LatLng(25.362364, 55.623289))

            return pointIsInRegion(lon, lat, rakCamp) /*|| pointIsInRegion(lat, lon, rakCamp)*/
        }


        private fun pointIsInRegion(px: Double, py: Double, thePath: ArrayList<LatLng>): Boolean {

            var crossings = 0
            val count = thePath.size

            for (i in 0 until count) {

                val a = thePath[i]
                var j = i + 1
                if (j >= count) {
                    j = 0
                }
                val b = thePath[j]
                if (rayCrossesSegment(px, py, a, b)) {
                    crossings++
                }
            }
            // odd number of crossings?
            return crossings % 2 == 1
        }

        fun rayCrossesSegment(px: Double, py: Double, a: LatLng, b: LatLng): Boolean {

            var px = px
            var py = py

            var ax = a.longitude
            var ay = a.latitude
            var bx = b.longitude
            var by = b.latitude

            if (ay > by) {
                ax = b.longitude
                ay = b.latitude
                bx = a.longitude
                by = a.latitude
            }

            if (px < 0) {
                px += 360.0
            }

            if (ax < 0) {
                ax += 360.0
            }

            if (bx < 0) {
                bx += 360.0
            }

            if (py == ay || py == by) py += 0.00000001
            if (py > by || py < ay || px > Math.max(ax, bx)) return false

            if (px < Math.min(ax, bx)) return true

            val red = if (ax != bx) (by - ay) / (bx - ax) else Double.MAX_VALUE
            val blue = if (ax != px) (py - ay) / (px - ax) else Double.MAX_VALUE
            return blue >= red
        }
    }
}