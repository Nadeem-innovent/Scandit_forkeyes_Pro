package com.forkeye.invo.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.forkeye.invo.data.local.db.dao.*
import com.forkeye.invo.data.local.db.entities.*

@Database(
    entities = [ DropOffEntity::class, RegForkLiftEntity::class, PalletPickUpEntity::class, UserEntity::class, RouteEntity::class], version = 1
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dropOffDAO(): DropOffDAO
    abstract fun forkLiftDAO(): ForkLiftDAO
    abstract fun palletPickUpDAO(): PalletPickUpDAO
    abstract fun userDAO(): UserDAO
    abstract fun routeDAO(): RouteDAO
}
