package com.forkeye.invo.ui.base

import androidx.lifecycle.ViewModel
import com.forkeye.invo.data.Repository
import com.forkeye.invo.data.local.db.AppDatabase
import com.forkeye.invo.data.remote.ApiService
import org.koin.core.component.KoinComponent
import org.koin.core.component.get

open class BaseViewModel() : ViewModel(), KoinComponent {
    val repository by lazy { get<Repository>() }
    val database by lazy { get<AppDatabase>() }
    val apiService by lazy { get<ApiService>() }

}