package com.forkeye.invo.ui.login

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.forkeye.invo.data.remote.response.Response
import com.forkeye.invo.data.local.db.entities.LocationBody
import com.forkeye.invo.ui.base.BaseViewModel
import kotlinx.coroutines.*
import java.lang.Exception

class LocationDialogVM(
        var context: Context
) : BaseViewModel() {


    private val _loginResult = MutableLiveData<Response>()
    val loginResult: LiveData<Response>
        get() = _loginResult

    private var viewModelJob = Job()
    private val coroutineScope = CoroutineScope(viewModelJob + Dispatchers.Main)


    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }



    fun fetchLocations(){
        coroutineScope.launch(Dispatchers.IO) {
            try {
                var authParam = LocationBody("","","","","" )
                //_loginResult.postValue(repository.mappedLocation(authParam))
            }catch (ex:Exception){
                _loginResult.postValue(null)
                Log.e("Exception", "performLogin:", ex.cause )
            }
        }

        val userCount = repository.getUserDAO().getCount()
        Log.i("DB Test", "performLogin: $userCount")
    }


}