package com.forkeye.invo.data.remote



import com.forkeye.invo.data.local.db.entities.*
import com.forkeye.invo.data.remote.entity.DefaultDropOffEntity
import com.forkeye.invo.data.remote.entity.InsideDropOffEntity
import com.forkeye.invo.data.remote.entity.TruckShippingEntity
import com.forkeye.invo.data.remote.entity.TruckTransitEntity
import com.forkeye.invo.data.remote.response.*
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface ApiService {


    @Headers("apikey:WYMOJXX8QZ4TBAWS", "Content-Type:application/json")
    @POST("USERS")
    suspend fun userAuth(@Body jsonParam: AuthUser): AuthResp

    @Headers("apikey:WYMOJXX8QZ4TBAWS", "Content-Type:application/json")
    @POST("USERS")
    suspend fun createUser(@Body jsonParam: UserEntity): Response

    @Headers("apikey:WYMOJXX8QZ4TBAWS", "Content-Type:application/json")
    @POST("USERS")
    suspend fun updateUser(@Body jsonParam: UpdateUserEntity): Response

    @Headers("apikey:WYMOJXX8QZ4TBAWS", "Content-Type:application/json")
    @POST("FORKLIFT")
    suspend fun registerForkLift(@Body jsonParam: RegForkLiftEntity): Response

    @Headers("apikey:WYMOJXX8QZ4TBAWS", "Content-Type:application/json")
    @POST("OPERATIONS")
    suspend fun palletPickUp(@Body jsonParam: PalletPickUpEntity): OperationResp

    @Headers("apikey:WYMOJXX8QZ4TBAWS", "Content-Type:application/json")
    @POST("OPERATIONS")
    suspend fun dropOffInsideFeild(@Body jsonParam: InsideDropOffEntity): OperationResp

    @Headers("apikey:WYMOJXX8QZ4TBAWS", "Content-Type:application/json")
    @POST("OPERATIONS")
    suspend fun dropOffDefault(@Body jsonParam: DefaultDropOffEntity): OperationResp

    @Headers("apikey:WYMOJXX8QZ4TBAWS", "Content-Type:application/json")
    @POST("OPERATIONS")
    suspend fun dropOffInternalTruck(@Body jsonParam: TruckTransitEntity): OperationResp

    @Headers("apikey:WYMOJXX8QZ4TBAWS", "Content-Type:application/json")
    @POST("OPERATIONS")
    suspend fun dropOffExternal(@Body jsonParam: TruckShippingEntity): OperationResp

    @Headers("apikey:WYMOJXX8QZ4TBAWS", "Content-Type:application/json")
    @POST("riot-core-services/api/reportExecution/MAPPEDLOCATIONS")
    suspend fun mappedLocation(@Body jsonParam: MappedLocEntity): Response

    @Headers("apikey:WYMOJXX8QZ4TBAWS", "Content-Type:application/json")
    @POST("PALLETDATA")
    suspend fun searchPallet(@Body jsonParam: SaerchPallet): List<PalletSearchResponse>


    @POST("https://saqibmaster.herokuapp.com/getSubscriptions")
    suspend fun checkAppSubcriptin(@Body jsonParam: SubcriptionParam): List<SubcriptionResponse>
}