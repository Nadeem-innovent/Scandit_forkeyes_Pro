package com.forkeye.invo.ui

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.lifecycle.viewModelScope
import com.forkeye.invo.R
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils
import com.forkeye.invo.ui.base.BaseActivity
import com.forkeye.invo.ui.login.LoginFragment
import com.forkeye.invo.ui.login.RegForkFragment
import com.forkeye.invo.ui.login.SplashViewModel
import com.forkeye.invo.utils.manager.AlarmUtils
import com.forkeye.invo.utils.manager.BootCompleteReceiver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import org.koin.androidx.viewmodel.ext.android.viewModel


class AdminLoginActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        showFragment(LoginFragment.getInstance(true))
    }
}