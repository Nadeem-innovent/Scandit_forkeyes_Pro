package com.forkeye.invo.ui.adaptor

import android.content.Context
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import app.commons.adapters.BaseAdapterViewProvider
import com.forkeye.invo.R
import com.forkeye.invo.data.local.db.entities.DropOffEntity
import java.text.SimpleDateFormat
import java.util.*

class PalletDropListViewProvider(var context: Context, var listener: NewsCardActionListener? = null) :
    BaseAdapterViewProvider() {

    override fun getLayoutId(): Int {
        return R.layout.list_item_pallet_drop
    }

    override fun populateView(view: View, item: Any, position: Int, count: Int) {

        var qrCodeText: TextView = view.findViewById(R.id.qrCodeTv)
        var time: TextView = view.findViewById(R.id.timeTv)
        var palletStatus: TextView = view.findViewById(R.id.palletStatusTv)
        var palletUploadStatus: ImageView = view.findViewById(R.id.palletUploadStatusImg)
        var zoneTv: TextView = view.findViewById(R.id.zoneTv)
        var latlngTv: TextView = view.findViewById(R.id.latlngTv)

        val obj = item as DropOffEntity

        qrCodeText.text = obj.PalletSerialNumber
        palletStatus.text = obj.Process
        time.text =  getDateTime(obj.lastDetectTime)
        palletUploadStatus.setImageResource(if (obj.pushed) R.drawable.up_cloud else R.drawable.local_db)
        obj.location?.let { latlngTv.text = it.replace(";0.0","") }
        obj.LocationDetails?.let {  zoneTv.text = it}
    }

    private fun getDateTime(s: String): String? {
        try {

            val formatter = SimpleDateFormat("hh:mm:ss a")

            val calendar = Calendar.getInstance()
            calendar.timeInMillis = s.toLong()
            return formatter.format(calendar.time)
        } catch (e: Exception) {
            return e.toString()
        }
    }

    interface NewsCardActionListener {
        //fun onCardSelected(libraryMainItem: NewsFeedEntity)
    }
}