package com.forkeye.invo.data.local.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.forkeye.invo.data.local.db.dao.RouteDAO
import com.forkeye.invo.data.local.db.dao.UserDAO
import java.io.Serializable

@Entity(tableName = RouteDAO.TABLE_NAME)
class RouteEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = RouteDAO.ID)
    var id: Int,
    @ColumnInfo(name = RouteDAO.POINT_ID)
    var pointId: Int,
    @ColumnInfo(name = RouteDAO.LATITUE)
    var latitude : Double = 0.0,
    @ColumnInfo(name = RouteDAO.LONGITUDE)
    var longitude: Double = 0.0,
    @ColumnInfo(name = RouteDAO.TRACK_NAME)
    var trackName: String = "",
    @ColumnInfo(name = RouteDAO.DISTANCE_FROM_CUR_LOC)
    var distFromCurLoc: Double = 0.0,
    @ColumnInfo(name = RouteDAO.DISTANCE_FROM_END_LOC)
    var distFromEndLoc: Double = 0.0,

) : Serializable
