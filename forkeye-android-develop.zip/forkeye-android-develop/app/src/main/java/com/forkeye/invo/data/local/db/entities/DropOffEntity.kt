package com.forkeye.invo.data.local.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.forkeye.invo.data.local.db.dao.DropOffDAO
import java.io.Serializable

@Entity(tableName = DropOffDAO.TABLE_NAME)
class DropOffEntity(

//    "PalletSerialNumber": "000123456789",
//"lastDetectTime": "1618107244000",
//"source": "VISION_1234",
//"User": "Saqib",
//"Process": "Drop off Ship",
//"ForkliftSerialNumber": "2",
//"location": "55.791446;25.677051;0.0",

//"LocationDetails":"MC5",
//"L5Location":"LEFT-8",
//"MappedZone":"MC5",
//"truck_plate": "001",
//"image": "Base64"

    @PrimaryKey()
    @ColumnInfo(name = DropOffDAO.ID)
    @Transient var id: String = "0",
    @ColumnInfo(name = DropOffDAO.PALLET_SERIAL_NO)
    var PalletSerialNumber: String = "",
    @ColumnInfo(name = DropOffDAO.LAST_DETECT_TIME)
    var lastDetectTime: String = "",
    @ColumnInfo(name = DropOffDAO.SOURCE)
    var source: String = "",
    @ColumnInfo(name = DropOffDAO.USER)
    var User: String = "",
    @ColumnInfo(name = DropOffDAO.PROCESS)
    var Process: String = "",
    @ColumnInfo(name = DropOffDAO.FORK_LIFT_SERIAL_NUMBER)
    var ForkliftSerialNumber: String = "",

    @ColumnInfo(name = DropOffDAO.LOCATION)
    var location: String = "",
    @ColumnInfo(name = DropOffDAO.LOCATION_DETAILS)
    var LocationDetails: String = "",
    @ColumnInfo(name = DropOffDAO.LANE)
    var Lane: String = "",
    @ColumnInfo(name = DropOffDAO.BIN_LOC)
    var BinLocation: String = "",
    @ColumnInfo(name = DropOffDAO.L5_LOCATION)
    var L5Location: String = "",



    @ColumnInfo(name = DropOffDAO.MAPPED_ZONE)
    var MappedZone: String = "",
    @ColumnInfo(name = DropOffDAO.TRUCK_PLATE)
    var truck_plate: String = "",
    @ColumnInfo(name = DropOffDAO.IMAGE)
    var image: String = "",



    @ColumnInfo(name = DropOffDAO.PUSH_TO_SERVER)
    @Transient var pushed: Boolean = false

    ) : Serializable
