package com.forkeye.invo.data.local.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import com.forkeye.invo.data.local.db.dao.MainDAO
import com.forkeye.invo.utils.AppGlobals
import org.json.JSONObject
import java.io.Serializable

@Entity(tableName = MainDAO.TABLE_NAME)
class MainListEntity(

    @PrimaryKey()
    @ColumnInfo(name = MainDAO.ID)
    var id: String = "0",
    @ColumnInfo(name = MainDAO.SERVICE_ID)
    var serviceId: String = "",
    @ColumnInfo(name = MainDAO.TYPE)
    var type: String = "",
    @ColumnInfo(name = MainDAO.TITLE)
    var title: String = "",

) : Serializable {

    companion object {

        const val CAMPAIGN_TYPE_EVENT = "event"
        const val CAMPAIGN_TYPE_SERVICE = "service"
    }

    @Ignore
    constructor(jsonObject: JSONObject, appGlobals: AppGlobals) : this() {

        type = jsonObject.optString("type")
        id = jsonObject.optString("id")
        title = jsonObject.optString("title")
    }
}
