package com.forkeye.invo.data

import com.forkeye.invo.data.local.db.AppDatabase
import com.forkeye.invo.data.local.db.entities.*
import com.forkeye.invo.data.remote.ApiService
import com.forkeye.invo.data.remote.entity.DefaultDropOffEntity
import com.forkeye.invo.data.remote.entity.InsideDropOffEntity
import com.forkeye.invo.data.remote.entity.TruckShippingEntity
import com.forkeye.invo.data.remote.entity.TruckTransitEntity


class Repository (private val apiService: ApiService, private val appDbHelper: AppDatabase) {
    suspend fun authUser(authUser: AuthUser) =  apiService.userAuth(authUser)

    suspend fun createUser(jsonParam: UserEntity) =  apiService.createUser(jsonParam)

    suspend fun updateUser(jsonParam: UpdateUserEntity) =  apiService.updateUser(jsonParam)

    suspend fun registerForkLift(jsonParam: RegForkLiftEntity) =  apiService.registerForkLift(jsonParam)

    suspend fun palletPickUp(jsonParam: PalletPickUpEntity) =  apiService.palletPickUp(jsonParam)

    suspend fun dropOffInside(jsonParam: InsideDropOffEntity) =  apiService.dropOffInsideFeild(jsonParam)

    suspend fun dropOffDefault(jsonParam: DefaultDropOffEntity) =  apiService.dropOffDefault(jsonParam)

    suspend fun dropOffInternalTruck(jsonParam: TruckTransitEntity) =  apiService.dropOffInternalTruck(jsonParam)

    suspend fun dropOffExternal(jsonParam: TruckShippingEntity) =  apiService.dropOffExternal(jsonParam)

    suspend fun mappedLocation(jsonParam: MappedLocEntity) =  apiService.mappedLocation(jsonParam)

    suspend fun searchPallet(authUser: SaerchPallet) =  apiService.searchPallet(authUser)

    suspend fun checkAppSubcriptin(jsonParam: SubcriptionParam) =  apiService.checkAppSubcriptin(jsonParam)

    fun dropOffDAO() =  appDbHelper.dropOffDAO()


    fun getForkLiftDAO() =  appDbHelper.forkLiftDAO()
    fun getPalletPickUpDAO() =  appDbHelper.palletPickUpDAO()
    fun getUserDAO() =  appDbHelper.userDAO()
    fun getRouteDAO() =  appDbHelper.routeDAO()

}