package com.forkeye.invo.data.local.db.dao

import androidx.room.*
import com.forkeye.invo.data.local.db.entities.UserEntity

@Dao
interface UserDAO {

    companion object {
        const val TABLE_NAME = "UserTable"
        const val ID = "id"
        const val PROCESS = "process"
        const val FIRST_NAME = "first_name"
        const val LAST_NAME = "last_name"
        const val EMAIL = "email"
        const val USER_NAME = "user_name"
        const val PASSWORD = "password"
        const val PLANT = "plant"
        const val MANAGER = "manager"
        const val ROLE = "role"
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: UserEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(items: ArrayList<UserEntity>): List<Long>

    @Query("SELECT COUNT(*) from $TABLE_NAME")
    fun getCount(): Int

    @Query("select * from $TABLE_NAME where $USER_NAME like :text")
    fun searchByUserName(text: String): List<UserEntity>

    @Query("delete from $TABLE_NAME")
    fun deleteAll()

    @Delete
    fun delete(item: UserEntity)

    @Update
    fun update(item: UserEntity)

    @Update
    fun update(items: List<UserEntity>)
}