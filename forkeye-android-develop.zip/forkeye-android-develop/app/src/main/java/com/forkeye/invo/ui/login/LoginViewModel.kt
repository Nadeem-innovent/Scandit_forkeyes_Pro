package com.forkeye.invo.ui.login


import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.forkeye.invo.data.local.db.entities.AuthUser
import com.forkeye.invo.data.remote.response.AuthResp
import com.forkeye.invo.ui.base.BaseViewModel
import kotlinx.coroutines.*
import java.lang.Exception

class LoginViewModel(
        var context: Context
) : BaseViewModel() {


    private val _loginResult = MutableLiveData<AuthResp>()
    val loginResult: LiveData<AuthResp>
        get() = _loginResult

    private var viewModelJob = Job()
    private val coroutineScope = CoroutineScope(viewModelJob + Dispatchers.Main)


    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }



    fun performLogin(userName:String, password:String){
        coroutineScope.launch(Dispatchers.IO) {
            try {
                var authParam = AuthUser("Authenticate", userName, password )
                _loginResult.postValue(repository.authUser(authParam))
            }catch (ex:Exception){
                _loginResult.postValue(null)
                Log.e("Exception", "performLogin:", ex.cause )
            }
        }

        val userCount = repository.getUserDAO().getCount()
        Log.i("DB Test", "performLogin: $userCount")
    }


}