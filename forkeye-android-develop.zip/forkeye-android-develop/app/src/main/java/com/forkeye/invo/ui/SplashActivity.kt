package com.forkeye.invo.ui

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.lifecycle.viewModelScope
import com.forkeye.invo.R
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils
import com.forkeye.invo.ui.base.BaseActivity
import com.forkeye.invo.ui.login.LoginFragment
import com.forkeye.invo.ui.login.RegForkFragment
import com.forkeye.invo.ui.login.SplashViewModel
import com.forkeye.invo.utils.manager.AlarmUtils
import com.forkeye.invo.utils.manager.BootCompleteReceiver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import org.koin.androidx.viewmodel.ext.android.viewModel


class SplashActivity : BaseActivity() {

    val DELAY = 2500L
    val debug = false
    val splashViewModel by viewModel<SplashViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val receiver = ComponentName(applicationContext, BootCompleteReceiver::class.java)

        applicationContext.packageManager?.setComponentEnabledSetting(
            receiver,
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )


        splashViewModel.viewModelScope.async(Dispatchers.Main) {

            //splashViewModel.performSubCheck()

            delay(DELAY)


            setupUploadService()
            if (debug) {
                startActivity(MainActivity::class.java)
                finish()
            } else {
                var response = splashViewModel.performLogin("Admin", "123456")
                while (true) {
                    if (response == null) {
                        delay(DELAY)
                        response = splashViewModel.performLogin("Admin", "123456")
                    } else {
                        break
                    }
                }
                if (!(PrefUtils.getFromPrefs(applicationContext, PrefKeys.USER_LOG_IN, false) as Boolean)) {
                    showFragment(LoginFragment.getInstance(adminLogin = false))
                } else if (!(PrefUtils.getFromPrefs(applicationContext, PrefKeys.FORK_REG, false) as Boolean)) {
                    showFragment(RegForkFragment.getInstance())
                } else {
                    startActivity(MainActivity::class.java)
                    finish()
                }
            }
        }
    }


    fun setupUploadService() {
        var timeInMilliSeconds: Long = 1000 * 60 * 1 // two minute
        val sharedPref = this.getSharedPreferences("AlarmPref", Context.MODE_PRIVATE)
            ?: return
        with(sharedPref.edit()) {
            putLong("timeInMilli", timeInMilliSeconds)
            apply()
        }
        AlarmUtils.setAlarm(this, timeInMilliSeconds)
    }

}