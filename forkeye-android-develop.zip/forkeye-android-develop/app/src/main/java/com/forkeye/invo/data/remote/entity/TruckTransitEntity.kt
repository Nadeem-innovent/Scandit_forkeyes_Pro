package com.forkeye.invo.data.remote.entity

   
data class TruckTransitEntity (

   var PalletSerialNumber : String,
   var lastDetectTime : String,
   var source : String,
   var User : String,
   var Process : String,
   var ForkliftSerialNumber : String,
   var truck_plate : String,
   var location : String,
   var image : String

)