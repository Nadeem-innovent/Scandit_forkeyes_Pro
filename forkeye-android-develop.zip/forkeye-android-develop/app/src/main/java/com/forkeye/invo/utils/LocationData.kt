package com.forkeye.invo.utils

import android.location.Location

class LocationData(
    var location: String,
    var locQaulity: Int,
    var timeStamp:Long
)