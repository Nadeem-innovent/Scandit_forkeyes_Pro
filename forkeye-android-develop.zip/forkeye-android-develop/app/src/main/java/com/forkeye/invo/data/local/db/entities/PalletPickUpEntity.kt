package com.forkeye.invo.data.local.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.forkeye.invo.data.local.db.dao.PalletPickUpDAO
import java.io.Serializable

@Entity(tableName = PalletPickUpDAO.TABLE_NAME)
class PalletPickUpEntity(

    @PrimaryKey()
    @ColumnInfo(name = PalletPickUpDAO.ID)
    var id: String = "0",
    @ColumnInfo(name = PalletPickUpDAO.PALLET_SERIAL_NO)
    var PalletSerialNumber: String = "",
    @ColumnInfo(name = PalletPickUpDAO.LAST_DETECT_TIME)
    var lastDetectTime: String = "",
    @ColumnInfo(name = PalletPickUpDAO.SOURCE)
    var source: String = "",
    @ColumnInfo(name = PalletPickUpDAO.USER)
    var User: String = "",
    @ColumnInfo(name = PalletPickUpDAO.PROCESS)
    var Process: String = "",
    @ColumnInfo(name = PalletPickUpDAO.FORK_LIFT_SERIAL_NUMBER)
    var ForkliftSerialNumber: String = "",
    @ColumnInfo(name = PalletPickUpDAO.LOCATION)
    var location: String = "",
    @ColumnInfo(name = PalletPickUpDAO.MAPPED_ZONE)
    var MappedZone: String = "",


    ) : Serializable
