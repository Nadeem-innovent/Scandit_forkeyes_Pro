package com.forkeye.invo.data.local.db.entities

import java.io.Serializable

data class SubcriptionParam(
    val subCode: String,
    val uuid: String
):Serializable
