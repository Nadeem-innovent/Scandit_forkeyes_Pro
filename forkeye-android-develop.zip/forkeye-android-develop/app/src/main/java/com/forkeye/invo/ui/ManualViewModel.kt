package com.forkeye.invo.ui

import android.content.Context
import android.widget.Toast
import com.forkeye.invo.data.local.db.entities.DropOffEntity
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils
import com.forkeye.invo.ui.base.BaseViewModel
import com.forkeye.invo.ui.dialog.AlertDialog
import com.forkeye.invo.ui.main.MainViewModel
import com.forkeye.invo.ui.main.MainViewModel.DROP_OFF_TYPE
import com.forkeye.invo.utils.LocationUtils
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.*

open class ManualViewModel(
    var context: Context
) : BaseViewModel() {

    private var viewModelJob = Job()
    private val coroutineScope = CoroutineScope(viewModelJob + Dispatchers.Main)


    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }

    fun dropOffShip(qrCode: String, location: String, default: MainViewModel.DROP_OFF_TYPE) {
        var dropOff = DropOffEntity(
            System.currentTimeMillis().toString(),
            (qrCode),
            System.currentTimeMillis().toString(),
            "VISION_1234",
            PrefUtils.getFromPrefs(context, PrefKeys.USER_NAME, "") as String,
            default.type,
            PrefUtils.getFromPrefs(context, PrefKeys.FORK_LIFT_REG_NO, "") as String,
            location + ";0.0"

        )
        repository.dropOffDAO().insert(dropOff)
    }


    fun dropOffInside(qrCode: String, zone: String) {
        var dropOff = DropOffEntity(
            System.currentTimeMillis().toString(),
            (qrCode),
            System.currentTimeMillis().toString(),
            "VISION_1234",
            PrefUtils.getFromPrefs(context, PrefKeys.USER_NAME, "") as String,
            DROP_OFF_TYPE.INSIDE.type,
            PrefUtils.getFromPrefs(context, PrefKeys.FORK_LIFT_REG_NO, "") as String,
            zone,
            zone
        )
        repository.dropOffDAO().insert(dropOff)
    }

    fun dropOffDefault(qrCode: String, location: String, locDetails:String, lane:String, bin:String, l5Loc: String) {

        var dropOff = DropOffEntity(
            System.currentTimeMillis().toString(),
            (qrCode),
            System.currentTimeMillis().toString(),
            "VISION_1234",
            PrefUtils.getFromPrefs(context, PrefKeys.USER_NAME, "") as String,
            DROP_OFF_TYPE.DEFAULT.type,
            PrefUtils.getFromPrefs(context, PrefKeys.FORK_LIFT_REG_NO, "") as String,
            location + ";0.0",
            locDetails,
            lane,
            bin,
            l5Loc
        )
        repository.dropOffDAO().insert(dropOff)
    }

}