package com.forkeye.invo.data.local.db.dao

import androidx.room.*
import com.forkeye.invo.data.local.db.entities.PalletPickUpEntity

@Dao
interface PalletPickUpDAO {

    companion object {

        const val TABLE_NAME = "PalletPickUpTable"
        const val ID = "id"
        const val PALLET_SERIAL_NO = "pallet_sr_no"
        const val LAST_DETECT_TIME = "last_detect_time"
        const val SOURCE = "source"
        const val USER = "user"
        const val PROCESS = "process"
        const val FORK_LIFT_SERIAL_NUMBER = "fork_lift_sr_no"
        const val LOCATION = "location"
        const val MAPPED_ZONE = "mapped_zone"
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: PalletPickUpEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(items: ArrayList<PalletPickUpEntity>): List<Long>

    @Query("SELECT COUNT(*) from $TABLE_NAME")
    fun getCount(): Int

    @Query("select * from $TABLE_NAME where $PALLET_SERIAL_NO like :text")
    fun searchByUserName(text: String): List<PalletPickUpEntity>

    @Query("delete from $TABLE_NAME")
    fun deleteAll()

    @Delete
    fun delete(item: PalletPickUpEntity)

    @Update
    fun update(item: PalletPickUpEntity)

    @Update
    fun update(items: List<PalletPickUpEntity>)
}