package app.commons.adapters

import android.view.View
import org.koin.core.component.KoinComponent

abstract class BaseAdapterViewProvider : KoinComponent {


    abstract fun getLayoutId(): Int
    abstract fun populateView(view: View, item: Any, position: Int, count: Int)
}