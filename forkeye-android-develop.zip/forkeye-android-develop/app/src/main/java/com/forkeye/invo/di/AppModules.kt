package com.forkeye.invo.di

import android.content.Context
import androidx.room.Room
import com.forkeye.invo.data.Repository
import com.forkeye.invo.data.local.db.AppDatabase
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils
import com.forkeye.invo.data.remote.ApiService
import com.forkeye.invo.data.remote.NetworkHelper
import com.forkeye.invo.ui.ManualViewModel
import com.forkeye.invo.ui.login.*
import com.forkeye.invo.ui.main.MainViewModel
import com.forkeye.invo.ui.map.MapViewModel
import com.jakewharton.retrofit2.adapter.kotlin.coroutines.CoroutineCallAdapterFactory
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.android.ext.koin.androidApplication
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.loadKoinModules
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.util.concurrent.TimeUnit

object AppModules {

    fun initialize() {
        loadKoinModules(listOf(modules, viewModelModules))
    }


    private fun provideNetworkHelper(context: Context) = NetworkHelper(context)


    private fun provideOkHttpClient(): OkHttpClient {
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY)

        return OkHttpClient().newBuilder()
            .callTimeout(30, TimeUnit.SECONDS)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor)
            .build()
    }


    private fun provideMoshiConverter()  =
        Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()

    private fun provideRetrofit(
        okHttpClient: OkHttpClient,
        context: Context
    ): Retrofit =
        Retrofit.Builder()
            .addConverterFactory(MoshiConverterFactory.create(provideMoshiConverter()))
            //.baseUrl("https://jsonplaceholder.typicode.com/todos/")
            //https://digitrack.rakceramics.com/innovent/FORKLIFT
            .baseUrl(PrefUtils.getFromPrefs(context, PrefKeys.VIZIX_SERVER_URL, "https://digitrack.rakceramics.com/innovent/") as String)
            //.baseUrl(PrefUtils.getFromPrefs(context, PrefKeys.VIZIX_SERVER_URL, "http://rak.innovent.site/innovent/") as String)
            .client(okHttpClient)
            .addCallAdapterFactory(CoroutineCallAdapterFactory())
            .build()

    private fun provideApiService(retrofit: Retrofit): ApiService = retrofit.create(ApiService::class.java)


    val modules = module {

        single {
            Room.databaseBuilder(androidApplication(), AppDatabase::class.java, "app_db_test")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build()
        }

        factory { provideOkHttpClient() }
        single { provideRetrofit(get(), get()) }
        single { provideApiService(get()) }
        single { provideNetworkHelper(androidContext()) }
        single {
            Repository(get(), get())
        }

    }



    val viewModelModules = module {
        viewModel { MainViewModel(androidApplication()) }
        viewModel { LoginViewModel(androidApplication()) }
        viewModel { RegViewModel(androidApplication()) }
        viewModel { LocationDialogVM(androidApplication()) }
        viewModel { SplashViewModel(androidApplication()) }
        viewModel { ManualViewModel(androidApplication()) }
        viewModel { MapViewModel(androidApplication()) }
    }
}