package com.forkeye.invo.ui

import android.content.Intent
import android.location.Location
import android.os.Bundle
import android.widget.*
import com.forkeye.invo.R
import com.forkeye.invo.ui.barcode.BarcodeScannerActivity
import com.forkeye.invo.ui.base.BaseActivity
import com.forkeye.invo.ui.dialog.ConfirmationDialog
import com.forkeye.invo.ui.dialog.LfiveDialog
import com.forkeye.invo.ui.dialog.LocationDialog
import com.forkeye.invo.ui.main.MainViewModel
import com.forkeye.invo.utils.LocationUtils
import com.google.android.gms.maps.model.LatLng
import kotlinx.android.synthetic.main.activity_manual.*
import mumayank.com.airlocationlibrary.AirLocation
import org.koin.androidx.viewmodel.ext.android.viewModel


class ManualActivity : BaseActivity() {

    private var insideZoneSelected: String? = null
    val manualViewModel by viewModel<ManualViewModel>()
    var backImg: ImageView? = null
    var operModeTv: TextView? = null
    var qrCodeTv: TextView? = null
    var locationTv: TextView? = null
    var dropOfType: String? = null
    var zoneValue: String? = null
    var location: Location? = null
    var qrCode: String? = null

    companion object {
        var DROP_OF_TYPE = "DROP_OF_TYPE"
        var ZONE_VALUE = "DROP_OF_TYPE"
    }

    private val airLocation = AirLocation(this, object : AirLocation.Callback {

        override fun onSuccess(locations: ArrayList<Location>) {
            locations?.let {
                if (it.size > 0) {
                    location = it.get(0)
                    locationTv?.text = location?.latitude.toString() + "," + location?.longitude.toString()
                }
            }
        }

        override fun onFailure(locationFailedEnum: AirLocation.LocationFailedEnum) {
            // do something
            // the reason for failure is given in locationFailedEnum
        }

    })


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manual)

        backImg = findViewById(R.id.back)
        backImg?.setOnClickListener {
            onBackPressed()
        }

        if (intent.hasExtra(DROP_OF_TYPE)) {
            dropOfType = intent.getStringExtra(DROP_OF_TYPE)
        }

        if (intent.hasExtra(ZONE_VALUE)) {
            zoneValue = intent.getStringExtra(ZONE_VALUE)
        }

        val qrScanBtn = findViewById<LinearLayout>(R.id.ll_scan)
        qrScanBtn.setOnClickListener {
            checkPermission()
        }

        findViewById<Button>(R.id.manualSaveBtn).setOnClickListener {
            if (qrCode.isNullOrEmpty()) {
                showAlert("Please Scan the QR Code!")
                return@setOnClickListener
            }
            if (location == null) {
                showAlert("Device Scanning for the Location Please wait and try Later!")
                return@setOnClickListener
            }
            when(dropOfType){
                MainViewModel.DROP_OFF_TYPE.DEFAULT.type ->{
                    var dialog = LfiveDialog.newInstance(
                        "",
                        "",
                        object : LfiveDialog.SimpleDialogClickListener {
                            override fun onSelectionDone(locDetails: String, lane: String, bin: String, l5Selection: String) {
                                locationTv?.text.toString()?.let {
                                    var locArr = it.split(",")
                                    var latLng = LatLng(locArr.get(1).toDouble(), locArr.get(0).toDouble())
                                    val l5Loc = l5Selection
                                    if (LocationUtils.isLocationInRAK(latLng.longitude, latLng.latitude )) {
                                        manualViewModel.dropOffDefault(qrCode!!, locationTv?.text.toString(),  locDetails, lane, bin, l5Loc)
                                        saveAndClear()
                                    } else {
                                        showAlert("Location is outside the define premises!")
                                    }
                                }
                            }
                        })
                    dialog.isCancelable = false
                    dialog.show(this?.supportFragmentManager!!, LfiveDialog.TAG)

                }
                MainViewModel.DROP_OFF_TYPE.INSIDE.type ->{
                    if(insideZoneSelected.isNullOrEmpty()){
                        showAlert("Please go back and select operation inside and select zone then start manual process")
                    }else{
                        manualViewModel.dropOffInside(qrCode!!, insideZoneSelected!!)
                        saveAndClear()
                    }
                }
                MainViewModel.DROP_OFF_TYPE.TRUCK_TRANSIT.type ->{
                    locationTv?.text.toString()?.let {
                        var locArr = it.split(",")
                        var latLng = LatLng(locArr.get(1).toDouble(), locArr.get(0).toDouble())
                        if (LocationUtils.isLocationInRAK(latLng.longitude, latLng.latitude)) {
                            manualViewModel.dropOffShip(qrCode!!, locationTv?.text.toString(), MainViewModel.DROP_OFF_TYPE.TRUCK_TRANSIT)
                            saveAndClear()
                        } else {
                            showAlert("Location is outside the define premises!")
                        }
                    }
                }
                MainViewModel.DROP_OFF_TYPE.SHIPPING_TRUCK.type ->{
                    locationTv?.text.toString()?.let {
                        var locArr = it.split(",")
                        var latLng = LatLng(locArr.get(1).toDouble(), locArr.get(0).toDouble())
                        if (LocationUtils.isLocationInRAK(latLng.longitude, latLng.latitude)) {
                            manualViewModel.dropOffShip(qrCode!!, locationTv?.text.toString(), MainViewModel.DROP_OFF_TYPE.SHIPPING_TRUCK)
                            saveAndClear()
                        } else {
                            showAlert("Location is outside the define premises!")
                        }
                    }

                }
            }

        }

        operModeTv = findViewById<TextView>(R.id.tv_operation_mode)
        qrCodeTv = findViewById<TextView>(R.id.qrCodeVal)
        locationTv = findViewById<TextView>(R.id.tv_location)
        operModeTv?.text = dropOfType
        airLocation.start()

        if (dropOfType == MainViewModel.DROP_OFF_TYPE.INSIDE.type){
            var dialog = LocationDialog.newInstance(object : LocationDialog.DialogClickListener {
                override fun onSelectionDone(zoneSelected: String) {
                    insideZoneSelected = zoneSelected
                }
            })
            dialog.isCancelable = false
            dialog.show(this?.supportFragmentManager!!, LfiveDialog.TAG)
        }
    }

    private fun saveAndClear() {
        showAlert("Transaction Saved Successfully!")
        qrCode = null
        qrCodeVal?.text = "No Value"
    }

    fun showDrofOffManualDialog() {
        this?.let {
            ConfirmationDialog.newInstance(
                "Bad Location. Need to add this Drop Off Manually!",
                null,
                object : ConfirmationDialog.DialogClickListener {
                    override fun onSelectionDone(transitToTruck: Boolean) {
                        manualProcessGPS()
                    }
                }).show(it?.supportFragmentManager, "ConfirmationDialog")
        }
    }

    fun manualProcessGPS() {
        var bundle = Bundle()
        bundle.putString(ManualActivity.DROP_OF_TYPE, dropOfType)
        //bundle.putString(ManualActivity.ZONE_VALUE, insideZoneSelected)
        (this as BaseActivity)?.startActivity(ManualActivity::class.java, bundle)
        //mainViewModel.dropOffInside("000123456789", "MC-5")
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == BarcodeScannerActivity.BARCODE) {
            qrCode = data?.extras?.get(BarcodeScannerActivity.BAR_CODE_VAL) as String
            qrCodeVal?.text = qrCode.toString()
        } else {
            airLocation.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        airLocation.onRequestPermissionsResult(requestCode, permissions, grantResults) // ADD THIS LINE INSIDE onRequestPermissionResult
    }


    fun checkPermission() {
        startActivityForResult(Intent(this, QRScannerActivity::class.java), QRScannerActivity.BARCODE)
    //        PermissionX.init(this)
//            .permissions(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
//            .request { allGranted, grantedList, deniedList ->
//                if (allGranted) {
//                    Toast.makeText(this, "All permissions are granted", Toast.LENGTH_LONG).show()
//                    startActivityForResult(Intent(this, QRScannerActivity::class.java), LoginFragment.QR_Result)
//                } else {
//                    Toast.makeText(this, "These permissions are denied: $deniedList", Toast.LENGTH_LONG).show()
//                }
//            }
    }

    override fun onBackPressed() {
        ConfirmationDialog.newInstance(applicationContext?.getString(R.string.exit_msg), null, object : ConfirmationDialog.DialogClickListener {
            override fun onSelectionDone(exit: Boolean) {
                if (exit)
                    finish()
            }
        }).show(supportFragmentManager, "ConfirmationDialog")
    }

}