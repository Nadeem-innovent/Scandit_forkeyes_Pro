package com.forkeye.invo.data.local.db.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.forkeye.invo.data.local.db.entities.*

@Dao
interface DropOffDAO {

    companion object {

        const val TABLE_NAME = "DropOffIndoorTable"
        const val ID = "id"
        const val PALLET_SERIAL_NO = "pallet_sr_no"
        const val LAST_DETECT_TIME = "last_detect_time"
        const val SOURCE = "source"
        const val USER = "user"
        const val PROCESS = "process"
        const val FORK_LIFT_SERIAL_NUMBER = "fork_lift_sr_no"
        const val LOCATION = "location"
        const val LOCATION_DETAILS = "location_details"
        const val L5_LOCATION = "L5_location"
        const val TRUCK_PLATE = "truck_plate"
        const val IMAGE = "image"
        const val MAPPED_ZONE = "mapped_zone"
        const val PUSH_TO_SERVER = "pushed"
        const val BIN_LOC = "BinLocation"
        const val L5_LOC = "L5Location"
        const val LANE = "Lane"
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: DropOffEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(items: ArrayList<DropOffEntity>): List<Long>

    @Query("SELECT COUNT(*) from $TABLE_NAME")
    fun getCount(): Int

    @Query("select * from $TABLE_NAME where $PALLET_SERIAL_NO like :text")
    fun searchByUserName(text: String): List<DropOffEntity>

    @Query("select * from ${TABLE_NAME} where not ${PUSH_TO_SERVER} order by $ID LIMIT 10")
    fun getAllNonPushed(): List<DropOffEntity>

    @Query("select * from ${TABLE_NAME} where ${PUSH_TO_SERVER}")
    fun getAllPushed(): List<DropOffEntity>

    @Query("select * from ${TABLE_NAME} where ${PUSH_TO_SERVER}  order by $ID LIMIT 10")
    fun getLastTenPushed(): List<DropOffEntity>

    @Query("select * from ${TABLE_NAME} where not ${PUSH_TO_SERVER}")
    fun getAllNonPush(): LiveData<List<DropOffEntity>>


    @Query("select * from ${TABLE_NAME}")
    fun getAll(): LiveData<List<DropOffEntity>>

    @Query("select * from ${TABLE_NAME} order by ${ID} desc LIMIT 1")
    fun getLastItem(): DropOffEntity

    @Query("delete from $TABLE_NAME")
    fun deleteAll()

    @Delete
    fun delete(item: DropOffEntity)

    @Update
    fun update(item: DropOffEntity)

    @Update
    fun update(items: List<DropOffEntity>)
}