package com.forkeye.invo.ui.main

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.view.*
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.*
import androidx.core.content.ContextCompat.getColor
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.observe
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.commons.adapters.BaseListAdapter
import com.alexvas.rtsp.RtspClient
import com.alexvas.rtsp.demo.decode.AudioDecodeThread
import com.alexvas.rtsp.demo.decode.FrameQueue
import com.alexvas.rtsp.demo.decode.VideoDecodeThread
import com.alexvas.utils.NetUtils
import com.alexvas.utils.VideoCodecUtils
import com.forkeye.invo.R
import com.forkeye.invo.data.local.db.entities.DropOffEntity
import com.forkeye.invo.data.local.pref.PrefKeys
import com.forkeye.invo.data.local.pref.PrefUtils
import com.forkeye.invo.ui.AdminLoginActivity
import com.forkeye.invo.ui.ManualActivity
import com.forkeye.invo.ui.SettingActivity
import com.forkeye.invo.ui.SplashActivity
import com.forkeye.invo.ui.adaptor.PalletDropListViewProvider
import com.forkeye.invo.ui.base.BaseActivity
import com.forkeye.invo.ui.dialog.*
import com.forkeye.invo.ui.map.MapActivity
import com.forkeye.invo.utils.ConnectionModel
import com.forkeye.invo.utils.LocationUtils
import com.google.android.gms.maps.model.LatLng
import com.google.mlkit.vision.barcode.Barcode
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.zxing.*
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.qrcode.QRCodeReader
import kotlinx.android.synthetic.main.activity_manual.*
import kotlinx.android.synthetic.main.fragment_main.*
import kotlinx.coroutines.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.io.ByteArrayOutputStream
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.log


private const val DEFAULT_RTSP_PORT = 554
private val TAG: String = "ForkEye"
private const val DEBUG = true


class MainFragment : Fragment(), TextureView.SurfaceTextureListener {


    val mainViewModel by viewModel<MainViewModel>()
    private var videoFrameQueue: FrameQueue = FrameQueue()
    private var audioFrameQueue: FrameQueue = FrameQueue()
    private var rtspThread: RtspThread? = null
    private var videoDecodeThread: VideoDecodeThread? = null
    private var audioDecodeThread: AudioDecodeThread? = null
    private var rtspStopped: AtomicBoolean = AtomicBoolean(true)
    private var btnStartStop: ImageView? = null
    private var surface: Surface? = null
    private var surfaceWidth: Int = 1920
    private var surfaceHeight: Int = 1080

    private var userNameTv: TextView? = null
    private var sampleImg: ImageView? = null
    private var takePic: LinearLayout? = null
    private var qrValue: TextView? = null
    private var zoneValue: TextView? = null
    private var operationSelected: TextView? = null
    private var cameraStatus: TextView? = null
    private var videoMimeType: String = ""
    private var audioMimeType: String = ""
    private var audioSampleRate: Int = 0
    private var audioChannelCount: Int = 0
    private var audioCodecConfig: ByteArray? = null
    private var startDecodeBarCode: AtomicBoolean = AtomicBoolean(false)
    var textureView: TextureView? = null
    var scannerView: ImageView? = null


    var defaultOperBtn: Button? = null
    var truckTransitBtn: Button? = null
    var shippingTruckBtn: Button? = null
    var insideBtn: Button? = null
    var manualGPS: Button? = null
    var palletListRV: RecyclerView? = null
    var plantId: TextView? = null
    var qrSet = HashSet<String>()
    var insideZoneSelected: String = ""


    companion object {
        @JvmStatic
        fun getInstance() =
            MainFragment()
    }

    fun onRtspClientStarted() {
        if (DEBUG) Log.v(TAG, "onRtspClientStarted()")
        rtspStopped.set(false)
        btnStartStop?.setImageResource(R.drawable.ic_logout)
    }

    fun onRtspClientStopped() {
        if (DEBUG) Log.v(TAG, "onRtspClientStopped()")
        rtspStopped.set(true)
        btnStartStop?.setImageResource(R.drawable.ic_refresh)
        videoDecodeThread?.interrupt()
        videoDecodeThread = null
        audioDecodeThread?.interrupt()
        audioDecodeThread = null
    }

    fun onRtspClientConnected() {
        if (DEBUG) Log.v(TAG, "onRtspClientConnected()")
        if (videoMimeType.isNotEmpty()) {
            Log.i(TAG, "Starting video decoder with mime type \"$videoMimeType\"")
            videoDecodeThread = VideoDecodeThread(
                surface!!,
                videoMimeType,
                surfaceWidth,
                surfaceHeight,
                videoFrameQueue
            )
            videoDecodeThread?.start()
        }
        if (audioMimeType.isNotEmpty()) {
            Log.i(TAG, "Starting audio decoder with mime type \"$audioMimeType\"")
            audioDecodeThread = AudioDecodeThread(
                audioMimeType,
                audioSampleRate,
                audioChannelCount,
                audioCodecConfig,
                audioFrameQueue
            )
            audioDecodeThread?.start()
        }
    }


    inner class RtspThread : Thread() {
        override fun run() {
            Handler(Looper.getMainLooper()).post { onRtspClientStarted() }
            val listener = object : RtspClient.RtspClientListener {
                override fun onRtspDisconnected() {
                    if (DEBUG) Log.v(TAG, "onRtspDisconnected()")
                    Handler(Looper.getMainLooper()).post { cameraStatus?.text = "RTSP disconnected" }
                    rtspStopped.set(true)
                }

                override fun onRtspFailed(message: String?) {
                    Log.e(TAG, "onRtspFailed(message=\"$message\")")
                    Handler(Looper.getMainLooper()).post {
                        cameraStatus?.text = "RTSP failed: $message"
                    }
                    rtspStopped.set(true)

                    if (rtspStopped.get()) {
                        if (DEBUG) Log.d(TAG, "Starting RTSP thread...")
                        rtspThread = RtspThread()
                        rtspThread?.start()
                    }
                }

                override fun onRtspConnected(sdpInfo: RtspClient.SdpInfo) {
                    if (DEBUG) Log.v(TAG, "onRtspConnected()")
                    Handler(Looper.getMainLooper()).post {
                        var s = ""
                        if (sdpInfo.videoTrack != null)
                            s = "video"
                        if (sdpInfo.audioTrack != null) {
                            if (s.length > 0)
                                s += ", "
                            s += "audio"
                        }
                        cameraStatus?.text = "RTSP connected ($s)"
                    }
                    if (sdpInfo.videoTrack != null) {
                        videoFrameQueue.clear()
                        when (sdpInfo.videoTrack?.videoCodec) {
                            RtspClient.VIDEO_CODEC_H264 -> videoMimeType = "video/avc"
                            RtspClient.VIDEO_CODEC_H265 -> videoMimeType = "video/hevc"
                        }
                        when (sdpInfo.audioTrack?.audioCodec) {
                            RtspClient.AUDIO_CODEC_AAC -> audioMimeType = "audio/mp4a-latm"
                        }
                        val sps: ByteArray? = sdpInfo.videoTrack?.sps
                        val pps: ByteArray? = sdpInfo.videoTrack?.pps
                        // Initialize decoder
                        if (sps != null && pps != null) {
                            val data = ByteArray(sps.size + pps.size)
                            sps.copyInto(data, 0, 0, sps.size)
                            pps.copyInto(data, sps.size, 0, pps.size)
                            videoFrameQueue.push(FrameQueue.Frame(data, 0, data.size, 0))

                        } else {
                            if (DEBUG) Log.d(TAG, "RTSP SPS and PPS NAL units missed in SDP")
                        }
                    }
                    if (sdpInfo.audioTrack != null) {
                        audioFrameQueue.clear()
                        when (sdpInfo.audioTrack?.audioCodec) {
                            RtspClient.AUDIO_CODEC_AAC -> audioMimeType = "audio/mp4a-latm"
                        }
                        audioSampleRate = sdpInfo.audioTrack?.sampleRateHz!!
                        audioChannelCount = sdpInfo.audioTrack?.channels!!
                        audioCodecConfig = sdpInfo.audioTrack?.config
                    }
                    onRtspClientConnected()
                }

                override fun onRtspFailedUnauthorized() {
                    Log.e(TAG, "onRtspFailedUnauthorized()")
                    Handler(Looper.getMainLooper()).post {
                        cameraStatus?.text = "RTSP username or password is incorrect"
                    }
                    rtspStopped.set(true)
                }

                override fun onRtspVideoNalUnitReceived(
                    data: ByteArray,
                    offset: Int,
                    length: Int,
                    timestamp: Long
                ) {
                    if (DEBUG) Log.v(
                        TAG,
                        "onRtspVideoNalUnitReceived(length=$length, timestamp=$timestamp)"
                    )
                    if (DEBUG) {
                        val nals: ArrayList<VideoCodecUtils.NalUnit> = ArrayList()
                        val numNals = VideoCodecUtils.getH264NalUnits(
                            data,
                            offset,
                            length - 1,
                            nals
                        )

                        //TODO data is our frame with QR to be render
                        //Or save as Image
                    }
                    if (length > 0)
                        videoFrameQueue.push(FrameQueue.Frame(data, offset, length, timestamp))


                    if (startDecodeBarCode.get()) {
                        detectBarCodeML(textureView?.bitmap!!)
                        Log.i(TAG, "QR Scanning : Bitmap Gone For Decoding...")
                    }
                }

                override fun onRtspAudioSampleReceived(
                    data: ByteArray,
                    offset: Int,
                    length: Int,
                    timestamp: Long
                ) {
                    if (DEBUG) Log.v(
                        TAG,
                        "onRtspAudioSampleReceived(length=$length, timestamp=$timestamp)"
                    )
                    if (length > 0)
                        audioFrameQueue.push(FrameQueue.Frame(data, offset, length, timestamp))
                }

                override fun onRtspConnecting() {
                    if (DEBUG) Log.v(TAG, "onRtspConnecting()")
                    Handler(Looper.getMainLooper()).post { cameraStatus?.text = "RTSP connecting" }
                }
            }
            val uri: Uri = Uri.parse(mainViewModel.DEFAULT_RTSP_REQUEST)
            val port = if (uri.port == -1) DEFAULT_RTSP_PORT else uri.port
            val username = mainViewModel.DEFAULT_RTSP_USERNAME
            val password = mainViewModel.DEFAULT_RTSP_PASSWORD
            try {
                if (DEBUG) Log.d(TAG, "Connecting to ${uri.host.toString()}:$port...")
                val socket: Socket = NetUtils.createSocketAndConnect(
                    uri.host.toString(),
                    port,
                    5000
                )

                // Blocking call until stopped variable is true or connection failed
                val rtspClient = RtspClient.Builder(socket, uri.toString(), rtspStopped, listener)
                    .requestVideo(true)
                    .requestAudio(false)
                    .withDebug(true)
                    .withUserAgent("RTSP test")
                    .withCredentials(username, password)
                    .build()
                rtspClient.execute()

                NetUtils.closeSocket(socket)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            Handler(Looper.getMainLooper()).post { onRtspClientStopped() }
        }
    }

    var palletList = MutableLiveData<List<DropOffEntity>>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //liveViewModel =
        //ViewModelProvider(this).get(LiveViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_main, container, false)

        textureView = root.findViewById(R.id.textureView)
        scannerView = root.findViewById(R.id.scan_view_img)
        operationSelected = root.findViewById(R.id.text_status)
        cameraStatus = root.findViewById(R.id.cameraStatus)
        takePic = root.findViewById(R.id.takePic)
        sampleImg = root.findViewById(R.id.sampleImg)
        userNameTv = root.findViewById(R.id.tv_username)
        qrValue = root.findViewById(R.id.qrCodeVal)
        zoneValue = root.findViewById(R.id.zoneVal)
        defaultOperBtn = root.findViewById(R.id.defaultOperBtn)
        truckTransitBtn = root.findViewById(R.id.truckTransitBtn)
        shippingTruckBtn = root.findViewById(R.id.shippingTruckBtn)
        insideBtn = root.findViewById(R.id.insideBtn)
        manualGPS = root.findViewById(R.id.manualScanBtn)
        palletListRV = root.findViewById(R.id.pallet_list)
        plantId = root.findViewById(R.id.plantId)

        root.findViewById<ImageView>(R.id.settingImg).setOnClickListener {
            (activity as BaseActivity).startActivity(AdminLoginActivity::class.java)
        }

        userNameTv?.apply {
            text = PrefUtils.getFromPrefs(context, PrefKeys.USER_NAME, "") as String
        }

        plantId?.apply {
            text = (PrefUtils.getFromPrefs(context, PrefKeys.REG_PLANT_ID, "") as String) +
                    "_" + (PrefUtils.getFromPrefs(context, PrefKeys.FORK_LIFT_REG_NO, "") as String)
        }

        root.findViewById<LinearLayout>(R.id.ll_turn).setOnClickListener {
            (activity as BaseActivity).startActivity(MapActivity::class.java)
        }


        palletListRV?.apply {
            layoutManager = LinearLayoutManager(context)
            isNestedScrollingEnabled = false
            adapter = BaseListAdapter(
                PalletDropListViewProvider(
                    requireContext(), null
                )
            )
        }

        var list = ArrayList<DropOffEntity>()
        mainViewModel?.palletExternalListLD
            .observe(viewLifecycleOwner) { t1 ->
                list.clear()
                // do something with combined livedata values
                t1?.let {
                    list.addAll(t1)
                }

                if (list != null && list.size > 0) {
                    palletListRV?.visibility = View.VISIBLE
                    nothing_view.visibility = View.GONE
                    (palletListRV?.adapter as BaseListAdapter).items = list.reversed()
                    (palletListRV?.adapter as BaseListAdapter).notifyDataSetChanged()
                } else {
                    palletListRV?.visibility = View.GONE
                    nothing_view.visibility = View.VISIBLE
                }

            }


        textureView?.surfaceTextureListener = this

        btnStartStop = root.findViewById(R.id.button_start_stop_rtsp)
        btnStartStop?.setOnClickListener {
            startRefreshCameraStream()
        }

        takePic?.setOnClickListener {
            sampleImg?.post {
                //sampleImg?.setImageBitmap(textureView?.bitmap)
                val bm = textureView?.bitmap
                val baos = ByteArrayOutputStream()
                bm?.compress(Bitmap.CompressFormat.JPEG, 100, baos) // bm is the bitmap object

                val encodedImage: String = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                val save = mainViewModel.addImageToLastDropOff(encodedImage)
                if (save)
                    showAlert("Image Saved Succesfully!")
            }
        }


        mainViewModel.qrCodeValue.observe(viewLifecycleOwner, androidx.lifecycle.Observer {
            if (!it.isNullOrEmpty() && it.length == 20 && !it.startsWith("321")) {
                var qrString: java.lang.StringBuilder = java.lang.StringBuilder()
                for (qr in qrSet) {
                    qrString.append(qr).append(",")
                }

                //QR Code Found Stop Scanning
                if (!it.equals("Not Found", false)
                    && !it.equals("CheckSum Issue", false)
                    && !it.equals("Waiting..", false)) {
                    //startDecodeBarCode.set(false)
                    Log.i(TAG, "QR Scanning : QR Code ${it}")
                    //Log.i(TAG, "QR Scanning : Closed...")

                    qrSet.add(it)
                    mainViewModel.viewModelScope.async(Dispatchers.Main) {
                        qrValue?.text = "found..."
                        delay(300)
                        qrValue?.text = qrString
                    }
                }
            } else {
                qrValue?.text = "Invalid Qr.. ${it}"
            }
//            else {
//                if (it.isNullOrEmpty() || !it.equals("Waiting..", false))
//                    showDrofOffManualDialog()
//            }
        })

        mainViewModel.pickedQualified.observe(viewLifecycleOwner) {
            if (it) {
                startDecodeBarCode.set(true)
                scannerView?.visibility = View.VISIBLE
                scannerView?.let { makeMeBlink(it, 20L) }
                mainViewModel.viewModelScope.async(Dispatchers.Main) {
                    qrSet.clear()
                    qrValue?.text = "--"
                    delay(5000)
                    scannerView?.clearAnimation()
                    scannerView?.visibility = View.GONE
                    startDecodeBarCode.set(false)
                    //TODO Push to DB here
                    if (qrSet.isEmpty()) {
                        showDrofOffManualDialog()
                        return@async
                    }


                    if (mainViewModel.dropOffType == MainViewModel.DROP_OFF_TYPE.DEFAULT) {
                        var dialog = LfiveDialog.newInstance(
                            "",
                            "",
                            object : LfiveDialog.SimpleDialogClickListener {


                                override fun onSelectionDone(locDetails: String, lane: String, bin: String, l5Selection: String) {
                                    val zoneLoc = l5Selection
                                    zoneValue?.text = l5Selection

                                    var loc = LocationUtils.getLocationFromQueue()
                                    if (loc.isNullOrEmpty()) {
                                        loc = mainViewModel.location
                                    }
                                    if (!loc.isNullOrEmpty()) {

                                        var locArr = loc!!.split(";")
                                        var latLng = LatLng(locArr.get(1).toDouble(), locArr.get(0).toDouble())
                                        if (LocationUtils.isLocationInRAK(latLng.latitude, latLng.longitude)) {
                                            for (qrCode in qrSet) {
                                                mainViewModel.dropOffDefault(qrCode, loc!!, locDetails, lane, bin, l5Selection)
                                            }
                                        } else {
                                            showAlert(context?.getString(R.string.location_outside_the_prem))
                                        }

                                    } else {
                                        showDrofOffManualDialog()
                                    }
                                }
                            })
                        dialog.isCancelable = false
                        dialog.show(activity?.supportFragmentManager!!, LfiveDialog.TAG)
                    } else if (mainViewModel.dropOffType == MainViewModel.DROP_OFF_TYPE.TRUCK_TRANSIT) {

                        mainViewModel.viewModelScope.async {
                            var sendToDB = false
                            val dialog = TransitToTruckDialog.newInstance(object : TransitToTruckDialog.DialogClickListener {
                                override fun onSelectionDone(transitToTruck: Boolean) {
                                    var loc = LocationUtils.getLocationFromQueue()
                                    if (loc.isNullOrEmpty()) {
                                        loc = mainViewModel.location
                                    }
                                    if (!loc.isNullOrEmpty()) {
                                        var locArr = loc!!.split(";")
                                        var latLng = LatLng(locArr.get(1).toDouble(), locArr.get(0).toDouble())
                                        if (LocationUtils.isLocationInRAK(latLng.latitude, latLng.longitude)) {
                                            for (qrCode in qrSet) {
                                                if (transitToTruck) {
                                                    sendToDB = true
                                                    mainViewModel.dropOffShip(qrCode, loc!!, MainViewModel.DROP_OFF_TYPE.TRUCK_TRANSIT)
                                                } else {
                                                    sendToDB = true
                                                    mainViewModel.dropOffShip(qrCode, loc!!, MainViewModel.DROP_OFF_TYPE.DEFAULT)
                                                }
                                            }
                                        } else {
                                            showAlert(context?.getString(R.string.location_outside_the_prem))
                                        }
                                    } else {
                                        showDrofOffManualDialog()
                                    }
                                }
                            })
                            dialog.isCancelable = false
                            dialog.show(activity?.supportFragmentManager!!, TransitToTruckDialog.TAG)
                            delay(10000)
                            if (!sendToDB) {
                                var loc = LocationUtils.getLocationFromQueue()
                                if (loc.isNullOrEmpty()) {
                                    loc = mainViewModel.location
                                }
                                if (!loc.isNullOrEmpty()) {

                                    var locArr = loc!!.split(";")
                                    var latLng = LatLng(locArr.get(1).toDouble(), locArr.get(0).toDouble())
                                    if (LocationUtils.isLocationInRAK(latLng.latitude, latLng.longitude)) {
                                        for (qrCode in qrSet) {
                                            mainViewModel.dropOffShip(qrCode, loc!!, MainViewModel.DROP_OFF_TYPE.TRUCK_TRANSIT)
                                        }
                                    } else {
                                        showAlert(context?.getString(R.string.location_outside_the_prem))
                                    }

                                } else {
                                    showDrofOffManualDialog()
                                }

                            }
                            dialog.dismiss()
                        }
                    } else if (mainViewModel.dropOffType == MainViewModel.DROP_OFF_TYPE.SHIPPING_TRUCK) {

                        mainViewModel.viewModelScope.async {
                            var sendToDB = false
                            val dialog = TransitToTruckDialog.newInstance(object : TransitToTruckDialog.DialogClickListener {
                                override fun onSelectionDone(transitToTruck: Boolean) {
                                    var loc = LocationUtils.getLocationFromQueue()
                                    if (loc.isNullOrEmpty()) {
                                        loc = mainViewModel.location
                                    }
                                    if (!loc.isNullOrEmpty()) {

                                        var locArr = loc!!.split(";")
                                        var latLng = LatLng(locArr.get(1).toDouble(), locArr.get(0).toDouble())
                                        if (LocationUtils.isLocationInRAK(latLng.latitude, latLng.longitude)) {
                                            for (qrCode in qrSet) {
                                                if (transitToTruck) {
                                                    sendToDB = true
                                                    mainViewModel.dropOffShip(qrCode, loc!!, MainViewModel.DROP_OFF_TYPE.SHIPPING_TRUCK)
                                                } else {
                                                    sendToDB = true
                                                    mainViewModel.dropOffShip(qrCode, loc!!, MainViewModel.DROP_OFF_TYPE.DEFAULT)
                                                }
                                            }
                                        } else {
                                            showAlert(context?.getString(R.string.location_outside_the_prem))
                                        }
                                    } else {
                                        showDrofOffManualDialog()
                                    }

                                }
                            })
                            dialog.show(activity?.supportFragmentManager!!, TransitToTruckDialog.TAG)
                            delay(10000)
                            var loc = LocationUtils.getLocationFromQueue()
                            if (loc.isNullOrEmpty()) {
                                loc = mainViewModel.location
                            }
                            if (!loc.isNullOrEmpty()) {
                                var locArr = loc!!.split(";")
                                var latLng = LatLng(locArr.get(1).toDouble(), locArr.get(0).toDouble())
                                if (LocationUtils.isLocationInRAK(latLng.latitude, latLng.longitude)) {
                                    if (!sendToDB) {
                                        for (qrCode in qrSet) {
                                            mainViewModel.dropOffShip(qrCode, loc!!, MainViewModel.DROP_OFF_TYPE.SHIPPING_TRUCK)
                                        }
                                    }
                                } else {
                                    showAlert(context?.getString(R.string.location_outside_the_prem))
                                }
                            } else {
                                showDrofOffManualDialog()
                            }

                            dialog.dismiss()
                        }
                    } else if (mainViewModel.dropOffType == MainViewModel.DROP_OFF_TYPE.INSIDE) {
                        for (qrCode in qrSet) {
                            mainViewModel.dropOffInside(qrCode, insideZoneSelected)
                        }

                    } else {
                        var loc = LocationUtils.getLocationFromQueue()

                        if (loc.isNullOrEmpty()) {
                            loc = mainViewModel.location
                        }
                        if (!loc.isNullOrEmpty()) {
                            var locArr = loc!!.split(";")
                            var latLng = LatLng(locArr.get(1).toDouble(), locArr.get(0).toDouble())
                            if (LocationUtils.isLocationInRAK(latLng.latitude, latLng.longitude)) {
                                for (qrCode in qrSet) {
                                    mainViewModel.dropOffShip(qrCode, loc!!, MainViewModel.DROP_OFF_TYPE.DEFAULT)
                                }
                            } else {
                                showAlert(context?.getString(R.string.location_outside_the_prem))
                            }
                        } else {
                            showDrofOffManualDialog()
                        }
                    }
                    Log.i(TAG, "QR Scanning : Picked Qualified ${it}")

                    mainViewModel.viewModelScope.async(Dispatchers.IO) {
                        startRefreshCameraStream()
                        delay(3000)
                        startRefreshCameraStream()
                    }
                }
            }
        }

        //Motion and GNS Sensor

        val loaderSensorStatus = root.findViewById<TextView>(R.id.loaderSensorTv)
        val loaderOperationTv = root.findViewById<TextView>(R.id.loadingStatusTv)
        val locationSensorStatus = root.findViewById<TextView>(R.id.locSensorTv)
        root.findViewById<ImageView>(R.id.logoutImg).setOnClickListener {
            PrefUtils.saveToPrefs(context, PrefKeys.USER_LOG_IN, false)
            //PrefUtils.saveToPrefs(context, PrefKeys.FORK_REG, false)
            val splashIntent = Intent(context, SplashActivity::class.java)
            splashIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(splashIntent)
            activity?.finish()
        }


        mainViewModel.loaderLD.observe(viewLifecycleOwner, androidx.lifecycle.Observer {
            when (it) {
                DeviceStatus.CONNNECTED -> {
                    context?.let { context -> loaderSensorStatus.setTextColor(getColor(context, R.color.green1)) }
                    loaderSensorStatus.text = context?.getString(R.string.connected)
                }
                DeviceStatus.LOADED -> {
                    context?.let { context -> loaderSensorStatus.setTextColor(getColor(context, R.color.green1)) }
                    loaderOperationTv.text = context?.getString(R.string.loaded)
                }
                DeviceStatus.UNLOADED -> {
                    context?.let { context -> loaderSensorStatus.setTextColor(getColor(context, R.color.green1)) }
                    loaderOperationTv.text = context?.getString(R.string.unloaded)
                }
                DeviceStatus.ERROR -> {
                    context?.let { context -> loaderSensorStatus.setTextColor(getColor(context, R.color.red1)) }
                    loaderSensorStatus.text = context?.getString(R.string.error)
                }
                DeviceStatus.WAITING -> {
                    context?.let { context -> loaderSensorStatus.setTextColor(getColor(context, R.color.red1)) }
                    loaderSensorStatus.text = context?.getString(R.string.waiting)
                }
                DeviceStatus.CONNENTING -> {
                    context?.let { context -> loaderSensorStatus.setTextColor(getColor(context, R.color.red1)) }
                    loaderSensorStatus.text = context?.getString(R.string.connecting)
                }
                DeviceStatus.STARTING -> {
                    context?.let { context -> loaderSensorStatus.setTextColor(getColor(context, R.color.red1)) }
                    loaderSensorStatus.text = context?.getString(R.string.starting)
                }
                DeviceStatus.DISCONECTED -> {
                    context?.let { context -> loaderSensorStatus.setTextColor(getColor(context, R.color.red1)) }
                    loaderSensorStatus.text = context?.getString(R.string.disconnected)
                }
            }

        })



        mainViewModel.locationLD.observe(viewLifecycleOwner, androidx.lifecycle.Observer {

            when (it) {
                DeviceStatus.CONNNECTED -> {
                    context?.let { context -> locationSensorStatus.setTextColor(getColor(context, R.color.green1)) }
                    locationSensorStatus.text = context?.getString(R.string.connected)
                }
                DeviceStatus.ERROR -> {
                    context?.let { context -> locationSensorStatus.setTextColor(getColor(context, R.color.red1)) }
                    locationSensorStatus.text = context?.getString(R.string.error)
                }
                DeviceStatus.WAITING -> {
                    context?.let { context -> locationSensorStatus.setTextColor(getColor(context, R.color.red1)) }
                    locationSensorStatus.text = context?.getString(R.string.waiting)
                }
                DeviceStatus.CONNENTING -> {
                    context?.let { context -> locationSensorStatus.setTextColor(getColor(context, R.color.red1)) }
                    locationSensorStatus.text = context?.getString(R.string.connecting)
                }
                DeviceStatus.STARTING -> {
                    context?.let { context -> locationSensorStatus.setTextColor(getColor(context, R.color.red1)) }
                    locationSensorStatus.text = context?.getString(R.string.starting)
                }
                DeviceStatus.DISCONECTED -> {
                    context?.let { context -> locationSensorStatus.setTextColor(getColor(context, R.color.red1)) }
                    locationSensorStatus.text = context?.getString(R.string.disconnected)
                }
            }
        })

        mainViewModel.connectionLiveData.observe(viewLifecycleOwner, {
            if (it?.type == ConnectionModel.Companion.Type.WIFI)
                networkState.text = context?.getString(R.string.connected)
            else
                networkState.text = context?.getString(R.string.disconnected)
        })

        processButton(R.id.defaultOperBtn)
        defaultOperBtn?.setOnClickListener { processButton(R.id.defaultOperBtn) }
        truckTransitBtn?.setOnClickListener { processButton(R.id.truckTransitBtn) }
        shippingTruckBtn?.setOnClickListener { processButton(R.id.shippingTruckBtn) }
        insideBtn?.setOnClickListener {
            var dialog = LocationDialog.newInstance(object : LocationDialog.DialogClickListener {
                override fun onSelectionDone(zoneSelected: String) {
                    insideZoneSelected = zoneSelected
                }
            })
            dialog.isCancelable = false
            dialog.show(activity?.supportFragmentManager!!, LfiveDialog.TAG)
            processButton(R.id.insideBtn)
        }
        manualGPS?.setOnClickListener { manualProcessGPS() }
        //startStreamRoutine()
        return root
    }

    private fun startRefreshCameraStream() {
        if (rtspStopped.get()) {
            if (DEBUG) Log.d(TAG, "Starting RTSP thread...")
            rtspThread = RtspThread()
            rtspThread?.start()
        } else {
            if (DEBUG) Log.d(TAG, "Stopping RTSP thread...")
            rtspStopped.set(true)
            rtspThread?.interrupt()
        }
    }

    fun startStreamRoutine() {
        mainViewModel.viewModelScope.async(Dispatchers.IO) {
            while (true) {
                if (rtspStopped.get()) {
                    if (DEBUG) Log.d(TAG, "Starting RTSP thread...")
                    rtspThread = RtspThread()
                    rtspThread?.start()
                } else {
                    return@async
                }
                delay(1000)
            }
        }
    }

    fun processButton(id: Int) {

        defaultOperBtn?.setBackgroundResource(R.drawable.rect_white_round)
        truckTransitBtn?.setBackgroundResource(R.drawable.rect_white_round)
        shippingTruckBtn?.setBackgroundResource(R.drawable.rect_white_round)
        insideBtn?.setBackgroundResource(R.drawable.rect_white_round)
        when (id) {
            R.id.defaultOperBtn -> {
                insideZoneSelected = ""
                mainViewModel.dropOffType = MainViewModel.DROP_OFF_TYPE.DEFAULT
                defaultOperBtn?.setBackgroundResource(R.drawable.rect_green)
            }
            R.id.truckTransitBtn -> {
                insideZoneSelected = ""
                mainViewModel.dropOffType = MainViewModel.DROP_OFF_TYPE.TRUCK_TRANSIT
                truckTransitBtn?.setBackgroundResource(R.drawable.rect_green)
            }
            R.id.shippingTruckBtn -> {
                insideZoneSelected = ""
                mainViewModel.dropOffType = MainViewModel.DROP_OFF_TYPE.SHIPPING_TRUCK
                shippingTruckBtn?.setBackgroundResource(R.drawable.rect_green)
            }
            R.id.insideBtn -> {
                mainViewModel.dropOffType = MainViewModel.DROP_OFF_TYPE.INSIDE
                insideBtn?.setBackgroundResource(R.drawable.rect_green)
            }
        }
        operationSelected?.text = mainViewModel.dropOffType.type
    }

    fun manualProcessGPS() {
        var bundle = Bundle()
        bundle.putString(ManualActivity.DROP_OF_TYPE, mainViewModel.dropOffType.type)
        (activity as BaseActivity)?.startActivity(ManualActivity::class.java, bundle)
        //mainViewModel.dropOffDefault("000123456789", "55.791446;25.677051","MC-5")
//        var result = LocationUtils.isLocationInRAK(25.683994,55.786800)
//        Log.d("location", "Is location in RAK $result")

    }

    fun showAlert(msg: String?) {
        activity?.let {
            AlertDialog.newInstance(msg, null, null).show(it?.supportFragmentManager, "ConfirmationDialog")
        }
    }

    fun showDrofOffManualDialog() {
        activity?.let {
            var dialog = ConfirmationDialog.newInstance(
                context?.getString(R.string.bad_qr_code_manual),
                null,
                object : ConfirmationDialog.DialogClickListener {
                    override fun onSelectionDone(transitToTruck: Boolean) {
                        manualProcessGPS()
                    }
                }).show(it?.supportFragmentManager, "ConfirmationDialog")
        }
    }

    val options = BarcodeScannerOptions.Builder()
        .setBarcodeFormats(
            Barcode.FORMAT_QR_CODE,
            Barcode.FORMAT_AZTEC
        )
        .build()

    fun detectBarCodeML(bitmap: Bitmap) {
        mainViewModel.viewModelScope.async(Dispatchers.IO) {
            try {
                val inputImg = InputImage.fromBitmap(bitmap, 0)
                val scanner = BarcodeScanning.getClient(options)
                val mlkitResult = scanner.process(inputImg)
                    .addOnSuccessListener { barcodes ->
                        // Task completed successfully
                        // ...
                        for (barcode in barcodes) {
                            Log.d("QRCodeScanner", "qrcode=" + barcode.rawValue)
                            //mlQrCodeVal.setText(barcode.rawValue)
                            mainViewModel.qrCodeValue.postValue(barcode.rawValue)
                            Log.i(TAG, "detectBarCode: " + barcode.rawValue)
                            //return barcode.rawValue
                        }
                    }
                    .addOnFailureListener {
                        // Task failed with an exception
                        // ...
                        Log.e("QRCodeScanner", "mlkit error", it)
                        //mainViewModel.qrCodeValue.postValue(null)
                    }
                delay(200)
            } catch (ex: java.lang.Exception) {
                Log.e("detectebar code", "" + ex.message)
                //mainViewModel.qrCodeValue.postValue(null)
            }
        }
    }

    fun makeMeBlink(view: View, offset: Long): View? {
        val anim: Animation = AlphaAnimation(0.0f, 1.0f)
        anim.duration = 100L
        anim.startOffset = offset
        anim.setRepeatMode(Animation.REVERSE)
        anim.setRepeatCount(Animation.INFINITE)
        view.startAnimation(anim)
        return view
    }


//    fun detectBarCode(bitmap: Bitmap): String? {
//        //val bitmap1 = BitmapFactory.decodeResource(activity?.resources, R.mipmap.qr_code_two)
//
//        val pixels = IntArray(bitmap.width * bitmap.getHeight())
//        bitmap.getPixels(pixels, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight())
//
//        val source = RGBLuminanceSource(
//            bitmap.getWidth(),
//            bitmap.getHeight(), pixels
//        )
//        val binarizer = GlobalHistogramBinarizer(source)
//        val image = BinaryBitmap(binarizer)
//        var result: Result? = null
//        try {
//            result = QRCodeReader().decode(image)
//            mainViewModel.qrCodeValue.postValue(result.text)
//            Log.i(TAG, "detectBarCode: " + result.text)
//            return result.text
//        } catch (e: NotFoundException) {
//            //mainViewModel.qrCodeValue.postValue("Not Found")
//            Log.i(TAG, "detectBarCode: Not Found " + result?.text)
//            e.printStackTrace()
//        } catch (e: ChecksumException) {
//            //mainViewModel.qrCodeValue.postValue("CheckSum Issue")
//            Log.i(TAG, "detectBarCode: ChecksumException " + result?.text)
//            e.printStackTrace()
//        } catch (e: FormatException) {
//            //mainViewModel.qrCodeValue.postValue("Format Issue")
//            e.printStackTrace()
//            Log.i(TAG, "detectBarCode: FormatException " + result?.text)
//        }
//
//        return null
//    }


    override fun onStart() {
        if (DEBUG) Log.v(TAG, "onStart()")
        super.onStart()
        startStreamRoutine()
        mainViewModel.resetSensorState()
        //mainViewModel.startSensorService()
        //liveViewModel.loadParams(context)
    }

    override fun onStop() {
        if (DEBUG) Log.v(TAG, "onStop()")
        super.onStop()
        //liveViewModel.saveParams(context)
        onRtspClientStopped()
        //mainViewModel.stopSensor()
    }


    override fun onSurfaceTextureAvailable(
        surfaceTexture: SurfaceTexture,
        width: Int,
        height: Int
    ) {
        if (DEBUG) Log.v(TAG, "onSurfaceTextureAvailable()")
        surface = Surface(surfaceTexture)
    }

    override fun onSurfaceTextureSizeChanged(
        surfaceTexture: SurfaceTexture,
        width: Int,
        height: Int
    ) {
        if (DEBUG) Log.v(TAG, "surfaceChanged(format=, width=$width, height=$height)")
        surface = Surface(surfaceTexture)
        surfaceWidth = width
        surfaceHeight = height
        if (videoDecodeThread != null) {
            videoDecodeThread?.interrupt()
            videoDecodeThread = VideoDecodeThread(
                surface!!,
                videoMimeType,
                width,
                height,
                videoFrameQueue
            )
            videoDecodeThread?.start()
        }
    }

    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        if (DEBUG) Log.v(TAG, "surfaceDestroyed()")
        videoDecodeThread?.interrupt()
        videoDecodeThread = null
        return true
    }

    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {
    }

}
