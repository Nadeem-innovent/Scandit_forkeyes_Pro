package com.forkeye.invo.data.local.db.entities

import java.io.Serializable

data class SaerchPallet(
    val serialNumber: String
):Serializable
