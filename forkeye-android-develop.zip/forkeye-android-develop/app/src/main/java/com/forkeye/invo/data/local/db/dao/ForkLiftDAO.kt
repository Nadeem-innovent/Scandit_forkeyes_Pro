package com.forkeye.invo.data.local.db.dao

import androidx.room.*
import com.forkeye.invo.data.local.db.entities.RegForkLiftEntity

@Dao
interface ForkLiftDAO {

    companion object {

        const val TABLE_NAME = "ForkLiftTable"
        const val ID = "ID"
        const val PROCESS = "Process"
        const val REG_NO = "Reg_No"
        const val PLANT_NO = "Plant"
        const val REG_DEVICES = "RegisteredDevice"
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(item: RegForkLiftEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(items: ArrayList<RegForkLiftEntity>): List<Long>

    @Query("SELECT COUNT(*) from $TABLE_NAME")
    fun getCount(): Int

    @Query("select * from $TABLE_NAME where $REG_NO like :text")
    fun searchByUserName(text: String): List<RegForkLiftEntity>

    @Query("delete from $TABLE_NAME")
    fun deleteAll()

    @Delete
    fun delete(item: RegForkLiftEntity)

    @Update
    fun update(item: RegForkLiftEntity)

    @Update
    fun update(items: List<RegForkLiftEntity>)
}