package com.forkeye.invo.data.local.pref

object PrefKeys {
    const val FORK_LIFT_REG_ID = "FORK_LIFT_REG_ID"
    const val REG_PLANT_ID = "REG_PLANT_ID"
    const val FORK_REG  = "USER_REG"
    const val LANGUAGE_PREF = "LANGUAGE_PREF"
    const val USER_LOG_IN = "USER_LOGGED_IN"
    const val USER_NAME = "USER_NAME"
    const val FORK_LIFT_REG_NO = "FORK_LIFT_SR_NO"
    const val PLANT_NO = "PLANT_NO"
    const val SERVER_IP_1 = "SERVER_IP_1"
    const val LOADER_SENSOR_PORT = "SERVER_IP_1_PORT"
    const val SERVER_IP_2 = "SERVER_IP_1"
    const val LOCATION_SENSOR_PORT = "SERVER_IP_2_PORT"
    const val FORK_LIFT_ID = "FORK_LIFT_ID"
    const val VIZIX_SERVER_URL = "VIZIX_SERVER_URL"
}