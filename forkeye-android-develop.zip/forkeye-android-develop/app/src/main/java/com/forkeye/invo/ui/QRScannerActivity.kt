package com.forkeye.invo.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import com.forkeye.invo.R

import com.forkeye.invo.ui.base.BaseActivity
import com.forkeye.invo.ui.login.LoginFragment
import com.google.zxing.Result
import me.dm7.barcodescanner.zxing.ZXingScannerView

class QRScannerActivity : BaseActivity(), ZXingScannerView.ResultHandler {
    var mScannerView: ZXingScannerView? = null
    var mScanLayout: LinearLayout? = null
    var cameraId: Int = -1
    var flashStateOn = false

    companion object {
        val BARCODE: Int = 1000
        val BAR_CODE_VAL: String = "barcode"
        val FRONT_FACING_CAM: String = "front_facing_cam"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_scanner)
        mScanLayout = findViewById(R.id.zx_scanner_view)
        // Programmatically initialize the scanner view
        mScannerView = ZXingScannerView(this)
        mScanLayout?.addView(mScannerView)
        if (intent.hasExtra("camId"))
            cameraId = intent.getIntExtra("camId", -1)

        findViewById<ImageView>(R.id.back).setOnClickListener {
            finish()
        }

        findViewById<ImageView>(R.id.flash).setOnClickListener {

            flashStateOn = !flashStateOn
            if (flashStateOn)
                (it as ImageView).setImageResource(R.drawable.flash_on)
            else
                (it as ImageView).setImageResource(R.drawable.flash_off)
            setFlash(flashStateOn)
        }
    }

    override fun onResume() {
        super.onResume()
        mScannerView?.setResultHandler(this) // Register ourselves as a handler for scan results.
        //mScannerView?.startCamera(CameraSource.CAMERA_FACING_FRONT) // Start camera on resume
        if (cameraId != -1)
            mScannerView?.startCamera(cameraId) // Start camera on resume
        else {
            mScannerView?.startCamera() // Start camera on resume
        }
    }

    override fun onPause() {
        super.onPause()
        mScannerView?.stopCamera();           // Stop camera on pause
    }

    override fun handleResult(rawResult: Result?) {
        // Do something with the result here
        Log.i("", "handleResult: ${rawResult?.getText()}")
        Log.i("", "${rawResult?.getBarcodeFormat().toString()}")
        // If you would like to resume scanning, call this method below:
        mScannerView?.resumeCameraPreview(this);

        //Toast.makeText(this, "Scan result: ${rawResult?.getText()}", Toast.LENGTH_LONG).show()
        var intent = Intent()
        intent.putExtra(BAR_CODE_VAL, rawResult?.getText())
        setResult(BARCODE, intent)
        finish()
    }

    fun setFlash(turnOn: Boolean) {
        mScannerView?.flash = turnOn
    }

}