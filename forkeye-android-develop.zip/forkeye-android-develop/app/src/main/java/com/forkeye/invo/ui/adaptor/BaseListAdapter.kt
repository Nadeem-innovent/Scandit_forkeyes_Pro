package app.commons.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

/**
 *
 */
class BaseListAdapter(var viewProvider: BaseAdapterViewProvider) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var items: List<Any>? = null

    fun setData(data: Any?) {

        if (data == null)
            items = null
        else
            items = data as List<Any>

        notifyDataSetChanged()
    }

    fun getItem(position: Int): Any? {

        return items?.get(position)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        (holder as BaseListViewHolder).bindItem(getItem(position)!!)
    }

    override fun getItemCount(): Int {

        return if (items != null) items!!.size else 0
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(viewProvider.getLayoutId(), parent, false)

        return BaseListViewHolder(view)
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        recyclerView.isNestedScrollingEnabled = false
    }

    inner class BaseListViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun bindItem(item: Any) {

            viewProvider.populateView(itemView, item, adapterPosition, itemCount)
        }
    }
}
