package com.forkeye.invo.data.local.db.entities

import java.io.Serializable

data class LocationBody(
    val LocationDetails: String,
    val StorageLocation: String,
    val BinLocation: String,
    val Lane: String,
    val MappedZone: String
):Serializable
