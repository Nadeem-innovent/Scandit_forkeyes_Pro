package com.forkeye.invo.data.remote.response

import java.io.Serializable

//{
//    "success": "true",
//    "data": [
//    {
//        "id": 165,
//        "subCode": "fbfba1b0b46f4344",
//        "status": "false",
//        "uuid": ""
//    }
//    ]
//}


data class SubcriptionResponse(
    val success: Boolean,
    val data: List<SubDataResponse>?,
    val message: String?
) : Serializable

data class SubDataResponse(
    val id: Int,
    val subCode:String,
    val status: String,
    val uuid: String
)