package com.forkeye.invo.utils

import android.content.Context
import java.util.*

open class AppGlobals(var context: Context) {

    companion object {

        val SHARED_PREFERENCES = "shared_preferences"
        private const val APP_LANGUAGE = "APP_LANGUAGE"

        const val APP_LANGUAGE_EN = "en"
        const val APP_LANGUAGE_AR = "ar"
        private const val APP_LANGUAGE_DEFAULT = APP_LANGUAGE_AR

        fun getDefaultLanguage(): String {

//            return APP_LANGUAGE_DEFAULT
            return Locale.getDefault().language
        }
    }

    val sharedPreferences = context.getSharedPreferences(SHARED_PREFERENCES, Context.MODE_PRIVATE)

    fun getBoolean(key: String, defaultValue: Boolean): Boolean {

        return sharedPreferences.getBoolean(key, defaultValue)
    }

    fun setBoolean(key: String, value: Boolean) {

        val editor = sharedPreferences.edit()
        editor.putBoolean(key, value)
        editor.apply()
    }

    fun getString(key: String, defaultValue: String?): String? {

        return sharedPreferences.getString(key, defaultValue)
    }

    fun setString(key: String, value: String?) {

        val editor = sharedPreferences.edit()
        editor.putString(key, value)
        editor.apply()
    }

    fun getInt(key: String, defaultValue: Int): Int {

        return sharedPreferences.getInt(key, defaultValue)
    }

    fun setInt(key: String, value: Int) {

        val editor = sharedPreferences.edit()
        editor.putInt(key, value)
        editor.apply()
    }

    fun getFloat(key: String, defaultValue: Float): Float {

        return sharedPreferences.getFloat(key, defaultValue)
    }

    fun setFloat(key: String, value: Float) {

        val editor = sharedPreferences.edit()
        editor.putFloat(key, value)
        editor.apply()
    }


    fun getDeviceID(): String {

        if (sharedPreferences.contains("deviceID")) {
            return sharedPreferences.getString("deviceID", "") ?: ""
        } else {
            val editor = sharedPreferences.edit()
            val deviceID = UUID.randomUUID().toString()
            editor.putString("deviceID", deviceID)
            editor.apply()
            return deviceID
        }
    }

    fun getAppLanguage(): String {

        return getString(APP_LANGUAGE, getDefaultLanguage())!!
    }

    fun setAppLanguage(language: String) {

        setString(APP_LANGUAGE, language)
    }

    fun isArabicSelected (): Boolean {

        return getAppLanguage().equals("ar")
    }
}
